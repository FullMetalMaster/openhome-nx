// Colosseum reader test with synthetic data (no real GameCube save is available here).
//   g++ -std=c++17 -Isource -o /tmp/tc tests/test_colo.cpp source/pkm/*.cpp source/box/*.cpp source/save/*.cpp && /tmp/tc
// The encryption below is written from PKHeX's ColoCrypto (encrypt direction) so it checks the reader's
// decrypt direction independently.
#include <cassert>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>

#include "pkm/pkm_internal.hpp"
#include "save/hash.hpp"
#include "save/savefile.hpp"

using Bytes = std::vector<uint8_t>;
static int g_checks = 0;
#define CHECK(c) do { g_checks++; if (!(c)) { std::printf("FAIL %s:%d  %s\n", __FILE__, __LINE__, #c); std::exit(1); } } while (0)

static void w16(uint8_t* p, uint16_t v) { p[0] = v >> 8; p[1] = (uint8_t)v; }
static void w32(uint8_t* p, uint32_t v) { p[0] = v >> 24; p[1] = v >> 16; p[2] = v >> 8; p[3] = (uint8_t)v; }
static uint32_t r32(const uint8_t* p) { return (uint32_t)p[0] << 24 | p[1] << 16 | p[2] << 8 | p[3]; }

constexpr size_t SLOT = 0x1E000, START = 0x6000;

static void putText(uint8_t* p, const char16_t* s) { for (int i = 0; s[i]; i++) w16(p + i * 2, s[i]); }

// species: internal Gen 3 id (Pikachu national 25 = internal 25, Mudkip 258 national = internal 283)
static void makeCk3(uint8_t* c, uint16_t internalSpecies, uint32_t exp, const char16_t* nick) {
    std::memset(c, 0, 312);
    w16(c, internalSpecies);
    w32(c + 4, 0x12345678);
    c[0x08] = 11;  // CXD
    c[0x09] = 2; c[0x0A] = 2;  // NTSC-U
    c[0x0B] = 2;   // English
    w16(c + 0x0C, 0x10);
    c[0x0E] = 5; c[0x0F] = 4;
    w16(c + 0x14, 0x2222); w16(c + 0x16, 0x1111);  // SID, TID
    putText(c + 0x18, u"WES");
    putText(c + 0x44, nick);
    w32(c + 0x5C, exp);
    c[0x60] = 30;
    w16(c + 0x78, 85); c[0x7A] = 15;   // Thunderbolt
    w16(c + 0x7C, 98); c[0x7E] = 30;   // Quick Attack
    w16(c + 0x8A, 70); w16(c + 0x8C, 80);
    w16(c + 0x98, 4);  w16(c + 0xA4, 31); w16(c + 0xA6, 10);
}

static void encryptSlot(uint8_t* s) {
    uint8_t digest[20];
    for (int i = 0; i < 20; i++) digest[i] = (uint8_t)~s[SLOT - 20 + i];
    uint8_t* p = s + 0x18;
    size_t left = SLOT - 20 - 0x18;
    while (left >= 20) {
        for (int j = 0; j < 20; j++) p[j] ^= digest[j];
        save::hash::sha1(p, 20, digest);
        p += 20; left -= 20;
    }
}

static void finishSlot(uint8_t* s) {  // PKHeX SetChecksums
    w32(s + 0x0C, 0);
    uint8_t h[20];
    save::hash::sha1(s, SLOT - 40, h);
    std::memcpy(s + SLOT - 20, h, 20);
    int32_t r = 0;
    for (int i = 0; i < 0x18; i += 4) r -= (int32_t)r32(s + i);
    r -= (int32_t)(r32(s + 0x18) ^ ~r32(h));
    r -= (int32_t)(r32(s + 0x1C) ^ ~r32(h + 4));
    w32(s + 0x0C, (uint32_t)r);
}

static Bytes makeSave(uint32_t olderCounter, uint32_t newerCounter) {
    Bytes b(0x60000, 0);
    for (int i = 0; i < 3; i++) {
        uint8_t* s = b.data() + START + SLOT * i;
        s[0] = 1; s[1] = 1; s[2] = 0; s[3] = 0;  // reads as 0x00000101 little endian
        w32(s + 4, i == 2 ? newerCounter : olderCounter);
        s[0x08] = 0; s[0x09] = 2; s[0x0A] = 2; s[0x0B] = 2;
        putText(s + 0x78, i == 2 ? u"WAYNE" : u"OLD");
        if (i == 2) {
            makeCk3(s + 0xB90 + 0x14, 25, 27000, u"SPARKY");               // box 1 slot 1: Pikachu
            makeCk3(s + 0xB90 + 0x14 + 312 * 5, 283, 15000, u"MUD");        // box 1 slot 6: Mudkip (internal 283)
            makeCk3(s + 0xB90 + 0x24A4 + 0x14, 25, 1000, u"B2");            // box 2 slot 1
            makeCk3(s + 0xA8, 25, 27000, u"PARTYMON");                      // party 1
            putText(s + 0xB90, u"Shadows");
        }
        finishSlot(s);
        encryptSlot(s);
    }
    return b;
}

static void checkSave(save::SaveFile* sv) {
    CHECK(sv != nullptr);
    CHECK(sv->format() == pkm::Format::PK3);
    CHECK(sv->boxCount() == 3 && sv->boxSlots() == 30);
    CHECK(sv->trainer() == "WAYNE");  // newest slot, not the older "OLD" ones
    CHECK(sv->boxName(0) == "Shadows" && sv->boxName(1) == "Box 2");
    CHECK(sv->partyCount() == 1);
    std::vector<uint8_t> m;
    CHECK(sv->readBox(0, 0, m) && m.size() == 80);
    pkm::Info i = sv->describe(m);
    CHECK(i.valid && i.species == 25 && i.level == 0 + i.level);
    CHECK(pkm::utf16ToUtf8(i.nickname) == "SPARKY" && pkm::utf16ToUtf8(i.otName) == "WES");
    CHECK(i.tid == 0x1111 && i.sid == 0x2222 && i.exp == 27000);
    CHECK(pkm::levelFromExp(25, 27000) > 0);
    CHECK(pkm::rd16(m.data() + 0x1C) == pkm::gen3Checksum(m.data()));  // a valid, standard .pk3
    CHECK(pkm::rd16(m.data() + 0x2C) == 85 && pkm::rd16(m.data() + 0x2E) == 98);
    CHECK(pkm::rd32(m.data() + 0x48) == (31u | 10u << 5));  // IV HP and Atk
    CHECK(sv->readBox(0, 5, m) && sv->describe(m).species == 258);  // Mudkip: internal 283 -> national 258
    CHECK(!sv->readBox(0, 1, m));                                   // empty
    CHECK(sv->readBox(1, 0, m) && sv->describe(m).species == 25);
    CHECK(!sv->readBox(3, 0, m));
    CHECK(sv->readParty(0, m) && m.size() == 100 && m[0x54] == 30);
    CHECK(!sv->readParty(1, m));
}

int main() {
    Bytes raw = makeSave(5, 9);
    std::string err;
    {
        auto sv = save::open(raw, "colo.raw", nullptr, err);
        if (!sv) std::printf("open error: %s\n", err.c_str());
        checkSave(sv.get());
    }
    {   // .gci: 0x40 byte directory entry first
        Bytes gci(0x40, 0);
        std::memcpy(gci.data(), "GC6E01", 6);
        gci.insert(gci.end(), raw.begin(), raw.end());
        auto sv = save::open(gci, "colo.gci", nullptr, err);
        checkSave(sv.get());
    }
    {   // memory card: 4 MiB (0x80000 minimum is 4 Mbit = 512 KiB), Colosseum file at block 5
        Bytes card(0x80000 * 2, 0);  // 1 MiB
        // header size field in megabits: bytes / 0x2000 / 16 = 1 MiB / 8192 / 16 = 8
        w16(card.data() + 0x22, (uint16_t)(card.size() / 0x2000 / 16));
        card[0] = 0; card[1] = 1;  // not all 0xFF
        uint8_t* dir = card.data() + 0x2000;
        std::memcpy(dir + 0 * 0x40, "GC6E01", 6);
        w16(dir + 0x36, 5);       // first block
        w16(dir + 0x38, 0x60000 / 0x2000);  // block count 48
        std::memcpy(card.data() + 5 * 0x2000, raw.data(), raw.size());
        auto sv = save::open(card, "card.raw", nullptr, err);
        checkSave(sv.get());
        // a second directory entry for another game is ignored
        std::memcpy(dir + 0x40, "GXXE01", 6);
        sv = save::open(card, "card.raw", nullptr, err);
        checkSave(sv.get());
    }
    {   // a corrupted body is reported, not silently read
        Bytes bad = raw;
        bad[START + SLOT * 2 + 0x5000] ^= 0xFF;
        auto sv = save::open(bad, "colo.raw", nullptr, err);
        CHECK(!sv && !err.empty() && err.find("checksum") != std::string::npos);
    }
    {   // random same-size data is "not mine", not an error from this reader
        Bytes junk(0x60000, 0x5A);
        auto sv = save::open(junk, "x.raw", nullptr, err);
        CHECK(!sv);
    }
    std::printf("colosseum tests passed (%d checks)\n", g_checks);
    return 0;
}
