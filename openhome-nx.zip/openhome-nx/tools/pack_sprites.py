#!/usr/bin/env python3
"""
Pack box sprites from an OpenHome checkout into romfs/sprites/<dex>.png (64x64).

    python3 tools/pack_sprites.py /path/to/OpenHome

Sprites come from OpenHome's public/sprites/box-home (128px webp, named by species).
Only the base form is packed per National Dex number. The app falls back to a plain
placeholder for any missing number. Requires Pillow (pip install pillow).
"""
import re
import sys
import unicodedata
from pathlib import Path

from PIL import Image

SIZE = 64

SPECIAL = {
    "Nidoran♀": "nidoran-f",
    "Nidoran♂": "nidoran-m",
    "Mr. Mime": "mr-mime",
    "Mime Jr.": "mime-jr",
    "Mr. Rime": "mr-rime",
    "Type: Null": "type-null",
    "Farfetch'd": "farfetchd",
    "Sirfetch'd": "sirfetchd",
    "Flabébé": "flabebe",
    "Porygon-Z": "porygon-z",
}


def slug(name):
    if name in SPECIAL:
        return SPECIAL[name]
    s = unicodedata.normalize("NFKD", name).encode("ascii", "ignore").decode()
    s = s.lower().replace(" ", "-")
    return re.sub(r"[^a-z0-9-]", "", s)


def main():
    if len(sys.argv) != 2:
        sys.exit("usage: pack_sprites.py /path/to/OpenHome")
    root = Path(sys.argv[1])
    src = root / "public/sprites/box-home"
    names_file = root / "pkm_rs_resources/src/pkhex_text/species/text_Species_en.txt"
    if not src.is_dir() or not names_file.is_file():
        sys.exit("not an OpenHome checkout (missing box-home sprites or species names)")
    names = names_file.read_text(encoding="utf-8").split("\n")
    out = Path(__file__).resolve().parent.parent / "romfs/sprites"
    out.mkdir(parents=True, exist_ok=True)
    have = {p.stem: p for p in src.glob("*.webp")}
    missing = []
    packed = 0
    for dex in range(1, 1026):
        s = slug(names[dex])
        p = have.get(s)
        if p is None:  # fall back to the first form sprite, e.g. basculin-red-striped
            cands = sorted(k for k in have if k.startswith(s + "-"))
            p = have[cands[0]] if cands else None
        if p is None:
            missing.append((dex, names[dex], s))
            continue
        im = Image.open(p).convert("RGBA").resize((SIZE, SIZE), Image.LANCZOS)
        im.save(out / f"{dex}.png", optimize=True)
        packed += 1
    total = sum(f.stat().st_size for f in out.glob("*.png"))
    print(f"packed {packed}/1025 sprites, {total // 1024} KiB")
    for m in missing:
        print("  missing:", m)


if __name__ == "__main__":
    main()
