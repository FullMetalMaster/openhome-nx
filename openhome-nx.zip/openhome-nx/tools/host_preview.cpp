// Desktop preview: runs the real UI with scripted input and writes PNG screenshots.
//
//   g++ -std=c++17 -O1 -Isource -Itests -o host_preview tools/host_preview.cpp source/ui/app.cpp source/gfx/canvas.cpp source/box/*.cpp source/pkm/*.cpp source/save/*.cpp
//   ./host_preview /path/to/openhome-nx /path/to/a.ttf /output/dir
#define STB_IMAGE_WRITE_IMPLEMENTATION
#include <cstdio>
#include <string>
#include <vector>

#include "box/fsutil.hpp"
#include "pkm/pkm.hpp"
#include "platform/platform.hpp"
#include "stb_image_write.h"
#include "ui/app.hpp"

namespace {

struct Step {
    uint32_t down = 0;
    bool touch = false;
    int tx = 0, ty = 0;
    int idle = 0;           // extra empty frames after this step
    std::string shot;       // screenshot name after this step renders
};

class HostPlatform : public plat::Platform {
public:
    HostPlatform(std::string project, std::string ttf, std::string out, std::vector<Step> steps)
        : project_(std::move(project)), out_(std::move(out)), steps_(std::move(steps)) {
        fsu::readFile(ttf, font_, 32u << 20);
        data_ = out_ + "/data";
        sd_ = out_ + "/sd";
    }
    bool init() override { return !font_.empty(); }
    void shutdown() override {}
    bool running() override { return true; }
    plat::Input poll() override {
        plat::Input in;
        if (pos_ >= steps_.size()) { in.down = plat::Plus; return in; }
        Step& s = steps_[pos_];
        if (idleLeft_ > 0) { idleLeft_--; if (idleLeft_ == 0) pos_++; return in; }
        in.down = s.down;
        in.touchBegan = s.touch;
        in.touching = s.touch;
        in.tx = s.tx;
        in.ty = s.ty;
        if (!s.shot.empty()) pending_ = s.shot;
        if (s.idle > 0) idleLeft_ = s.idle; else pos_++;
        return in;
    }
    void present(const gfx::Canvas& c) override {
        if (pending_.empty()) return;
        std::string path = out_ + "/" + pending_ + ".png";
        stbi_write_png(path.c_str(), c.width(), c.height(), 4, c.pixels(), c.width() * 4);
        std::printf("wrote %s\n", path.c_str());
        pending_.clear();
    }
    const uint8_t* fontData(size_t& size) override { size = font_.size(); return font_.data(); }
    std::string dataRoot() override { return data_; }
    std::string sdRoot() override { return sd_ + "/"; }
    std::string assetPath(const std::string& rel) override { return project_ + "/romfs/" + rel; }

private:
    std::string project_, out_, data_, sd_;
    std::vector<uint8_t> font_;
    std::vector<Step> steps_;
    size_t pos_ = 0;
    int idleLeft_ = 0;
    std::string pending_;
};

void put16(std::vector<uint8_t>& b, size_t off, uint16_t v) { b[off] = v & 0xFF; b[off + 1] = v >> 8; }

void seedPokemon(const std::string& data) {
    struct P { int slot, dex; const char* nick; };
    const P mons[] = {{0, 6, "Blaze"}, {1, 25, "Sparky"}, {2, 150, ""}, {3, 94, ""}, {4, 448, ""}, {5, 658, ""},
                      {6, 384, ""}, {7, 133, "Eevee"}, {8, 149, ""}, {9, 130, ""}, {10, 143, "Munch"}, {11, 9, ""},
                      {12, 3, ""}, {14, 700, ""}, {15, 197, ""}, {16, 282, ""}, {17, 445, "Spike"}, {18, 249, ""},
                      {24, 250, ""}, {25, 487, ""}, {26, 493, ""}, {27, 635, ""}, {30, 612, ""}, {31, 306, ""},
                      {37, 59, ""}, {38, 134, ""}, {39, 135, ""}, {40, 136, ""}, {50, 1000, ""}, {51, 1008, ""}};
    std::string dir = data + "/boxes/Bank 1/Box 01";
    fsu::mkdirs(dir);
    for (const P& m : mons) {
        std::vector<uint8_t> b(344, 0);
        put16(b, 0x08, (uint16_t)m.dex);
        for (size_t i = 0; m.nick[i]; i++) put16(b, 0x58 + i * 2, (uint8_t)m.nick[i]);
        for (size_t i = 0; "Ash"[i]; i++) put16(b, 0xF8 + i * 2, (uint8_t)"Ash"[i]);
        char name[64];
        std::snprintf(name, sizeof(name), "%03d_mon%d.pk9", m.slot, m.dex);
        fsu::writeFile(dir + "/" + name, b.data(), b.size());
    }
}

void seedSd(const std::string& sd) {
    struct F { const char* path; size_t size; };
    const F files[] = {{"roms/gba/Pokemon Emerald.sav", 131072}, {"roms/gba/Pokemon FireRed.sav", 131072},
                       {"roms/nds/Pokemon Platinum.dsv", 524288}, {"roms/nds/Pokemon Black 2.sav", 524288},
                       {"saves/citra/XY/main.sav", 415232}, {"saves/misc.sav", 777}, {"roms/gb/Crystal.sav", 32768}};
    for (const F& f : files) {
        std::string p = sd + "/" + f.path;
        fsu::mkdirs(p.substr(0, p.find_last_of('/')));
        std::vector<uint8_t> b(f.size, 0);
        fsu::writeFile(p, b.data(), b.size());
    }
    std::vector<uint8_t> pk(344, 0);
    put16(pk, 0x08, 25);
    fsu::writeFile(sd + "/roms/Pikachu.pk9", pk.data(), pk.size());
}

}  // namespace

int main(int argc, char** argv) {
    if (argc != 4) { std::fprintf(stderr, "usage: host_preview <project> <font.ttf> <outdir>\n"); return 2; }
    std::string out = argv[3];
    fsu::mkdirs(out);
    seedPokemon(out + "/data");
    seedSd(out + "/sd");
    using namespace plat;
    std::vector<Step> s;
    auto press = [&](uint32_t b, const char* shot = "", int idle = 0) { Step st; st.down = b; st.shot = shot; st.idle = idle; s.push_back(st); };
    auto tap = [&](int x, int y, const char* shot = "") { Step st; st.touch = true; st.tx = x; st.ty = y; st.shot = shot; s.push_back(st); };

    press(0, "01_home");
    press(Right); press(Right); press(Right); press(Down); press(A, "02_home_holding");
    press(Right); press(Right); press(Down); press(A, "03_home_after_move");
    press(Y, "04_keyboard");
    tap(290 + 18 + 67 * 0, 70 + 150 + 66 + 20);  // Q? (row 1 col 0) - just exercise touch typing
    press(Plus, "05_filter_applied");
    press(B); press(Minus);
    press(Left); press(Left); press(Left); press(Left); press(Up); press(Up);
    press(X, "06_release_confirm");
    press(B);
    press(ZR); press(X, "", 60); tap(640, 560, "07_saves_scan_done");
    press(R, "08_saves_browse");
    press(Down); press(Down); press(A, "09_saves_browse_dir");
    press(B);
    press(Left); press(Y, "10_users_dialog");
    press(A);
    press(A, "11_mount_error");
    press(A);
    press(ZR, "12_settings");
    press(ZR); press(0, "13_home_again");
    return ui::run(*new HostPlatform(argv[1], argv[2], out, s));
}
