// Desktop preview: runs the real UI with scripted input and writes PNG screenshots.
//
//   g++ -std=c++17 -O1 -Isource -Itests -o host_preview tools/host_preview.cpp source/ui/app.cpp source/gfx/canvas.cpp source/box/*.cpp source/pkm/*.cpp source/save/*.cpp
//   ./host_preview /path/to/openhome-nx /path/to/a.ttf /output/dir
#define STB_IMAGE_WRITE_IMPLEMENTATION
#include <cstdio>
#include <string>
#include <vector>

#include "box/fsutil.hpp"
#include <dirent.h>
#include <cstring>

#include "pkm/pkm.hpp"
#include "pkm/pkm_internal.hpp"
#include "platform/platform.hpp"
#include "stb_image_write.h"
#include "ui/app.hpp"

namespace {

struct Step {
    uint32_t down = 0;
    bool touch = false;
    int tx = 0, ty = 0;
    int idle = 0;           // extra empty frames after this step
    std::string shot;       // screenshot name after this step renders
};

class HostPlatform : public plat::Platform {
public:
    HostPlatform(std::string project, std::string ttf, std::string out, std::vector<Step> steps)
        : project_(std::move(project)), out_(std::move(out)), steps_(std::move(steps)) {
        fsu::readFile(ttf, font_, 32u << 20);
        data_ = out_ + "/data";
        sd_ = out_ + "/sd";
    }
    bool init() override { return !font_.empty(); }
    void shutdown() override {}
    bool running() override { return true; }
    plat::Input poll() override {
        plat::Input in;
        if (pos_ >= steps_.size()) { in.down = plat::Plus; return in; }
        Step& s = steps_[pos_];
        if (idleLeft_ > 0) { idleLeft_--; if (idleLeft_ == 0) pos_++; return in; }
        in.down = s.down;
        in.touchBegan = s.touch;
        in.touching = s.touch;
        in.tx = s.tx;
        in.ty = s.ty;
        if (!s.shot.empty()) pending_ = s.shot;
        if (s.idle > 0) idleLeft_ = s.idle; else pos_++;
        return in;
    }
    void present(const gfx::Canvas& c) override {
        if (pending_.empty()) return;
        std::string path = out_ + "/" + pending_ + ".png";
        stbi_write_png(path.c_str(), c.width(), c.height(), 4, c.pixels(), c.width() * 4);
        std::printf("wrote %s\n", path.c_str());
        pending_.clear();
    }
    const uint8_t* fontData(size_t& size) override { size = font_.size(); return font_.data(); }
    std::string dataRoot() override { return data_; }
    std::string sdRoot() override { return sd_ + "/"; }
    std::string assetPath(const std::string& rel) override { return project_ + "/romfs/" + rel; }

private:
    std::string project_, out_, data_, sd_;
    std::vector<uint8_t> font_;
    std::vector<Step> steps_;
    size_t pos_ = 0;
    int idleLeft_ = 0;
    std::string pending_;
};

void put16(std::vector<uint8_t>& b, size_t off, uint16_t v) { b[off] = v & 0xFF; b[off + 1] = v >> 8; }

void seedPokemon(const std::string& data) {
    struct P { int slot, dex; const char* nick; };
    const P mons[] = {{0, 6, "Blaze"}, {1, 25, "Sparky"}, {2, 150, ""}, {3, 94, ""}, {4, 448, ""}, {5, 658, ""},
                      {6, 384, ""}, {7, 133, "Eevee"}, {8, 149, ""}, {9, 130, ""}, {10, 143, "Munch"}, {11, 9, ""},
                      {12, 3, ""}, {14, 700, ""}, {15, 197, ""}, {16, 282, ""}, {17, 445, "Spike"}, {18, 249, ""},
                      {24, 250, ""}, {25, 487, ""}, {26, 493, ""}, {27, 635, ""}, {30, 612, ""}, {31, 306, ""},
                      {37, 59, ""}, {38, 134, ""}, {39, 135, ""}, {40, 136, ""}, {50, 1000, ""}, {51, 1008, ""}};
    std::string dir = data + "/boxes/Bank 1/Box 01";
    fsu::mkdirs(dir);
    for (const P& m : mons) {
        std::vector<uint8_t> b(344, 0);
        put16(b, 0x08, (uint16_t)m.dex);
        for (size_t i = 0; m.nick[i]; i++) put16(b, 0x58 + i * 2, (uint8_t)m.nick[i]);
        for (size_t i = 0; "Ash"[i]; i++) put16(b, 0xF8 + i * 2, (uint8_t)"Ash"[i]);
        char name[64];
        std::snprintf(name, sizeof(name), "%03d_mon%d.pk9", m.slot, m.dex);
        fsu::writeFile(dir + "/" + name, b.data(), b.size());
    }
}

// Builds a real-layout FireRed save (two 14-sector copies) holding the decrypted .pk3 samples from tests/data/pk3.
std::vector<uint8_t> buildGen3Save(const std::string& project, bool hack = false) {
    static const uint16_t kLen[14] = {3884, 3968, 3968, 3968, 3848, 3968, 3968, 3968, 3968, 3968, 3968, 3968, 3968, 2000};
    std::vector<uint8_t> small(0xF80, 0), large(4 * 0xF80, 0), storage(9 * 0xF80, 0);
    small[0] = 0xBB; small[1] = 0xBC; small[2] = 0xBD; small[3] = 0xFF;  // "ABC"
    pkm::wr32(small.data() + 0xAC, 1);                                   // FireRed / LeafGreen
    std::string dir = project + "/tests/data/pk3";
    int slot = 0;
    if (DIR* d = opendir(dir.c_str())) {
        while (dirent* e = readdir(d)) {
            std::string n = e->d_name;
            if (n.size() < 5 || n.substr(n.size() - 4) != ".pk3") continue;
            std::vector<uint8_t> m;
            if (!fsu::readFile(dir + "/" + n, m) || m.size() < 80) continue;
            m.resize(80);
            if (hack) {  // Unbound-style numbers: Gen 4/5/6/7 species after the Gen 3 block, plus hack-only ids with no official art
                static const uint16_t kHack[] = {440, 547, 758, 939, 1013, 1020, 1021, 1030, 25, 277};
                int hs = slot % (int)(sizeof(kHack) / sizeof(kHack[0]));
                if (slot < 10) {
                    pkm::gen3Decrypt(m.data());
                    pkm::wr16(m.data() + 0x20, kHack[hs]);
                    pkm::wr16(m.data() + 0x1C, pkm::gen3Checksum(m.data()));
                }
            }
            pkm::gen3Encrypt(m.data());
            std::memcpy(storage.data() + 4 + 80 * (slot % 30 + 30 * (slot / 30)), m.data(), 80);
            if (++slot >= 40) break;
        }
        closedir(d);
    }
    std::vector<uint8_t> img(0x20000, 0xFF);
    for (int copy = 0; copy < 2; copy++)
        for (int phys = 0; phys < 14; phys++) {
            int id = phys;
            uint8_t* sec = img.data() + (copy ? 0xE000 : 0) + phys * 0x1000;
            std::memset(sec, 0, 0x1000);
            const uint8_t* src = id == 0 ? small.data() : id <= 4 ? large.data() + (id - 1) * 0xF80 : storage.data() + (id - 5) * 0xF80;
            std::memcpy(sec, src, kLen[id]);
            uint32_t sum = 0;
            for (size_t i = 0; i + 4 <= kLen[id]; i += 4) sum += pkm::rd32(sec + i);
            pkm::wr16(sec + 0xFF4, (uint16_t)id);
            pkm::wr16(sec + 0xFF6, (uint16_t)(sum + (sum >> 16)));
            pkm::wr32(sec + 0xFF8, 0x08012025);
            pkm::wr32(sec + 0xFFC, copy ? 9 : 5);
        }
    return img;
}

void seedSd(const std::string& sd, const std::string& project) {
    struct F { const char* path; size_t size; };
    const F files[] = {{"roms/gba/Pokemon Emerald.sav", 131072}, {"roms/gba/Pokemon FireRed.sav", 131072},
                       {"roms/nds/Pokemon Platinum.dsv", 524288}, {"roms/nds/Pokemon Black 2.sav", 524288},
                       {"saves/citra/XY/main.sav", 415232}, {"saves/misc.sav", 777}, {"roms/gb/Crystal.sav", 32768}};
    for (const F& f : files) {
        std::string p = sd + "/" + f.path;
        fsu::mkdirs(p.substr(0, p.find_last_of('/')));
        std::vector<uint8_t> b(f.size, 0);
        fsu::writeFile(p, b.data(), b.size());
    }
    {
        std::vector<uint8_t> g3 = buildGen3Save(project);
        fsu::writeFile(sd + "/roms/gba/Pokemon FireRed.sav", g3.data(), g3.size());
        std::vector<uint8_t> hk = buildGen3Save(project, true);
        fsu::writeFile(sd + "/roms/gba/Pokemon Unbound.sav", hk.data(), hk.size());
    }
    std::vector<uint8_t> pk(344, 0);
    put16(pk, 0x08, 25);
    fsu::writeFile(sd + "/roms/Pikachu.pk9", pk.data(), pk.size());
}

}  // namespace

int main(int argc, char** argv) {
    if (argc != 4) { std::fprintf(stderr, "usage: host_preview <project> <font.ttf> <outdir>\n"); return 2; }
    std::string out = argv[3];
    fsu::mkdirs(out);
    seedPokemon(out + "/data");
    seedSd(out + "/sd", argv[1]);
    using namespace plat;
    std::vector<Step> s;
    auto press = [&](uint32_t b, const char* shot = "", int idle = 0) { Step st; st.down = b; st.shot = shot; st.idle = idle; s.push_back(st); };
    auto tap = [&](int x, int y, const char* shot = "") { Step st; st.touch = true; st.tx = x; st.ty = y; st.shot = shot; s.push_back(st); };

    press(0, "01_home");
    press(ZR); press(X, "", 60); tap(700, 218);  // select the FireRed row
    tap(700, 218, "02_save_opened");             // second tap opens it
    press(Left, "03_save_focus");                // d-pad Left from the bank's first column enters the save panel
    press(Right); press(Right); press(Down);
    press(A, "04_save_copy_held");               // pick up a copy
    press(Right); press(Right); press(Right); press(Right); press(Right);  // leave the save panel -> bank
    press(Right); press(Down); press(Down); press(Down); press(Down); press(Down); press(Down);
    press(A, "05_copied_into_bank");
    press(L, "06_other_save_box");               // (focus is on the bank now: L changes the bank box)
    press(Left, "07_back_to_save");
    press(R, "08_save_next_box");
    tap(60, 120, "09_touch_pick");
    tap(60, 120, "10_touch_pick_up");
    tap(420, 150, "11_touch_place");
    press(ZR); press(ZL);  // Find Saves tab is reached with ZR from Home; ZL from Find Saves returns home
    press(ZR, "12_findsaves_again");
    tap(700, 252); tap(700, 252, "13_unbound_open");   // Pokemon Unbound.sav (FireRed hack): placeholders for hack-only ids
    return ui::run(*new HostPlatform(argv[1], argv[2], out, s));
}
