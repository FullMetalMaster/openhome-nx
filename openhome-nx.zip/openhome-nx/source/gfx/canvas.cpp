#include "gfx/canvas.hpp"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>

#define STB_IMAGE_IMPLEMENTATION
#define STBI_ONLY_PNG
#define STBI_NO_LINEAR
#define STBI_NO_HDR
#include "third_party/stb_image.h"

#define STB_TRUETYPE_IMPLEMENTATION
#include "third_party/stb_truetype.h"

namespace gfx {

// ---------------------------------------------------------------- images
Image loadPng(const std::string& path) {
    Image img;
    int w = 0, h = 0, n = 0;
    unsigned char* d = stbi_load(path.c_str(), &w, &h, &n, 4);
    if (!d) return img;
    img.w = w;
    img.h = h;
    img.px.resize((size_t)w * h);
    std::memcpy(img.px.data(), d, (size_t)w * h * 4);
    stbi_image_free(d);
    return img;
}

// ---------------------------------------------------------------- font
struct Font::Impl {
    stbtt_fontinfo info;
};

bool Font::init(const uint8_t* data, size_t) {
    impl_ = std::make_shared<Impl>();
    int off = stbtt_GetFontOffsetForIndex(data, 0);
    ok_ = off >= 0 && stbtt_InitFont(&impl_->info, data, off) != 0;
    cache_.clear();
    return ok_;
}

int Font::ascent(int px) const {
    if (!ok_) return px;
    int a, d, g;
    stbtt_GetFontVMetrics(&impl_->info, &a, &d, &g);
    return (int)std::lround(a * stbtt_ScaleForPixelHeight(&impl_->info, (float)px));
}

int Font::lineHeight(int px) const {
    if (!ok_) return px;
    int a, d, g;
    stbtt_GetFontVMetrics(&impl_->info, &a, &d, &g);
    return (int)std::lround((a - d + g) * stbtt_ScaleForPixelHeight(&impl_->info, (float)px));
}

const Font::Glyph& Font::glyph(uint32_t cp, int px) {
    uint64_t key = ((uint64_t)cp << 16) | (uint64_t)px;
    auto it = cache_.find(key);
    if (it != cache_.end()) return it->second;
    Glyph g;
    if (ok_) {
        float sc = stbtt_ScaleForPixelHeight(&impl_->info, (float)px);
        int adv, lsb;
        stbtt_GetCodepointHMetrics(&impl_->info, (int)cp, &adv, &lsb);
        g.adv = adv * sc;
        int x0, y0, x1, y1;
        stbtt_GetCodepointBitmapBox(&impl_->info, (int)cp, sc, sc, &x0, &y0, &x1, &y1);
        g.w = x1 - x0;
        g.h = y1 - y0;
        g.xoff = x0;
        g.yoff = y0;
        if (g.w > 0 && g.h > 0) {
            g.bmp.resize((size_t)g.w * g.h);
            stbtt_MakeCodepointBitmap(&impl_->info, g.bmp.data(), g.w, g.h, g.w, sc, sc, (int)cp);
        }
    }
    return cache_.emplace(key, std::move(g)).first->second;
}

static uint32_t nextCp(const std::string& s, size_t& i) {
    unsigned char c = (unsigned char)s[i++];
    if (c < 0x80) return c;
    int extra = (c >= 0xF0) ? 3 : (c >= 0xE0) ? 2 : (c >= 0xC0) ? 1 : 0;
    uint32_t cp = c & (0x3F >> extra);
    while (extra-- > 0 && i < s.size() && ((unsigned char)s[i] & 0xC0) == 0x80) cp = (cp << 6) | ((unsigned char)s[i++] & 0x3F);
    return cp;
}

int Font::measure(const std::string& s, int px) {
    float w = 0;
    for (size_t i = 0; i < s.size();) w += glyph(nextCp(s, i), px).adv;
    return (int)std::lround(w);
}

// ---------------------------------------------------------------- canvas
Canvas::Canvas(int w, int h) : w_(w), h_(h), px_((size_t)w * h, 0xFF000000u), cx1_(w), cy1_(h) {}

void Canvas::setClip(int x, int y, int w, int h) {
    cx0_ = std::max(0, x);
    cy0_ = std::max(0, y);
    cx1_ = std::min(w_, x + w);
    cy1_ = std::min(h_, y + h);
}
void Canvas::clearClip() { cx0_ = 0; cy0_ = 0; cx1_ = w_; cy1_ = h_; }

void Canvas::clear(Color c) {
    uint32_t v = (uint32_t)c.r | ((uint32_t)c.g << 8) | ((uint32_t)c.b << 16) | 0xFF000000u;
    std::fill(px_.begin(), px_.end(), v);
}

void Canvas::blend(int x, int y, Color c, int cov) {
    if (x < cx0_ || y < cy0_ || x >= cx1_ || y >= cy1_) return;
    int a = (c.a * cov) / 255;
    if (a <= 0) return;
    uint32_t& d = px_[(size_t)y * w_ + x];
    if (a >= 255) {
        d = (uint32_t)c.r | ((uint32_t)c.g << 8) | ((uint32_t)c.b << 16) | 0xFF000000u;
        return;
    }
    int dr = d & 0xFF, dg = (d >> 8) & 0xFF, db = (d >> 16) & 0xFF;
    int r = dr + ((c.r - dr) * a) / 255;
    int g = dg + ((c.g - dg) * a) / 255;
    int b = db + ((c.b - db) * a) / 255;
    d = (uint32_t)r | ((uint32_t)g << 8) | ((uint32_t)b << 16) | 0xFF000000u;
}

void Canvas::fillRect(int x, int y, int w, int h, Color c) {
    int x0 = std::max(x, cx0_), y0 = std::max(y, cy0_);
    int x1 = std::min(x + w, cx1_), y1 = std::min(y + h, cy1_);
    for (int yy = y0; yy < y1; yy++)
        for (int xx = x0; xx < x1; xx++) blend(xx, yy, c, 255);
}

void Canvas::hline(int x, int y, int w, Color c) { fillRect(x, y, w, 1, c); }

// Coverage of pixel (px,py) for a rounded rect, using distance to the corner circle.
static int roundCov(int px, int py, int w, int h, int r, float inset) {
    float fx = px + 0.5f, fy = py + 0.5f;
    float cx = std::min(std::max(fx, (float)r), (float)(w - r));
    float cy = std::min(std::max(fy, (float)r), (float)(h - r));
    float d = std::sqrt((fx - cx) * (fx - cx) + (fy - cy) * (fy - cy));
    float cov = (r - inset) - d + 0.5f;
    if (r == 0) {  // plain rect with inset
        cov = std::min(std::min(fx, w - fx), std::min(fy, h - fy)) - inset + 0.5f;
    }
    return (int)(std::min(1.0f, std::max(0.0f, cov)) * 255.0f);
}

void Canvas::fillRoundRect(int x, int y, int w, int h, int r, Color c) {
    r = std::min(r, std::min(w, h) / 2);
    for (int yy = std::max(y, cy0_); yy < std::min(y + h, cy1_); yy++) {
        for (int xx = std::max(x, cx0_); xx < std::min(x + w, cx1_); xx++) {
            int lx = xx - x, ly = yy - y;
            bool corner = (lx < r || lx >= w - r) && (ly < r || ly >= h - r);
            blend(xx, yy, c, corner ? roundCov(lx, ly, w, h, r, 0) : 255);
        }
    }
}

void Canvas::strokeRoundRect(int x, int y, int w, int h, int r, int thick, Color c) {
    r = std::min(r, std::min(w, h) / 2);
    for (int yy = std::max(y, cy0_); yy < std::min(y + h, cy1_); yy++) {
        for (int xx = std::max(x, cx0_); xx < std::min(x + w, cx1_); xx++) {
            int lx = xx - x, ly = yy - y;
            int outer = roundCov(lx, ly, w, h, r, 0);
            if (outer == 0) continue;
            // inner rect shrunk by `thick`
            int ix = lx - thick, iy = ly - thick, iw = w - 2 * thick, ih = h - 2 * thick;
            int inner = 0;
            if (iw > 0 && ih > 0 && ix >= 0 && iy >= 0 && ix < iw && iy < ih) {
                int ir = std::max(0, r - thick);
                inner = roundCov(ix, iy, iw, ih, ir, 0);
            }
            blend(xx, yy, c, std::max(0, outer - inner));
        }
    }
}

void Canvas::drawImage(const Image& img, int x, int y, int w, int h, uint8_t alpha) {
    if (img.empty() || w <= 0 || h <= 0) return;
    for (int yy = std::max(y, cy0_); yy < std::min(y + h, cy1_); yy++) {
        float sy = ((yy - y) + 0.5f) * img.h / h - 0.5f;
        int y0 = (int)std::floor(sy);
        float fy = sy - y0;
        int y1 = std::min(img.h - 1, y0 + 1);
        y0 = std::max(0, y0);
        for (int xx = std::max(x, cx0_); xx < std::min(x + w, cx1_); xx++) {
            float sx = ((xx - x) + 0.5f) * img.w / w - 0.5f;
            int x0 = (int)std::floor(sx);
            float fx = sx - x0;
            int x1 = std::min(img.w - 1, x0 + 1);
            x0 = std::max(0, x0);
            auto at = [&](int ax, int ay) { return img.px[(size_t)ay * img.w + ax]; };
            uint32_t p00 = at(x0, y0), p10 = at(x1, y0), p01 = at(x0, y1), p11 = at(x1, y1);
            float ch[4];
            // premultiplied bilinear to avoid dark fringes
            for (int k = 0; k < 4; k++) {
                auto g = [&](uint32_t p) {
                    float a = ((p >> 24) & 0xFF) / 255.0f;
                    float v = ((p >> (8 * k)) & 0xFF);
                    return k == 3 ? a : v * a;
                };
                float top = g(p00) * (1 - fx) + g(p10) * fx;
                float bot = g(p01) * (1 - fx) + g(p11) * fx;
                ch[k] = top * (1 - fy) + bot * fy;
            }
            float a = ch[3];
            if (a <= 0.003f) continue;
            Color c((uint8_t)std::min(255.f, ch[0] / a), (uint8_t)std::min(255.f, ch[1] / a),
                    (uint8_t)std::min(255.f, ch[2] / a), 255);
            blend(xx, yy, c, (int)(a * alpha));
        }
    }
}

int Canvas::textWidth(const std::string& s, int px) { return font_ ? font_->measure(s, px) : 0; }

void Canvas::text(const std::string& str, int px, int x, int y, Color c, Align al, int maxW) {
    if (!font_ || !font_->ok() || str.empty()) return;
    std::string s = str;
    if (maxW > 0 && font_->measure(s, px) > maxW) {
        int ell = font_->measure("...", px);
        while (!s.empty() && font_->measure(s, px) + ell > maxW) {
            size_t i = s.size() - 1;  // drop whole UTF-8 sequences
            while (i > 0 && ((unsigned char)s[i] & 0xC0) == 0x80) i--;
            s.erase(i);
        }
        s += "...";
    }
    int w = font_->measure(s, px);
    float pen = (float)x;
    if (al == Align::Center) pen = (float)(x - w / 2);
    else if (al == Align::Right) pen = (float)(x - w);
    int base = y + font_->ascent(px);
    for (size_t i = 0; i < s.size();) {
        uint32_t cp = nextCp(s, i);
        const Font::Glyph& g = font_->glyph(cp, px);
        int gx = (int)std::lround(pen) + g.xoff, gy = base + g.yoff;
        for (int yy = 0; yy < g.h; yy++)
            for (int xx = 0; xx < g.w; xx++) blend(gx + xx, gy + yy, c, g.bmp[(size_t)yy * g.w + xx]);
        pen += g.adv;
    }
}

}  // namespace gfx
