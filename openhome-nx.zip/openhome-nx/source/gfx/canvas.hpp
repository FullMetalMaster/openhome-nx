// Tiny software renderer. Pixel format is RGBA8888 in memory (bytes R,G,B,A) which is what the
// libnx framebuffer expects, and what the host test harness dumps to PNG. No GPU, no SDL.
#pragma once
#include <cstdint>
#include <map>
#include <memory>
#include <string>
#include <vector>

namespace gfx {

struct Color {
    uint8_t r = 0, g = 0, b = 0, a = 255;
    constexpr Color() = default;
    constexpr Color(uint8_t r_, uint8_t g_, uint8_t b_, uint8_t a_ = 255) : r(r_), g(g_), b(b_), a(a_) {}
    constexpr Color alpha(uint8_t na) const { return Color(r, g, b, na); }
};
constexpr Color rgb(uint32_t hex) { return Color((hex >> 16) & 0xFF, (hex >> 8) & 0xFF, hex & 0xFF, 255); }

struct Image {
    int w = 0, h = 0;
    std::vector<uint32_t> px;  // RGBA8888 (R in low byte)
    bool empty() const { return px.empty(); }
};

// Load a PNG file (stb_image). Returns empty image on failure.
Image loadPng(const std::string& path);

class Font {
public:
    // `data` must stay alive for the lifetime of the Font (the Switch shared font is static).
    bool init(const uint8_t* data, size_t size);
    bool ok() const { return ok_; }
    struct Glyph { std::vector<uint8_t> bmp; int w = 0, h = 0, xoff = 0, yoff = 0; float adv = 0; };
    const Glyph& glyph(uint32_t cp, int px);
    int ascent(int px) const;
    int lineHeight(int px) const;
    int measure(const std::string& utf8, int px);

private:
    struct Impl;
    std::shared_ptr<Impl> impl_;
    std::map<uint64_t, Glyph> cache_;
    bool ok_ = false;
};

enum class Align { Left, Center, Right };

class Canvas {
public:
    Canvas(int w, int h);
    int width() const { return w_; }
    int height() const { return h_; }
    uint32_t* pixels() { return px_.data(); }
    const uint32_t* pixels() const { return px_.data(); }

    void setFont(Font* f) { font_ = f; }
    Font* font() const { return font_; }

    void setClip(int x, int y, int w, int h);
    void clearClip();

    void clear(Color c);
    void fillRect(int x, int y, int w, int h, Color c);
    void fillRoundRect(int x, int y, int w, int h, int r, Color c);
    void strokeRoundRect(int x, int y, int w, int h, int r, int thick, Color c);
    void hline(int x, int y, int w, Color c);

    // Draw `img` scaled into the destination rectangle (bilinear). `tint` multiplies alpha.
    void drawImage(const Image& img, int x, int y, int w, int h, uint8_t alpha = 255);

    // y is the TOP of the text line. Text longer than maxW (if >0) is ellipsized.
    void text(const std::string& s, int px, int x, int y, Color c, Align a = Align::Left, int maxW = 0);
    int textWidth(const std::string& s, int px);

private:
    void blend(int x, int y, Color c, int cov);
    int w_, h_;
    std::vector<uint32_t> px_;
    int cx0_ = 0, cy0_ = 0, cx1_, cy1_;
    Font* font_ = nullptr;
};

}  // namespace gfx
