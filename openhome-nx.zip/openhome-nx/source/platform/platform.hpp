// Everything the UI needs from the machine: input, a screen to present to, a font and paths.
// The Switch implementation is platform_switch.cpp; the desktop test harness (tools/host_preview.cpp)
// provides another one so the whole UI can be rendered and tested on a PC.
#pragma once
#include <cstddef>
#include <cstdint>
#include <string>

#include "gfx/canvas.hpp"

namespace plat {

enum Btn : uint32_t {
    A = 1 << 0, B = 1 << 1, X = 1 << 2, Y = 1 << 3,
    L = 1 << 4, R = 1 << 5, ZL = 1 << 6, ZR = 1 << 7,
    Plus = 1 << 8, Minus = 1 << 9,
    Up = 1 << 10, Down = 1 << 11, Left = 1 << 12, Right = 1 << 13,
};

struct Input {
    uint32_t down = 0;       // buttons pressed this frame
    uint32_t held = 0;       // buttons currently held
    bool touchBegan = false; // a new finger touched this frame
    bool touching = false;
    int tx = 0, ty = 0;      // touch position in 1280x720 space
};

class Platform {
public:
    virtual ~Platform() = default;
    virtual bool init() = 0;
    virtual void shutdown() = 0;
    virtual bool running() = 0;                   // false once the system asks us to exit
    virtual Input poll() = 0;                     // also paces the loop (~60 Hz)
    virtual void present(const gfx::Canvas& c) = 0;
    virtual const uint8_t* fontData(size_t& size) = 0;
    virtual std::string dataRoot() = 0;           // where boxes/backups live, e.g. "sdmc:/switch/openhome-nx"
    virtual std::string sdRoot() = 0;             // root for the SD card search, e.g. "sdmc:/"
    virtual std::string assetPath(const std::string& rel) = 0;  // e.g. "romfs:/sprites/25.png"
};

#ifdef __SWITCH__
Platform* create();
#endif

}  // namespace plat
