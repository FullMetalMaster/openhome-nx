#ifdef __SWITCH__
#include <switch.h>

#include <cstring>

#include "platform/platform.hpp"

namespace plat {

class SwitchPlatform : public Platform {
public:
    bool init() override {
        romfsInit();  // sprites live in romfs; the app still runs (with placeholders) if this fails
        plInitialize(PlServiceType_User);
        plOk_ = R_SUCCEEDED(plGetSharedFontByType(&font_, PlSharedFontType_Standard));

        padConfigureInput(1, HidNpadStyleSet_NpadStandard);
        padInitializeDefault(&pad_);
        hidInitializeTouchScreen();

        NWindow* win = nwindowGetDefault();
        framebufferCreate(&fb_, win, 1280, 720, PIXEL_FORMAT_RGBA_8888, 2);
        framebufferMakeLinear(&fb_);
        fbOk_ = true;
        return plOk_;
    }

    void shutdown() override {
        if (fbOk_) framebufferClose(&fb_);
        plExit();
        romfsExit();
    }

    bool running() override { return appletMainLoop(); }

    Input poll() override {
        Input in;
        padUpdate(&pad_);
        u64 d = padGetButtonsDown(&pad_), h = padGetButtons(&pad_);
        auto map = [](u64 v) {
            uint32_t o = 0;
            if (v & HidNpadButton_A) o |= A;
            if (v & HidNpadButton_B) o |= B;
            if (v & HidNpadButton_X) o |= X;
            if (v & HidNpadButton_Y) o |= Y;
            if (v & HidNpadButton_L) o |= L;
            if (v & HidNpadButton_R) o |= R;
            if (v & HidNpadButton_ZL) o |= ZL;
            if (v & HidNpadButton_ZR) o |= ZR;
            if (v & HidNpadButton_Plus) o |= Plus;
            if (v & HidNpadButton_Minus) o |= Minus;
            if (v & (HidNpadButton_Up | HidNpadButton_StickLUp)) o |= Up;
            if (v & (HidNpadButton_Down | HidNpadButton_StickLDown)) o |= Down;
            if (v & (HidNpadButton_Left | HidNpadButton_StickLLeft)) o |= Left;
            if (v & (HidNpadButton_Right | HidNpadButton_StickLRight)) o |= Right;
            return o;
        };
        in.down = map(d);
        in.held = map(h);

        HidTouchScreenState ts = {0};
        bool now = hidGetTouchScreenStates(&ts, 1) && ts.count > 0;
        if (now) {
            in.tx = (int)ts.touches[0].x;
            in.ty = (int)ts.touches[0].y;
        }
        in.touching = now;
        in.touchBegan = now && !wasTouching_;
        wasTouching_ = now;
        return in;
    }

    void present(const gfx::Canvas& c) override {
        u32 stride = 0;
        u8* dst = (u8*)framebufferBegin(&fb_, &stride);
        const uint32_t* src = c.pixels();
        for (int y = 0; y < c.height(); y++)
            std::memcpy(dst + (size_t)y * stride, src + (size_t)y * c.width(), (size_t)c.width() * 4);
        framebufferEnd(&fb_);
    }

    const uint8_t* fontData(size_t& size) override {
        size = plOk_ ? font_.size : 0;
        return plOk_ ? (const uint8_t*)font_.address : nullptr;
    }
    std::string dataRoot() override { return "sdmc:/switch/openhome-nx"; }
    std::string sdRoot() override { return "sdmc:/"; }
    std::string assetPath(const std::string& rel) override { return "romfs:/" + rel; }

private:
    PadState pad_;
    Framebuffer fb_;
    PlFontData font_;
    bool plOk_ = false, fbOk_ = false, wasTouching_ = false;
};

Platform* create() {
    static SwitchPlatform p;
    return &p;
}

}  // namespace plat
#endif  // __SWITCH__
