// OpenHome NX user interface: Home (bank/box grid), Find Saves (console + SD card), Settings.
// Everything is drawn with the software renderer in gfx/ and driven by plat::Input, so the same
// code runs on the Switch and in the desktop preview harness.
#include "ui/app.hpp"

#include <algorithm>
#include <cstdio>
#include <functional>
#include <map>
#include <memory>
#include <string>
#include <vector>

#include "box/boxstore.hpp"
#include "box/fsutil.hpp"
#include "gfx/canvas.hpp"
#include "pkm/species.hpp"
#include "save/gamedb.hpp"
#include "save/savemount.hpp"
#include "save/savefile.hpp"
#include "save/sdscan.hpp"

namespace ui {
namespace {

using gfx::Align;
using gfx::Color;
using gfx::rgb;

// ------------------------------------------------------------------ theme (matches desktop OpenHome)
const Color kBg = rgb(0x58B4A8);
const Color kPanel = rgb(0xDDFADD);
const Color kCell = rgb(0xC8E8C8);
const Color kCellAlt = rgb(0xBEE0BE);
const Color kInk = rgb(0x24403A);
const Color kMuted = rgb(0x7C9A90);
const Color kAccent = rgb(0xD9534F);
const Color kHead = rgb(0x6FB0A4);
const Color kBody = rgb(0x8ECBBE);
const Color kWhite = rgb(0xFFFFFF);
const Color kShade = Color(0, 0, 0, 120);

constexpr int W = 1280, H = 720, kTabH = 48;
constexpr int kPitch = 52;  // box grid pitch

struct R {
    int x = 0, y = 0, w = 0, h = 0;
    bool in(int px, int py) const { return px >= x && py >= y && px < x + w && py < y + h; }
};

enum class Tab { Home, Saves, Settings };
const char* kTabNames[] = {"Home", "Find Saves", "Settings"};

const pkm::Format kFormats[] = {pkm::Format::PK3, pkm::Format::PK4, pkm::Format::PK5, pkm::Format::PK6,
                                pkm::Format::PK7, pkm::Format::PB7, pkm::Format::PK8, pkm::Format::PB8,
                                pkm::Format::PA8, pkm::Format::PK9};
constexpr int kFormatCount = (int)(sizeof(kFormats) / sizeof(kFormats[0]));

std::string lower(std::string s) {
    for (auto& c : s) c = (char)std::tolower((unsigned char)c);
    return s;
}

std::string fmtSize(uint64_t n) {
    char b[32];
    if (n >= (1u << 20)) std::snprintf(b, sizeof(b), "%.1f MB", n / 1048576.0);
    else std::snprintf(b, sizeof(b), "%llu KB", (unsigned long long)((n + 1023) / 1024));
    return b;
}

Color gameColor(size_t i) {
    static const Color c[] = {rgb(0xE5B93C), rgb(0xB5834E), rgb(0x3E79C4), rgb(0xC8404A), rgb(0x4A7FD0),
                              rgb(0xD070A8), rgb(0x9A8A5A), rgb(0xE05A2B), rgb(0x7A4FB0), rgb(0x2FA89A), rgb(0xD8483A), rgb(0x4FA64A)};
    return c[i % 12];
}

struct SaveMon {
    bool present = false;
    std::vector<uint8_t> bytes;  // decrypted .pkN bytes
    pkm::Info info;
};

constexpr int kSaveCols = 6;

struct Card {
    std::string title, user, status;
    Color tag;
    bool consoleSave = false;
    std::shared_ptr<save::SaveFile> sv;  // the opened save (read-only here)
    int sbox = 0;
    std::vector<SaveMon> mons;           // the Pokemon of the current save box
};

enum class Dlg { None, Confirm, Keyboard, Users, Info };

class App {
public:
    explicit App(plat::Platform& p) : P(p), cv(W, H), store(p.dataRoot()) {}

    bool init() {
        size_t n = 0;
        const uint8_t* fd = P.fontData(n);
        if (!fd || !font.init(fd, n)) return false;
        cv.setFont(&font);
        if (!store.init()) toastMsg("Could not create folders on the SD card");
        {
            // Folder for your own sprites (fakemon / re-skinned hack Pokemon). Created once, with instructions.
            std::string sd = fsu::join(P.dataRoot(), "sprites/custom");
            std::vector<uint8_t> rd;
            if (!fsu::readFile(fsu::join(sd, "README.txt"), rd, 4096)) {
                fsu::mkdirs(sd);
                static const char kTxt[] =
                    "Put your own Pokemon pictures here (PNG, square, about 96x96 or bigger, transparent background).\n\n"
                    "  25.png        replaces the sprite for National Dex #25 (re-skin hacks such as Pokemon Sweet)\n"
                    "  raw_1020.png  art for a hack-only species whose number in the save is 1020 (fakemon).\n"
                    "                The app shows the number on a placeholder tile until you add the file.\n";
                fsu::writeFile(fsu::join(sd, "README.txt"), (const uint8_t*)kTxt, sizeof(kTxt) - 1);
            }
        }
        {
            std::vector<uint8_t> b;
            if (fsu::readFile(fsu::join(P.dataRoot(), "gen3species.txt"), b, 64)) {
                std::string v(b.begin(), b.end());
                save::setGen3Species(v == "Vanilla" ? save::Gen3Species::Vanilla
                                     : v == "Expansion" ? save::Gen3Species::Expansion
                                     : v == "Cfru" ? save::Gen3Species::Cfru : save::Gen3Species::Auto);
            }
        }
        reload();
        return true;
    }

    void update(const plat::Input& in);
    void draw();
    const gfx::Canvas& canvas() const { return cv; }

    bool quit = false;
    bool dirty = true;

private:
    plat::Platform& P;
    gfx::Canvas cv;
    gfx::Font font;
    box::Store store;

    Tab tab = Tab::Home;

    // ---- Home state
    int bank = 0, boxIdx = 0, cx = 0, cy = 0;
    std::vector<box::Slot> slots;
    int at[box::kSlotsPerBox];
    bool holding = false;
    box::Slot held;
    std::string fSpecies;
    int fFormat = 0;  // 0 = any
    std::vector<Card> cards;
    bool saveFocus = false;          // cursor is on the save panel instead of the bank
    int scx = 0, scy = 0;
    bool heldFromSave = false;       // the held Pokemon is a copy taken from a save
    std::vector<uint8_t> heldBytes;
    box::Slot saveTmp;

    // ---- Saves state
    int gameSel = 0, scanSel = 0, browseSel = 0;
    bool rightFocus = false, browseMode = false;
    save::Scanner scanner;
    bool scanned = false;
    std::string browsePath;
    std::vector<fsu::Entry> browseEntries;

    // ---- Settings state
    int setSel = 0;

    // ---- dialogs / toast
    Dlg dlg = Dlg::None;
    std::string dlgTitle, dlgText;
    std::function<void()> onYes;
    std::string kbText;
    int kbRow = 1, kbCol = 0;
    std::function<void(const std::string&)> onKb;
    std::vector<save::User> users;
    int userSel = 0;
    int pendingGame = -1;
    std::string toast;
    int toastLeft = 0;

    std::map<int, gfx::Image> sprites;

    // ------------------------------------------------------------ helpers
    void toastMsg(const std::string& s) { toast = s; toastLeft = 240; dirty = true; }

    void reload() {
        for (int& v : at) v = -1;
        slots = store.load(bank, boxIdx);
        for (size_t i = 0; i < slots.size(); i++) at[slots[i].index] = (int)i;
        dirty = true;
    }

    const box::Slot* slotAt(int c, int r) const {
        int i = at[r * box::kCols + c];
        return i >= 0 ? &slots[(size_t)i] : nullptr;
    }

    // Your own art wins: sdmc:/switch/openhome-nx/sprites/custom/<dex>.png replaces an official sprite (re-skin hacks such
    // as Pokemon Sweet), and raw_<number>.png supplies art for hack-only species that have no National Dex number.
    const gfx::Image* spriteKey(int key, const std::string& customName, const std::string& builtin) {
        auto it = sprites.find(key);
        if (it == sprites.end()) {
            gfx::Image im = gfx::loadPng(P.dataRoot() + "/sprites/custom/" + customName + ".png");
            if (im.empty() && !builtin.empty()) im = gfx::loadPng(P.assetPath(builtin));
            it = sprites.emplace(key, std::move(im)).first;
        }
        return it->second.empty() ? nullptr : &it->second;
    }
    const gfx::Image* sprite(int dex) { return spriteKey(dex, std::to_string(dex), "sprites/" + std::to_string(dex) + ".png"); }
    const gfx::Image* spriteRaw(int raw) { return spriteKey(100000 + raw, "raw_" + std::to_string(raw), ""); }

    bool matches(const box::Slot& s) const {
        if (fFormat > 0 && s.info.format != kFormats[fFormat - 1]) return false;
        if (!fSpecies.empty()) {
            std::string q = lower(fSpecies);
            std::string name = lower(species::name(s.info.species));
            std::string nick = lower(pkm::utf16ToUtf8(s.info.nickname));
            if (name.find(q) == std::string::npos && nick.find(q) == std::string::npos) return false;
        }
        return true;
    }
    bool filterActive() const { return fFormat > 0 || !fSpecies.empty(); }

    std::string displayName(const box::Slot& s) const {
        std::string nick = pkm::utf16ToUtf8(s.info.nickname);
        if (!nick.empty()) return nick;
        if (s.info.rawSpecies) return "Hack species #" + std::to_string(s.info.rawSpecies);
        return s.info.species ? species::name(s.info.species) : "Unknown Pokemon";
    }

    std::vector<std::string> wrap(const std::string& text, int px, int maxW) {
        std::vector<std::string> out;
        std::string line, word;
        auto flush = [&]() {
            if (line.empty()) { line = word; }
            else if (cv.textWidth(line + " " + word, px) <= maxW) line += " " + word;
            else { out.push_back(line); line = word; }
            word.clear();
        };
        for (char ch : text + " ") {
            if (ch == '\n') { if (!word.empty()) flush(); out.push_back(line); line.clear(); }
            else if (ch == ' ') { if (!word.empty()) flush(); }
            else word.push_back(ch);
        }
        if (!line.empty()) out.push_back(line);
        return out;
    }

    void info(const std::string& title, const std::string& text) {
        dlg = Dlg::Info; dlgTitle = title; dlgText = text; dirty = true;
    }
    void confirm(const std::string& title, const std::string& text, std::function<void()> yes) {
        dlg = Dlg::Confirm; dlgTitle = title; dlgText = text; onYes = std::move(yes); dirty = true;
    }
    void keyboard(const std::string& title, const std::string& initial, std::function<void(const std::string&)> cb) {
        dlg = Dlg::Keyboard; dlgTitle = title; kbText = initial; kbRow = 1; kbCol = 0; onKb = std::move(cb); dirty = true;
    }

    // ------------------------------------------------------------ layout rects
    R tabR(int i) const { return {20 + i * 160, H - kTabH, 150, kTabH}; }
    R bankSwitchR() const { return {332, 12, 130, 30}; }
    R addBankR() const { return {824, 12, 132, 30}; }
    R sortR() const { return {336, 56, 84, 30}; }
    R prevBoxR() const { return {540, 54, 40, 34}; }
    R nextBoxR() const { return {708, 54, 40, 34}; }
    R cellR(int c, int r) const { return {332 + c * kPitch, 98 + r * kPitch, kPitch, kPitch}; }
    R fSpeciesR() const { return {988, 54, 268, 36}; }
    R fFormatR() const { return {988, 98, 268, 36}; }
    R fClearR() const { return {1156, 12, 100, 28}; }
    R releaseR() const { return {988, 530, 268, 124}; }
    R addSaveR(int y) const { return {12, y, 300, 40}; }
    R cardCellR(int c, int r) const { return {22 + c * 44, 80 + r * 44, 44, 44}; }
    R cardPrevR() const { return {20, 42, 40, 28}; }
    R cardNextR() const { return {264, 42, 40, 28}; }

    // ------------------------------------------------------------ drawing primitives
    void panel(const R& r, Color c = kPanel) { cv.fillRoundRect(r.x, r.y, r.w, r.h, 8, c); }

    void button(const R& r, const std::string& label, bool enabled = true, bool primary = false) {
        Color fill = primary ? kAccent : rgb(0xE9FCE9);
        Color ink = primary ? kWhite : kInk;
        if (!enabled) { fill = rgb(0xD3E6D3); ink = kMuted; }
        cv.fillRoundRect(r.x, r.y, r.w, r.h, 6, fill);
        if (!primary) cv.strokeRoundRect(r.x, r.y, r.w, r.h, 6, 1, rgb(0xA9CFC3));
        cv.text(label, 16, r.x + r.w / 2, r.y + (r.h - 18) / 2, ink, Align::Center, r.w - 8);
    }

    void field(const R& r, const std::string& label, const std::string& value) {
        cv.fillRoundRect(r.x, r.y, r.w, r.h, 6, rgb(0xF2FDF2));
        cv.strokeRoundRect(r.x, r.y, r.w, r.h, 6, 1, rgb(0xA9CFC3));
        if (value.empty()) cv.text(label, 16, r.x + 12, r.y + 9, kMuted, Align::Left, r.w - 40);
        else cv.text(value, 16, r.x + 12, r.y + 9, kInk, Align::Left, r.w - 40);
        cv.text("v", 14, r.x + r.w - 16, r.y + 10, kMuted, Align::Center);
    }

    void sectionHeader(const R& r, const std::string& title) {
        cv.fillRoundRect(r.x, r.y, r.w, 30, 8, kHead);
        cv.fillRect(r.x, r.y + 20, r.w, 10, kHead);
        cv.text(title, 17, r.x + r.w / 2, r.y + 5, kWhite, Align::Center);
    }

    void drawSprite(int dex, const R& r, int pad, uint8_t alpha = 255) {
        const gfx::Image* im = sprite(dex);
        if (im) cv.drawImage(*im, r.x + pad, r.y + pad, r.w - 2 * pad, r.h - 2 * pad, alpha);
        else {
            cv.fillRoundRect(r.x + pad + 6, r.y + pad + 6, r.w - 2 * pad - 12, r.h - 2 * pad - 12, 6, kBody.alpha(alpha));
            cv.text("#" + std::to_string(dex), 13, r.x + r.w / 2, r.y + r.h / 2 - 8, kInk.alpha(alpha), Align::Center);
        }
    }

    // Draws a Pokemon: its sprite, or for hack-only species (fakemon) the user's own raw_<n>.png, or a tinted placeholder tile.
    void drawMon(const pkm::Info& in, const R& r, int pad, uint8_t alpha = 255) {
        if (in.species) { drawSprite(in.species, r, pad, alpha); return; }
        if (!in.rawSpecies) return;
        if (const gfx::Image* im = spriteRaw(in.rawSpecies)) { cv.drawImage(*im, r.x + pad, r.y + pad, r.w - 2 * pad, r.h - 2 * pad, alpha); return; }
        uint32_t h = (uint32_t)in.rawSpecies * 2654435761u;
        Color tint = rgb(0x9FB8D8 + ((h >> 3) & 0x1F1F1F) % 0x303030);
        int w = r.w - 2 * pad - 8, hh = r.h - 2 * pad - 8;
        cv.fillRoundRect(r.x + pad + 4, r.y + pad + 4, w, hh, 8, tint.alpha(alpha));
        cv.strokeRoundRect(r.x + pad + 4, r.y + pad + 4, w, hh, 8, 2, kInk.alpha(alpha / 2));
        int big = std::max(12, std::min(22, r.w / 4));
        cv.text("?", big + 4, r.x + r.w / 2, r.y + r.h / 2 - big - 2, kInk.alpha(alpha), Align::Center);
        cv.text("#" + std::to_string(in.rawSpecies), std::max(10, big - 6), r.x + r.w / 2, r.y + r.h / 2 + 4, kInk.alpha(alpha), Align::Center);
    }

    // ------------------------------------------------------------ Home
    void drawHome();
    void drawCards();
    void drawBank();
    void drawRight();
    void updateHome(const plat::Input& in);
    void pressA();
    void cursorMove(int dx, int dy);
    void changeBox(int d);
    void askRelease();

    // ------------------------------------------------------------ Saves
    void drawSaves();
    void updateSaves(const plat::Input& in);
    void startScan();
    void startMount(int gi);
    void doMount(int gi);
    void openBrowse(const std::string& path);
    void openUsers();
    void addCard(const Card& c) { cards.push_back(c); dirty = true; }
    void loadCardBox(Card& c);
    void changeSaveBox(int d);
    const SaveMon* curSaveMon() const;
    bool saveReady() const { return !cards.empty() && cards[0].sv; }
    void savePress();
    void openSdSave(const std::string& path);
    void finishOpen(std::shared_ptr<save::SaveFile> sv, const std::string& title, const std::string& user, Color tag,
                    bool consoleSave, const std::string& status);
    void browseActivate();
    void scanActivate();

    // ------------------------------------------------------------ Settings
    void drawSettings();
    void updateSettings(const plat::Input& in);
    void settingsActivate();

    // ------------------------------------------------------------ dialogs
    void drawDialog();
    void updateDialog(const plat::Input& in);
    R kbKeyR(int row, int col) const;
    int kbRowLen(int row) const;
    std::string kbKey(int row, int col) const;
    void kbPress();
};

// ==================================================================== update
void App::update(const plat::Input& in) {
    if (toastLeft > 0 && --toastLeft == 0) dirty = true;
    if (scanner.running()) { scanner.step(6); dirty = true; }
    if (in.down || in.touchBegan) dirty = true;

    if (dlg != Dlg::None) { updateDialog(in); return; }

    if (in.down & plat::Plus) { quit = true; return; }
    if (in.down & plat::ZR) tab = (Tab)(((int)tab + 1) % 3);
    if (in.down & plat::ZL) tab = (Tab)(((int)tab + 2) % 3);
    if (in.touchBegan)
        for (int i = 0; i < 3; i++)
            if (tabR(i).in(in.tx, in.ty)) tab = (Tab)i;

    switch (tab) {
        case Tab::Home: updateHome(in); break;
        case Tab::Saves: updateSaves(in); break;
        case Tab::Settings: updateSettings(in); break;
    }
}

// ==================================================================== draw
void App::draw() {
    cv.clearClip();
    cv.clear(kBg);
    switch (tab) {
        case Tab::Home: drawHome(); break;
        case Tab::Saves: drawSaves(); break;
        case Tab::Settings: drawSettings(); break;
    }

    // tab bar
    cv.fillRect(0, H - kTabH, W, kTabH, kPanel);
    for (int i = 0; i < 3; i++) {
        R r = tabR(i);
        bool on = (int)tab == i;
        cv.text(kTabNames[i], 18, r.x + r.w / 2, r.y + 13, on ? kInk : kMuted, Align::Center);
        if (on) cv.fillRect(r.x + 14, r.y + r.h - 3, r.w - 28, 3, kAccent);
    }
    std::string hint;
    if (tab == Tab::Home)
        hint = holding ? "A Place   B Cancel   X Release   L/R Box   +  Quit"
                       : "A Pick up   X Release   Y Filter   -  Sort   L/R Box   ZL/ZR Tabs";
    else if (tab == Tab::Saves) hint = "A Select   Y User   X Scan   L/R Scan/Browse   B Up   ZL/ZR Tabs";
    else hint = "A Select   ZL/ZR Tabs   +  Quit";
    cv.text(hint, 14, W - 16, H - kTabH + 16, kMuted, Align::Right, 700);

    if (toastLeft > 0 && !toast.empty()) {
        int tw = std::min(900, cv.textWidth(toast, 17) + 40);
        cv.fillRoundRect(W / 2 - tw / 2, H - kTabH - 54, tw, 38, 19, kInk.alpha(235));
        cv.text(toast, 17, W / 2, H - kTabH - 45, kWhite, Align::Center, tw - 30);
    }
    if (dlg != Dlg::None) drawDialog();
}

// ==================================================================== Home
namespace {
constexpr int kMaxCards = 4;
}

void App::drawHome() {
    drawCards();
    drawBank();
    drawRight();
}

void App::drawCards() {
    if (cards.empty()) {
        R r{12, 8, 300, 190};
        panel(r);
        cv.text("No saves added yet", 19, r.x + r.w / 2, r.y + 22, kInk, Align::Center);
        int y = r.y + 58;
        for (const auto& l : wrap("Add a game save from the console or find one on your SD card to see it here next to your bank.", 15, 260)) {
            cv.text(l, 15, r.x + r.w / 2, y, kMuted, Align::Center);
            y += 20;
        }
        button({32, 142, 260, 40}, "+ Add a save", true, true);
        return;
    }
    int n = (int)std::min<size_t>(cards.size(), kMaxCards);
    for (int i = 0; i < n; i++) {
        const Card& c = cards[(size_t)i];
        bool full = i == 0;
        R r = full ? R{12, 8, 300, 300} : R{12, 316 + (i - 1) * 80, 300, 72};
        panel(r);
        cv.fillRoundRect(r.x + 10, r.y + 10, 24, 24, 5, kAccent);
        cv.text("x", 17, r.x + 22, r.y + 12, kWhite, Align::Center);
        int tw = std::min(150, cv.textWidth(c.title, 16) + 20);
        cv.fillRoundRect(r.x + 40, r.y + 10, tw, 24, 5, c.tag);
        cv.text(c.title, 16, r.x + 40 + tw / 2, r.y + 13, kWhite, Align::Center, tw - 8);
        cv.text(c.user, 16, r.x + 48 + tw, r.y + 13, kInk, Align::Left, r.w - 60 - tw);
        if (full && c.sv) {
            button(cardPrevR(), "<");
            button(cardNextR(), ">");
            char t[48];
            std::snprintf(t, sizeof(t), "%s", c.sv->boxName(c.sbox).c_str());
            cv.text(t, 17, r.x + r.w / 2, r.y + 44, kInk, Align::Center, 190);
            int slots = c.sv->boxSlots();
            int rows = (slots + kSaveCols - 1) / kSaveCols;
            for (int gy = 0; gy < rows; gy++)
                for (int gx = 0; gx < kSaveCols; gx++) {
                    int idx = gy * kSaveCols + gx;
                    if (idx >= slots) continue;
                    R cr = cardCellR(gx, gy);
                    cv.fillRoundRect(cr.x + 1, cr.y + 1, cr.w - 2, cr.h - 2, 5, ((gx + gy) & 1) ? kCellAlt : kCell);
                    if (idx < (int)c.mons.size() && c.mons[(size_t)idx].present) {
                        const pkm::Info& pi = c.mons[(size_t)idx].info;
                        if (pi.species || pi.rawSpecies) drawMon(pi, cr, 2);
                        else cv.text("?", 16, cr.x + cr.w / 2, cr.y + 12, kMuted, Align::Center);
                    }
                }
            if (saveFocus) {
                R cr = cardCellR(scx, scy);
                cv.strokeRoundRect(cr.x, cr.y, cr.w, cr.h, 6, 3, kAccent);
            }
        } else if (full) {
            R plate{r.x + 12, r.y + 50, r.w - 24, 230};
            cv.fillRoundRect(plate.x, plate.y, plate.w, plate.h, 8, kPanel.alpha(240));
            int y = plate.y + 12;
            for (const auto& l : wrap(c.status, 14, plate.w - 24)) { cv.text(l, 14, plate.x + 12, y, kInk); y += 19; }
        } else {
            int y = r.y + 40;
            int lines = 0;
            for (const auto& l : wrap(c.status, 13, r.w - 24)) {
                if (lines++ == 2) break;
                cv.text(l, 13, r.x + 12, y, kMuted, Align::Left, r.w - 24);
                y += 17;
            }
        }
    }
    if (cards.size() < (size_t)kMaxCards) button(addSaveR(316 + (n - 1) * 80), "+ Add a save");
}

void App::loadCardBox(Card& c) {
    c.mons.clear();
    if (!c.sv) return;
    int slots = c.sv->boxSlots();
    c.mons.resize((size_t)slots);
    for (int i = 0; i < slots; i++) {
        SaveMon& m = c.mons[(size_t)i];
        if (!c.sv->readBox(c.sbox, i, m.bytes)) continue;
        m.info = c.sv->describe(m.bytes);
        m.present = true;
    }
    dirty = true;
}

void App::changeSaveBox(int d) {
    if (!saveReady()) return;
    Card& c = cards[0];
    int n = c.sv->boxCount();
    if (n <= 0) return;
    c.sbox = (c.sbox + d + n) % n;
    loadCardBox(c);
}

const SaveMon* App::curSaveMon() const {
    if (!saveReady()) return nullptr;
    size_t i = (size_t)(scy * kSaveCols + scx);
    const Card& c = cards[0];
    return i < c.mons.size() && c.mons[i].present ? &c.mons[i] : nullptr;
}

// Press A on the save panel: take a COPY of the Pokemon (the save itself is never changed).
void App::savePress() {
    if (holding) { holding = false; dirty = true; return; }
    const SaveMon* m = curSaveMon();
    if (!m) return;
    std::vector<uint8_t> exp;
    std::string why;
    if (!cards[0].sv->exportMon(m->bytes, exp, why)) { toastMsg(why.empty() ? "This Pokemon can't be copied" : why); return; }
    held = box::Slot();
    held.info = pkm::parse(cards[0].sv->format(), exp.data(), exp.size());
    if (!held.info.valid) held.info = m->info;
    std::string base = m->info.species ? species::name(m->info.species) : "Pokemon";
    held.fileName = base + "." + pkm::formatExt(cards[0].sv->format());
    heldBytes = exp;
    heldFromSave = true;
    holding = true;
    dirty = true;
}

void App::finishOpen(std::shared_ptr<save::SaveFile> sv, const std::string& title, const std::string& user, Color tag,
                     bool consoleSave, const std::string& status) {
    Card c;
    c.title = title;
    c.user = user;
    c.tag = tag;
    c.consoleSave = consoleSave;
    c.status = status;
    c.sv = std::move(sv);
    loadCardBox(c);
    cards.insert(cards.begin(), std::move(c));  // newest save goes to the big panel
    if (cards.size() > (size_t)kMaxCards) cards.pop_back();
    saveFocus = false;
    scx = scy = 0;
    tab = Tab::Home;
    dirty = true;
}

void App::openSdSave(const std::string& path) {
    std::vector<uint8_t> buf;
    if (!fsu::readFile(path, buf, 32u << 20)) { toastMsg("Could not read " + fsu::baseName(path)); return; }
    std::string err;
    auto sv = save::open(buf, fsu::baseName(path), nullptr, err);
    if (!sv) {
        info("Cannot open this save", fsu::baseName(path) + "\n\n" + err);
        return;
    }
    std::string st = sv->notes();
    finishOpen(std::shared_ptr<save::SaveFile>(std::move(sv)), "SD save", fsu::baseName(path), rgb(0x6A8F86), false, st);
    toastMsg("Opened " + fsu::baseName(path));
}

void App::drawBank() {
    panel({324, 8, 640, 36});
    button(bankSwitchR(), "Switch Bank");
    cv.text(store.bankCount() ? store.bankName(bank) : "Bank 1", 22, 644, 12, kInk, Align::Center);
    button(addBankR(), "+ New Bank");

    R box{324, 48, 640, 616};
    panel(box);
    button(sortR(), "Sort");
    char t[24];
    std::snprintf(t, sizeof(t), "Box %02d", boxIdx + 1);
    button(prevBoxR(), "<");
    button(nextBoxR(), ">");
    cv.text(t, 21, 644, 56, kInk, Align::Center);
    std::snprintf(t, sizeof(t), "%d / %d", (int)slots.size(), box::kSlotsPerBox);
    cv.text(t, 15, 952, 62, kMuted, Align::Right);

    for (int r = 0; r < box::kRows; r++) {
        for (int c = 0; c < box::kCols; c++) {
            R cr = cellR(c, r);
            cv.fillRoundRect(cr.x + 2, cr.y + 2, kPitch - 4, kPitch - 4, 6, ((c + r) & 1) ? kCellAlt : kCell);
            const box::Slot* s = slotAt(c, r);
            if (!s) continue;
            bool isHeld = holding && s->path == held.path;
            uint8_t a = isHeld ? 70 : (filterActive() && !matches(*s)) ? 55 : 255;
            if (s->info.species || s->info.rawSpecies) drawMon(s->info, cr, 2, a);
            else {
                cv.text(pkm::formatName(s->info.format), 14, cr.x + kPitch / 2, cr.y + 17, kMuted.alpha(a), Align::Center);
            }
        }
    }
    // cursor + held Pokemon
    R cr = cellR(cx, cy);
    if (!saveFocus) {
        if (holding && (held.info.species || held.info.rawSpecies)) drawMon(held.info, {cr.x - 4, cr.y - 8, kPitch + 8, kPitch + 8}, 1, 235);
        cv.strokeRoundRect(cr.x, cr.y, kPitch, kPitch, 7, 3, kAccent);
    }

    std::string foot;
    if (holding) foot = std::string(heldFromSave ? "Copying " : "Holding ") + displayName(held) + " - move to an empty slot and press A";
    else if (saveFocus) foot = "Save panel: A copies the Pokemon into your bank";
    else if (const box::Slot* s = slotAt(cx, cy)) foot = displayName(*s);
    else foot = "Empty slot " + std::to_string(cy * box::kCols + cx + 1);
    cv.text(foot, 16, 644, 630, holding ? kAccent : kMuted, Align::Center, 600);
}

void App::drawRight() {
    // Filter
    R f{976, 8, 292, 176};
    panel(f);
    cv.text("Filter", 21, 988, 12, kInk);
    button(fClearR(), "Clear All", filterActive());
    field(fSpeciesR(), "Species / nickname", fSpecies);
    field(fFormatR(), "Game format", fFormat ? pkm::formatName(kFormats[fFormat - 1]) : "");
    int shown = 0;
    for (const auto& s : slots) shown += matches(s) ? 1 : 0;
    char t[48];
    std::snprintf(t, sizeof(t), "Showing %d of %d in this box", shown, (int)slots.size());
    cv.text(t, 15, 988, 150, kMuted);

    // Preview
    R pv{976, 192, 292, 290};
    panel(pv, kBody);
    sectionHeader(pv, "Preview");
    const box::Slot* sel = holding ? &held : slotAt(cx, cy);
    if (!holding && saveFocus) {
        if (const SaveMon* m = curSaveMon()) {
            saveTmp = box::Slot();
            saveTmp.info = m->info;
            saveTmp.fileName = m->info.species ? species::name(m->info.species) : m->info.rawSpecies ? "Hack species #" + std::to_string(m->info.rawSpecies) : "Pokemon";
            sel = &saveTmp;
        } else sel = nullptr;
    }
    if (sel) {
        if (sel->info.species || sel->info.rawSpecies) drawMon(sel->info, {pv.x + 90, pv.y + 40, 112, 112}, 0);
        cv.text(displayName(*sel), 21, pv.x + pv.w / 2, pv.y + 160, kInk, Align::Center, 270);
        char l[80];
        if (sel->info.species) {
            std::snprintf(l, sizeof(l), "#%03d  %s", sel->info.species, species::name(sel->info.species));
            cv.text(l, 16, pv.x + pv.w / 2, pv.y + 190, kInk, Align::Center, 270);
        } else if (sel->info.rawSpecies) {
            cv.text("Hack species #" + std::to_string(sel->info.rawSpecies) + " (no official art)", 15, pv.x + pv.w / 2, pv.y + 190, kInk, Align::Center, 270);
            cv.text("Add sprites/custom/raw_" + std::to_string(sel->info.rawSpecies) + ".png", 12, pv.x + pv.w / 2, pv.y + 262, kMuted, Align::Center, 270);
        } else {
            cv.text("Details need a decryptor (coming soon)", 14, pv.x + pv.w / 2, pv.y + 190, kInk, Align::Center, 270);
        }
        std::string ot = pkm::utf16ToUtf8(sel->info.otName);
        cv.text(std::string("Format ") + pkm::formatName(sel->info.format) + (ot.empty() ? "" : "   OT " + ot), 15,
                pv.x + pv.w / 2, pv.y + 216, kInk, Align::Center, 270);
        std::string rest;
        box::parseSlotPrefix(sel->fileName, &rest);
        cv.text(rest.empty() ? sel->fileName : rest, 13, pv.x + pv.w / 2, pv.y + 246, kMuted, Align::Center, 270);
    } else {
        cv.text("Move the cursor over a Pokemon", 15, pv.x + pv.w / 2, pv.y + 130, kInk.alpha(170), Align::Center);
    }

    // Release
    R rl{976, 490, 292, 174};
    panel(rl, kBody);
    sectionHeader(rl, "Release");
    int y = rl.y + 42;
    for (const auto& l : wrap("Press X (or tap the button) to release the selected Pokemon. The file moves to the 'released' folder, so it can be restored.", 14, 262)) {
        cv.text(l, 14, rl.x + 15, y, kInk);
        y += 19;
    }
    button({1000, 606, 244, 42}, "Release", sel != nullptr, true);
}

void App::cursorMove(int dx, int dy) {
    cx = std::max(0, std::min(box::kCols - 1, cx + dx));
    cy = std::max(0, std::min(box::kRows - 1, cy + dy));
    dirty = true;
}

void App::changeBox(int d) {
    boxIdx = (boxIdx + d + box::kBoxesPerBank) % box::kBoxesPerBank;
    reload();
}

void App::pressA() {
    const box::Slot* t = slotAt(cx, cy);
    if (!holding) {
        if (t) { held = *t; holding = true; heldFromSave = false; }
        dirty = true;
        return;
    }
    if (heldFromSave) {  // placing a copy taken from a save
        if (t) { toastMsg("That slot is taken - pick an empty one"); return; }
        std::string out = store.add(bank, boxIdx, held.fileName, heldBytes.data(), heldBytes.size(), cy * box::kCols + cx);
        holding = false;
        heldFromSave = false;
        reload();
        toastMsg(out.empty() ? "Could not copy (SD card error)" : "Copied into " + store.bankName(bank) + ", Box " + std::to_string(boxIdx + 1));
        return;
    }
    if (t && t->path == held.path) { holding = false; dirty = true; return; }
    bool ok = t ? store.swap(held, *t) : store.move(held, bank, boxIdx, cy * box::kCols + cx);
    holding = false;
    reload();
    toastMsg(ok ? "Moved" : "Could not move the file (SD card error)");
}

void App::askRelease() {
    if (holding && heldFromSave) { toastMsg("This is a copy from a save - nothing to release"); return; }
    if (saveFocus) return;
    const box::Slot* t = holding ? &held : slotAt(cx, cy);
    if (!t) return;
    box::Slot s = *t;
    std::string name = displayName(s);
    confirm("Release " + name + "?", "The file is moved to the 'released' folder on your SD card, so you can restore it later.", [this, s, name]() {
        bool ok = store.release(s);
        holding = false;
        reload();
        toastMsg(ok ? name + " was released" : "Could not release (SD card error)");
    });
}

void App::updateHome(const plat::Input& in) {
    if (saveFocus && !saveReady()) saveFocus = false;
    if (saveFocus) {
        const Card& c = cards[0];
        int rows = (c.sv->boxSlots() + kSaveCols - 1) / kSaveCols;
        if (in.down & plat::Left) scx = std::max(0, scx - 1);
        if (in.down & plat::Right) { if (scx < kSaveCols - 1) scx++; else saveFocus = false; }
        if (in.down & plat::Up) scy = std::max(0, scy - 1);
        if (in.down & plat::Down) scy = std::min(rows - 1, scy + 1);
        if (in.down & plat::L) changeSaveBox(-1);
        if (in.down & plat::R) changeSaveBox(1);
        if (in.down & plat::A) savePress();
        dirty = true;
    } else {
        if (in.down & plat::Left) { if (cx == 0 && saveReady()) saveFocus = true; else cursorMove(-1, 0); }
        if (in.down & plat::Right) cursorMove(1, 0);
        if (in.down & plat::Up) cursorMove(0, -1);
        if (in.down & plat::Down) cursorMove(0, 1);
        if (in.down & plat::L) changeBox(-1);
        if (in.down & plat::R) changeBox(1);
        if (in.down & plat::A) pressA();
    }
    if ((in.down & plat::B) && holding) { holding = false; dirty = true; }
    if (in.down & plat::X) askRelease();
    if (in.down & plat::Y) keyboard("Filter by species or nickname", fSpecies, [this](const std::string& s) { fSpecies = s; dirty = true; });
    if (in.down & plat::Minus) {
        bool ok = store.sortBox(bank, boxIdx);
        reload();
        toastMsg(ok ? "Box sorted by Pokedex number" : "Could not sort this box");
    }
    if (!in.touchBegan) return;

    int tx = in.tx, ty = in.ty;
    for (int r = 0; r < box::kRows; r++)
        for (int c = 0; c < box::kCols; c++)
            if (cellR(c, r).in(tx, ty)) {
                bool same = c == cx && r == cy && !saveFocus;
                saveFocus = false;
                cx = c; cy = r;
                if (same || holding) pressA();
                dirty = true;
            }
    if (saveReady()) {
        const Card& c0 = cards[0];
        int slots = c0.sv->boxSlots();
        for (int i = 0; i < slots; i++) {
            int gx = i % kSaveCols, gy = i / kSaveCols;
            if (cardCellR(gx, gy).in(tx, ty)) {
                bool same = saveFocus && scx == gx && scy == gy;
                saveFocus = true; scx = gx; scy = gy;
                if (same || holding) savePress();
                dirty = true;
            }
        }
        if (cardPrevR().in(tx, ty)) changeSaveBox(-1);
        if (cardNextR().in(tx, ty)) changeSaveBox(1);
    }
    if (prevBoxR().in(tx, ty)) changeBox(-1);
    if (nextBoxR().in(tx, ty)) changeBox(1);
    if (bankSwitchR().in(tx, ty) && store.bankCount() > 0) { bank = (bank + 1) % store.bankCount(); reload(); }
    if (addBankR().in(tx, ty)) { toastMsg(store.addBank() ? "Created " + store.bankName(store.bankCount() - 1) : "Could not create a bank"); }
    if (sortR().in(tx, ty)) { bool ok = store.sortBox(bank, boxIdx); reload(); toastMsg(ok ? "Box sorted by Pokedex number" : "Could not sort this box"); }
    if (fSpeciesR().in(tx, ty)) keyboard("Filter by species or nickname", fSpecies, [this](const std::string& s) { fSpecies = s; dirty = true; });
    if (fFormatR().in(tx, ty)) fFormat = (fFormat + 1) % (kFormatCount + 1);
    if (fClearR().in(tx, ty)) { fSpecies.clear(); fFormat = 0; }
    if (R{1000, 606, 244, 42}.in(tx, ty)) askRelease();
    // cards: close buttons and "add a save"
    if (cards.empty()) {
        if (R{32, 142, 260, 40}.in(tx, ty)) tab = Tab::Saves;
    } else {
        int n = (int)std::min<size_t>(cards.size(), kMaxCards);
        for (int i = 0; i < n; i++) {
            R r = i == 0 ? R{12, 8, 300, 300} : R{12, 316 + (i - 1) * 80, 300, 72};
            if (R{r.x + 6, r.y + 6, 32, 32}.in(tx, ty)) { cards.erase(cards.begin() + i); saveFocus = false; break; }
            if (i > 0 && r.in(tx, ty)) { std::rotate(cards.begin(), cards.begin() + i, cards.begin() + i + 1); saveFocus = false; break; }
        }
        if (cards.size() < (size_t)kMaxCards && addSaveR(316 + (n - 1) * 80).in(tx, ty)) tab = Tab::Saves;
    }
}

// ==================================================================== Saves
void App::openBrowse(const std::string& path) {
    browsePath = path;
    browseSel = 0;
    if (!fsu::listDir(path, browseEntries)) {
        browseEntries.clear();
        toastMsg("Could not open " + path);
    }
    dirty = true;
}

void App::startScan() {
    browseMode = false;
    scanned = true;
    scanSel = 0;
    scanner.start(P.sdRoot());
    dirty = true;
}

void App::openUsers() {
    std::string err;
    users = save::listUsers(err);
    userSel = 0;
    if (users.empty()) { info("No user profiles", err.empty() ? "The console did not report any user profiles." : err); return; }
    dlg = Dlg::Users;
    dlgTitle = "Whose saves should be opened?";
    dirty = true;
}

void App::startMount(int gi) {
    if (!save::haveUser()) { pendingGame = gi; openUsers(); return; }
    doMount(gi);
}

void App::doMount(int gi) {
    const save::Game& g = save::games()[(size_t)gi];
    save::MountResult r = save::mount(g);
    if (!r.ok) {
        info("Could not open the save",
             r.error + "\n\nTip: if you started this app from the Album, close it and launch it again by holding R while "
                       "opening a game (title takeover) so it has full access to save data.");
        return;
    }
    std::string err;
    std::string dir = save::backup(g, P.dataRoot(), err);
    // Find the main save file inside the mounted save data.
    std::string mainPath = fsu::join("ohsave:/", g.mainFile);
    if (!g.mainFile[0] || !fsu::exists(mainPath) || fsu::isDir(mainPath)) {  // e.g. FireRed/LeafGreen: "<name>_e.sav"
        std::vector<fsu::Entry> es;
        uint64_t best = 0;
        if (fsu::listDir("ohsave:/", es))
            for (const auto& e : es)
                if (!e.isDir && e.size > best) { best = e.size; mainPath = fsu::join("ohsave:/", e.name); }
    }
    std::vector<uint8_t> buf;
    bool read = fsu::readFile(mainPath, buf, 32u << 20);
    save::unmount();
    std::string status = dir.empty() ? "Backup FAILED: " + err + " The save was not changed." : "Backed up to " + dir;
    std::string openErr;
    std::unique_ptr<save::SaveFile> sv;
    if (read) sv = save::open(buf, fsu::baseName(mainPath), &g, openErr);
    else openErr = "Could not read " + mainPath;
    if (sv) {
        std::string notes = sv->notes();
        finishOpen(std::shared_ptr<save::SaveFile>(std::move(sv)), g.name, save::currentUser().name, gameColor((size_t)gi), true,
                   notes.empty() ? status : status + "\n" + notes);
        toastMsg(dir.empty() ? "Opened, but the backup FAILED" : std::string(g.name) + ": backed up and opened");
    } else {
        Card c;
        c.title = g.name;
        c.user = save::currentUser().name;
        c.tag = gameColor((size_t)gi);
        c.consoleSave = true;
        c.status = status + "\nCould not read Pokemon: " + openErr;
        addCard(c);
        tab = Tab::Home;
        toastMsg(dir.empty() ? "Backup failed - see the card on Home" : std::string(g.name) + ": backed up (Pokemon not readable yet)");
    }
}

void App::scanActivate() {
    const auto& res = scanner.results();
    if (scanSel < 0 || scanSel >= (int)res.size()) return;
    openSdSave(res[(size_t)scanSel].path);
}

void App::browseActivate() {
    if (browseSel < 0 || browseSel >= (int)browseEntries.size()) return;
    const fsu::Entry& e = browseEntries[(size_t)browseSel];
    std::string full = fsu::join(browsePath, e.name);
    if (e.isDir) { openBrowse(full); return; }
    pkm::Format f = pkm::detect(fsu::extLower(e.name), (size_t)e.size);
    if (f != pkm::Format::Unknown) {
        std::vector<uint8_t> buf;
        if (!fsu::readFile(full, buf, 1 << 20)) { toastMsg("Could not read " + e.name); return; }
        std::string out = store.add(bank, boxIdx, e.name, buf.data(), buf.size());
        if (out.empty()) toastMsg("This box is full - pick another box with L/R on the Home tab");
        else { reload(); toastMsg("Imported " + e.name + " into Box " + std::to_string(boxIdx + 1)); }
        return;
    }
    std::string label = save::classifySave(e.name, e.size);
    if (!label.empty()) { openSdSave(full); return; }
    toastMsg("Not a Pokemon file or a recognised save");
}

void App::updateSaves(const plat::Input& in) {
    const auto& games = save::games();
    int nGames = (int)games.size();
    if (in.down & plat::Y) openUsers();
    if (in.down & plat::X) startScan();
    if (in.down & plat::L) { browseMode = false; rightFocus = true; }
    if (in.down & plat::R) { browseMode = true; rightFocus = true; if (browsePath.empty()) openBrowse(P.sdRoot()); }
    if (in.down & plat::Left) rightFocus = false;
    if (in.down & plat::Right) rightFocus = true;

    int dy = ((in.down & plat::Down) ? 1 : 0) - ((in.down & plat::Up) ? 1 : 0);
    if (dy) {
        if (!rightFocus) gameSel = std::max(0, std::min(nGames - 1, gameSel + dy));
        else if (browseMode) browseSel = std::max(0, std::min((int)browseEntries.size() - 1, browseSel + dy));
        else scanSel = std::max(0, std::min((int)scanner.results().size() - 1, scanSel + dy));
    }
    if (in.down & plat::A) {
        if (!rightFocus) startMount(gameSel);
        else if (browseMode) browseActivate();
        else scanActivate();
    }
    if ((in.down & plat::B) && rightFocus && browseMode && browsePath != P.sdRoot()) {
        std::string p = browsePath;
        while (p.size() > 1 && p.back() == '/') p.pop_back();
        size_t i = p.find_last_of('/');
        std::string up = i == std::string::npos ? P.sdRoot() : p.substr(0, i + 1);
        if (up.size() < P.sdRoot().size()) up = P.sdRoot();
        openBrowse(up);
    }

    if (!in.touchBegan) return;
    int tx = in.tx, ty = in.ty;
    if (R{22, 56, 150, 32}.in(tx, ty)) openUsers();
    for (int i = 0; i < nGames; i++)
        if (R{22, 104 + i * 40, 410, 36}.in(tx, ty)) {
            if (!rightFocus && gameSel == i) startMount(i);
            gameSel = i;
            rightFocus = false;
        }
    if (R{466, 48, 170, 32}.in(tx, ty)) { browseMode = false; rightFocus = true; }
    if (R{646, 48, 170, 32}.in(tx, ty)) { browseMode = true; rightFocus = true; if (browsePath.empty()) openBrowse(P.sdRoot()); }
    if (R{1100, 48, 154, 32}.in(tx, ty)) startScan();
    if (rightFocus || tx > 454) {
        int n = browseMode ? (int)browseEntries.size() : (int)scanner.results().size();
        int first = 0;
        int sel = browseMode ? browseSel : scanSel;
        first = std::max(0, std::min(sel - 7, std::max(0, n - 15)));
        for (int row = 0; row < 15 && first + row < n; row++)
            if (R{466, 134 + row * 34, 790, 32}.in(tx, ty)) {
                bool same = (browseMode ? browseSel : scanSel) == first + row;
                (browseMode ? browseSel : scanSel) = first + row;
                rightFocus = true;
                if (same) { if (browseMode) browseActivate(); else scanActivate(); }
            }
    }
}

void App::drawSaves() {
    const auto& games = save::games();
    // ---- left: console saves
    R l{12, 8, 430, 656};
    panel(l);
    cv.text("Console saves", 21, 28, 14, kInk);
    button({22, 56, 150, 32}, "Change profile");
    cv.text(save::haveUser() ? save::currentUser().name : "No profile chosen yet", 16, 184, 62, save::haveUser() ? kInk : kMuted, Align::Left, 240);
    for (size_t i = 0; i < games.size(); i++) {
        R r{22, 104 + (int)i * 40, 410, 36};
        bool sel = !rightFocus && gameSel == (int)i;
        cv.fillRoundRect(r.x, r.y, r.w, r.h, 7, sel ? rgb(0xF4FFF4) : kCell);
        cv.fillRoundRect(r.x, r.y, 10, r.h, 5, gameColor(i));
        cv.text(games[i].name, 18, r.x + 24, r.y + 8, kInk);
        if (sel) cv.strokeRoundRect(r.x, r.y, r.w, r.h, 7, 3, kAccent);
    }
    int y = 104 + (int)games.size() * 40 + 8;
    for (const auto& s : wrap("Opening a save makes a full backup on your SD card first and never changes the save.", 14, 390)) {
        cv.text(s, 14, 28, y, kMuted);
        y += 19;
    }

    // ---- right: SD card
    R r{454, 8, 814, 656};
    panel(r);
    cv.text("SD card", 21, 470, 12, kInk);
    cv.text("(older games: GB, GBA, DS, 3DS saves)", 14, 560, 17, kMuted);
    cv.fillRoundRect(466, 48, 170, 32, 6, browseMode ? rgb(0xE9FCE9) : kAccent);
    cv.text("Scan for saves", 16, 551, 55, browseMode ? kInk : kWhite, Align::Center);
    cv.fillRoundRect(646, 48, 170, 32, 6, browseMode ? kAccent : rgb(0xE9FCE9));
    cv.text("Browse folders", 16, 731, 55, browseMode ? kWhite : kInk, Align::Center);
    button({1100, 48, 154, 32}, scanner.running() ? "Scanning..." : "Scan now", !scanner.running());

    int rows = 15;
    if (!browseMode) {
        std::string st;
        if (!scanned) st = "Press X or tap Scan now to search the whole SD card for .sav, .dsv, .srm and .sa1 files.";
        else {
            char b[160];
            std::snprintf(b, sizeof(b), "%s%d folders checked - %d saves found%s", scanner.running() ? "Scanning... " : "", scanner.dirsVisited(),
                          (int)scanner.results().size(), scanner.otherSaves() ? (" (+" + std::to_string(scanner.otherSaves()) + " .sav files of unknown size)").c_str() : "");
            st = b;
        }
        cv.text(st, 15, 470, 96, kMuted, Align::Left, 780);
        const auto& res = scanner.results();
        int first = std::max(0, std::min(scanSel - 7, std::max(0, (int)res.size() - rows)));
        for (int i = 0; i < rows && first + i < (int)res.size(); i++) {
            const save::Found& f = res[(size_t)(first + i)];
            R rr{466, 134 + i * 34, 790, 32};
            bool sel = rightFocus && scanSel == first + i;
            cv.fillRoundRect(rr.x, rr.y, rr.w, rr.h, 6, sel ? rgb(0xF4FFF4) : kCell);
            if (sel) cv.strokeRoundRect(rr.x, rr.y, rr.w, rr.h, 6, 2, kAccent);
            cv.text(f.label, 14, rr.x + 10, rr.y + 7, kMuted, Align::Left, 250);
            cv.text(f.path, 14, rr.x + 270, rr.y + 7, kInk, Align::Left, 430);
            cv.text(fmtSize(f.size), 14, rr.x + rr.w - 10, rr.y + 7, kMuted, Align::Right);
        }
        if (scanned && !scanner.running() && res.empty())
            cv.text("Nothing found. Try Browse folders to look around by hand.", 16, 470, 140, kInk);
    } else {
        cv.text(browsePath, 15, 470, 96, kInk, Align::Left, 780);
        int n = (int)browseEntries.size();
        int first = std::max(0, std::min(browseSel - 7, std::max(0, n - rows)));
        for (int i = 0; i < rows && first + i < n; i++) {
            const fsu::Entry& e = browseEntries[(size_t)(first + i)];
            R rr{466, 134 + i * 34, 790, 32};
            bool sel = rightFocus && browseSel == first + i;
            cv.fillRoundRect(rr.x, rr.y, rr.w, rr.h, 6, sel ? rgb(0xF4FFF4) : kCell);
            if (sel) cv.strokeRoundRect(rr.x, rr.y, rr.w, rr.h, 6, 2, kAccent);
            std::string tag;
            if (e.isDir) tag = "";
            else if (pkm::detect(fsu::extLower(e.name), (size_t)e.size) != pkm::Format::Unknown) tag = "Pokemon file - A to import";
            else tag = save::classifySave(e.name, e.size);
            cv.text(e.isDir ? e.name + "/" : e.name, 14, rr.x + 10, rr.y + 7, e.isDir ? kInk : kInk.alpha(210), Align::Left, 400);
            cv.text(tag, 14, rr.x + 430, rr.y + 7, kAccent, Align::Left, 250);
            if (!e.isDir) cv.text(fmtSize(e.size), 14, rr.x + rr.w - 10, rr.y + 7, kMuted, Align::Right);
        }
        if (browseEntries.empty()) cv.text("This folder is empty.", 16, 470, 140, kMuted);
        cv.text("B: up a folder", 14, 1250, 96, kMuted, Align::Right);
    }
}

// ==================================================================== Settings
void App::settingsActivate() {
    switch (setSel) {
        case 0: toastMsg(store.addBank() ? "Created " + store.bankName(store.bankCount() - 1) : "Could not create a bank"); break;
        case 1: { bool ok = store.sortBox(bank, boxIdx); reload(); toastMsg(ok ? "Box sorted by Pokedex number" : "Could not sort this box"); break; }
        case 2: store.init(); reload(); toastMsg("Boxes reloaded from the SD card"); break;
        case 3: cards.clear(); toastMsg("Save cards cleared"); break;
        case 4: {
            int m = ((int)save::gen3Species() + 1) % 4;
            save::setGen3Species((save::Gen3Species)m);
            std::string v = m == 0 ? "Auto" : m == 1 ? "Vanilla" : m == 2 ? "Expansion" : "Cfru";
            fsu::writeFile(fsu::join(P.dataRoot(), "gen3species.txt"), (const uint8_t*)v.data(), v.size());
            toastMsg("Gen 3 species numbering: " + v + " (re-open the save to apply)");
            break;
        }
    }
}

void App::updateSettings(const plat::Input& in) {
    if (in.down & plat::Up) setSel = std::max(0, setSel - 1);
    if (in.down & plat::Down) setSel = std::min(4, setSel + 1);
    if (in.down & plat::A) settingsActivate();
    if (in.touchBegan)
        for (int i = 0; i < 5; i++)
            if (R{24, 56 + i * 70, 616, 62}.in(in.tx, in.ty)) {
                if (setSel == i) settingsActivate();
                setSel = i;
            }
}

void App::drawSettings() {
    R l{12, 8, 640, 656};
    panel(l);
    cv.text("Settings", 21, 28, 14, kInk);
    struct Row { const char* title; std::string value; };
    Row rows[] = {
        {"Add a new bank", std::to_string(store.bankCount()) + " bank(s)"},
        {"Sort this box by Pokedex number", store.bankCount() ? store.bankName(bank) + ", Box " + std::to_string(boxIdx + 1) : ""},
        {"Reload boxes from the SD card", "after copying files in on a PC"},
        {"Clear save cards on Home", std::to_string(cards.size()) + " card(s)"},
        {"Gen 3 species numbering (ROM hacks)",
         std::string(save::gen3Species() == save::Gen3Species::Auto ? "Auto-detect (default)"
                     : save::gen3Species() == save::Gen3Species::Vanilla ? "Vanilla games only"
                     : save::gen3Species() == save::Gen3Species::Expansion ? "Emerald Seaglass style (National Dex numbers)"
                                                                           : "Unbound style (FireRed hacks, CFRU numbering)")},
    };
    for (int i = 0; i < 5; i++) {
        R r{24, 56 + i * 70, 616, 62};
        cv.fillRoundRect(r.x, r.y, r.w, r.h, 8, setSel == i ? rgb(0xF4FFF4) : kCell);
        if (setSel == i) cv.strokeRoundRect(r.x, r.y, r.w, r.h, 8, 3, kAccent);
        cv.text(rows[i].title, 19, r.x + 16, r.y + 8, kInk);
        cv.text(rows[i].value, 15, r.x + 16, r.y + 35, kMuted, Align::Left, r.w - 32);
    }

    R a{664, 8, 604, 656};
    panel(a);
    cv.text("About OpenHome NX", 21, 680, 14, kInk);
    int y = 54;
    auto line = [&](const std::string& s, bool muted = false) {
        for (const auto& w : wrap(s, 15, 570)) { cv.text(w, 15, 680, y, muted ? kMuted : kInk); y += 20; }
        y += 6;
    };
    line("Version 0.1.0 - a Nintendo Switch homebrew box manager inspired by OpenHome (GPL-3.0).");
    line("Boxes: " + P.dataRoot() + "/boxes", true);
    line("Released Pokemon: " + P.dataRoot() + "/released", true);
    line("Save backups: " + P.dataRoot() + "/backups", true);
    line("Controls: D-pad move, A pick up/place, B cancel, X release, Y filter, - sort box, L/R change box, ZL/ZR change tab, + quit. The touch screen works too.");
    line("Pokemon icons come from the OpenHome project. Pokemon and all related names are trademarks of Nintendo, Creatures Inc. and GAME FREAK inc.", true);
    line("Not affiliated with Nintendo, The Pokemon Company or the OpenHome project.", true);
}

// ==================================================================== dialogs
namespace {
const char* kKbRows[4] = {"1234567890", "QWERTYUIOP", "ASDFGHJKL-", "ZXCVBNM.'"};
const char* kKbSpecial[5] = {"Space", "Del", "Clear", "Cancel", "OK"};
constexpr R kKbPanel{290, 70, 700, 540};
}  // namespace

int App::kbRowLen(int row) const { return row == 4 ? 5 : (int)std::string(kKbRows[row]).size(); }
std::string App::kbKey(int row, int col) const { return row == 4 ? kKbSpecial[col] : std::string(1, kKbRows[row][col]); }

R App::kbKeyR(int row, int col) const {
    int y = kKbPanel.y + 150 + row * 66;
    if (row == 4) return {kKbPanel.x + 25 + col * 130, y + 10, 124, 56};
    return {kKbPanel.x + 18 + col * 67, y, 62, 58};
}

void App::kbPress() {
    std::string k = kbKey(kbRow, kbCol);
    if (kbRow == 4) {
        if (k == "Space") kbText.push_back(' ');
        else if (k == "Del") { if (!kbText.empty()) kbText.pop_back(); }
        else if (k == "Clear") kbText.clear();
        else if (k == "Cancel") dlg = Dlg::None;
        else if (k == "OK") { dlg = Dlg::None; if (onKb) onKb(kbText); }
    } else if (kbText.size() < 24) {
        bool cap = kbText.empty() || kbText.back() == ' ';
        char c = k[0];
        if (std::isalpha((unsigned char)c)) c = cap ? (char)std::toupper((unsigned char)c) : (char)std::tolower((unsigned char)c);
        kbText.push_back(c);
    }
    dirty = true;
}

void App::updateDialog(const plat::Input& in) {
    int tx = in.tx, ty = in.ty;
    if (dlg == Dlg::Info || dlg == Dlg::Confirm) {
        int n = (int)wrap(dlgText, 17, 600).size();
        int h = 110 + n * 24 + 70;
        R d{320, (H - h) / 2, 640, h};
        R yes{d.x + d.w - 170, d.y + d.h - 62, 150, 44}, no{d.x + d.w - 340, d.y + d.h - 62, 150, 44};
        bool isConfirm = dlg == Dlg::Confirm;
        if (in.down & plat::A) { dlg = Dlg::None; if (isConfirm && onYes) onYes(); }
        else if (in.down & plat::B) dlg = Dlg::None;
        else if (in.touchBegan) {
            if (yes.in(tx, ty)) { dlg = Dlg::None; if (isConfirm && onYes) onYes(); }
            else if (isConfirm ? no.in(tx, ty) : !d.in(tx, ty)) dlg = Dlg::None;
        }
        dirty = true;
        return;
    }
    if (dlg == Dlg::Users) {
        int n = (int)users.size();
        int h = 100 + n * 52 + 30;
        R d{380, (H - h) / 2, 520, h};
        auto choose = [&](int i) {
            save::setUser(users[(size_t)i]);
            dlg = Dlg::None;
            if (pendingGame >= 0) { int g = pendingGame; pendingGame = -1; doMount(g); }
        };
        if (in.down & plat::Up) userSel = std::max(0, userSel - 1);
        if (in.down & plat::Down) userSel = std::min(n - 1, userSel + 1);
        if (in.down & plat::A) choose(userSel);
        if (in.down & plat::B) { dlg = Dlg::None; pendingGame = -1; }
        if (in.touchBegan) {
            bool hit = false;
            for (int i = 0; i < n; i++)
                if (R{d.x + 20, d.y + 70 + i * 52, d.w - 40, 46}.in(tx, ty)) { choose(i); hit = true; break; }
            if (!hit && !d.in(tx, ty)) { dlg = Dlg::None; pendingGame = -1; }
        }
        dirty = true;
        return;
    }
    if (dlg == Dlg::Keyboard) {
        if (in.down & plat::Up) kbRow = std::max(0, kbRow - 1);
        if (in.down & plat::Down) kbRow = std::min(4, kbRow + 1);
        if (in.down & plat::Left) kbCol = std::max(0, kbCol - 1);
        if (in.down & plat::Right) kbCol = kbCol + 1;
        kbCol = std::min(kbCol, kbRowLen(kbRow) - 1);
        if (in.down & plat::A) kbPress();
        if ((in.down & plat::B) && !kbText.empty()) kbText.pop_back();
        if (in.down & plat::Y) kbText.clear();
        if (in.down & plat::Plus) { dlg = Dlg::None; if (onKb) onKb(kbText); }
        if (in.touchBegan) {
            for (int r = 0; r < 5; r++)
                for (int c = 0; c < kbRowLen(r); c++)
                    if (kbKeyR(r, c).in(tx, ty)) { kbRow = r; kbCol = c; kbPress(); }
        }
        dirty = true;
    }
}

void App::drawDialog() {
    cv.fillRect(0, 0, W, H, kShade);
    if (dlg == Dlg::Info || dlg == Dlg::Confirm) {
        auto lines = wrap(dlgText, 17, 600);
        int h = 110 + (int)lines.size() * 24 + 70;
        R d{320, (H - h) / 2, 640, h};
        panel(d);
        cv.text(dlgTitle, 22, d.x + 20, d.y + 18, kInk, Align::Left, d.w - 40);
        int y = d.y + 66;
        for (const auto& l : lines) { cv.text(l, 17, d.x + 20, y, kInk); y += 24; }
        R yes{d.x + d.w - 170, d.y + d.h - 62, 150, 44}, no{d.x + d.w - 340, d.y + d.h - 62, 150, 44};
        if (dlg == Dlg::Confirm) { button(no, "No (B)"); button(yes, "Yes (A)", true, true); }
        else button(yes, "OK (A)", true, true);
    } else if (dlg == Dlg::Users) {
        int n = (int)users.size();
        int h = 100 + n * 52 + 30;
        R d{380, (H - h) / 2, 520, h};
        panel(d);
        cv.text(dlgTitle, 21, d.x + d.w / 2, d.y + 18, kInk, Align::Center, d.w - 30);
        for (int i = 0; i < n; i++) {
            R r{d.x + 20, d.y + 70 + i * 52, d.w - 40, 46};
            cv.fillRoundRect(r.x, r.y, r.w, r.h, 8, userSel == i ? rgb(0xF4FFF4) : kCell);
            if (userSel == i) cv.strokeRoundRect(r.x, r.y, r.w, r.h, 8, 3, kAccent);
            cv.fillRoundRect(r.x + 8, r.y + 7, 32, 32, 16, kHead);
            cv.text(users[(size_t)i].name.empty() ? "?" : users[(size_t)i].name.substr(0, 1), 18, r.x + 24, r.y + 11, kWhite, Align::Center);
            cv.text(users[(size_t)i].name, 19, r.x + 54, r.y + 11, kInk, Align::Left, r.w - 70);
        }
    } else if (dlg == Dlg::Keyboard) {
        panel(kKbPanel);
        cv.text(dlgTitle, 22, kKbPanel.x + 24, kKbPanel.y + 18, kInk, Align::Left, kKbPanel.w - 48);
        R box{kKbPanel.x + 24, kKbPanel.y + 70, kKbPanel.w - 48, 52};
        cv.fillRoundRect(box.x, box.y, box.w, box.h, 8, rgb(0xF4FFF4));
        cv.strokeRoundRect(box.x, box.y, box.w, box.h, 8, 2, rgb(0xA9CFC3));
        cv.text(kbText + "|", 24, box.x + 14, box.y + 11, kInk, Align::Left, box.w - 28);
        for (int r = 0; r < 5; r++)
            for (int c = 0; c < kbRowLen(r); c++) {
                R k = kbKeyR(r, c);
                bool sel = kbRow == r && kbCol == c;
                bool ok = r == 4 && c == 4;
                cv.fillRoundRect(k.x, k.y, k.w, k.h, 7, ok ? kAccent : (sel ? rgb(0xF4FFF4) : kCell));
                if (sel) cv.strokeRoundRect(k.x, k.y, k.w, k.h, 7, 3, kAccent);
                cv.text(kbKey(r, c), r == 4 ? 18 : 22, k.x + k.w / 2, k.y + (r == 4 ? 17 : 14), ok ? kWhite : kInk, Align::Center);
            }
        cv.text("A type   B delete   Y clear   + done", 14, kKbPanel.x + kKbPanel.w / 2, kKbPanel.y + kKbPanel.h - 28, kMuted, Align::Center);
    }
}

}  // namespace

// ==================================================================== entry point
int run(plat::Platform& p) {
    App app(p);
    if (!app.init()) return 1;
    int idle = 0;
    while (p.running() && !app.quit) {
        plat::Input in = p.poll();
        app.update(in);
        if (app.dirty || ++idle >= 30) {
            app.draw();
            p.present(app.canvas());
            app.dirty = false;
            idle = 0;
        }
    }
    return 0;
}

}  // namespace ui
