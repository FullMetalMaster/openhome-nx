#pragma once
#include "platform/platform.hpp"

namespace ui {
// Runs the whole application until the user quits. Returns the process exit code.
int run(plat::Platform& p);
}
