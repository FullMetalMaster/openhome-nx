#include "pkm/pkm.hpp"

#include <algorithm>

#include "pkm/data.h"
#include "pkm/pkm_internal.hpp"

namespace pkm {

uint16_t rd16(const uint8_t* p) { return (uint16_t)(p[0] | (p[1] << 8)); }
uint32_t rd32(const uint8_t* p) {
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}
void wr16(uint8_t* p, uint16_t v) { p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); }
void wr32(uint8_t* p, uint32_t v) { wr16(p, (uint16_t)v); wr16(p + 2, (uint16_t)(v >> 16)); }

namespace {
struct Row { Format f; const char* name; const char* ext; size_t minSize; };
const Row kRows[] = {
    {Format::PK1, "PK1", "pk1", 59},  {Format::PK2, "PK2", "pk2", 63},   {Format::PK3, "PK3", "pk3", 80},
    {Format::PK4, "PK4", "pk4", 136}, {Format::PK5, "PK5", "pk5", 136},   {Format::PK6, "PK6", "pk6", 232},
    {Format::PK7, "PK7", "pk7", 232}, {Format::PB7, "PB7", "pb7", 232},   {Format::PK8, "PK8", "pk8", 328},
    {Format::PA8, "PA8", "pa8", 360}, {Format::PB8, "PB8", "pb8", 328},   {Format::PK9, "PK9", "pk9", 328},
    {Format::PA9, "PA9", "pa9", 328},
};
const Row* rowFor(Format f) {
    for (const auto& r : kRows)
        if (r.f == f) return &r;
    return nullptr;
}
}  // namespace

const char* formatName(Format f) { const Row* r = rowFor(f); return r ? r->name : "???"; }
const char* formatExt(Format f) { const Row* r = rowFor(f); return r ? r->ext : "bin"; }
size_t formatStoredSize(Format f) { const Row* r = rowFor(f); return r ? r->minSize : 0; }

Format detect(const std::string& ext, size_t size) {
    for (const auto& r : kRows)
        if (ext == r.ext) return size >= r.minSize ? r.f : Format::Unknown;
    return Format::Unknown;
}

Info parse(Format f, const uint8_t* d, size_t size) {
    Info info;
    info.format = f;
    if (f == Format::Unknown || size < formatStoredSize(f)) return info;
    bool ok = false;
    switch (f) {
        case Format::PK1: case Format::PK2: ok = parseGen12(f, d, size, info); break;
        case Format::PK3: ok = parseGen3(f, d, size, info); break;
        case Format::PK4: case Format::PK5: ok = parseGen45(f, d, size, info); break;
        default: ok = parseModern(f, d, size, info); break;
    }
    info.format = f;
    info.valid = ok && info.species != 0 && info.species <= 1100;
    if (!info.valid) info.species = 0;
    if (info.valid && info.level == 0 && info.exp) info.level = levelFromExp(info.species, info.exp);
    return info;
}

// ---- experience curves (levels 1..100) ----
static int64_t expForLevel(int growth, int64_t n) {
    int64_t n2 = n * n, n3 = n2 * n;
    switch (growth) {
        case 0:  // Erratic
            if (n < 50) return n3 * (100 - n) / 50;
            if (n < 68) return n3 * (150 - n) / 100;
            if (n < 98) return n3 * ((1911 - 10 * n) / 3) / 500;
            return n3 * (160 - n) / 100;
        case 1: return 4 * n3 / 5;                                     // Fast
        case 2: return n3;                                             // Medium Fast
        case 3: { int64_t v = 6 * n3 / 5 - 15 * n2 + 100 * n - 140; return v < 0 ? 0 : v; }  // Medium Slow
        case 4: return 5 * n3 / 4;                                     // Slow
        default:  // Fluctuating
            if (n < 15) return n3 * ((n + 1) / 3 + 24) / 50;
            if (n < 36) return n3 * (n + 14) / 50;
            return n3 * (n / 2 + 32) / 50;
    }
}

uint8_t levelFromExp(uint16_t dex, uint32_t exp) {
    if (dex == 0 || dex >= ohnx::kGrowthCount) return 0;
    int g = ohnx::kGrowth[dex];
    int lvl = 1;
    for (int n = 2; n <= 100; n++) {
        if (expForLevel(g, n) <= (int64_t)exp) lvl = n;
        else break;
    }
    return (uint8_t)lvl;
}

bool isShinyPid(uint32_t pid, uint16_t tid, uint16_t sid, int threshold) {
    uint32_t x = (uint32_t)tid ^ (uint32_t)sid ^ (pid >> 16) ^ (pid & 0xFFFF);
    return x < (uint32_t)threshold;
}

std::string utf16ToUtf8(const std::u16string& s) {
    std::string out;
    for (size_t i = 0; i < s.size(); i++) {
        uint32_t c = s[i];
        if (c >= 0xD800 && c <= 0xDBFF && i + 1 < s.size()) {
            uint32_t lo = s[i + 1];
            if (lo >= 0xDC00 && lo <= 0xDFFF) { c = 0x10000 + ((c - 0xD800) << 10) + (lo - 0xDC00); i++; }
        }
        if (c < 0x80) out.push_back((char)c);
        else if (c < 0x800) { out.push_back((char)(0xC0 | (c >> 6))); out.push_back((char)(0x80 | (c & 0x3F))); }
        else if (c < 0x10000) { out.push_back((char)(0xE0 | (c >> 12))); out.push_back((char)(0x80 | ((c >> 6) & 0x3F))); out.push_back((char)(0x80 | (c & 0x3F))); }
        else { out.push_back((char)(0xF0 | (c >> 18))); out.push_back((char)(0x80 | ((c >> 12) & 0x3F))); out.push_back((char)(0x80 | ((c >> 6) & 0x3F))); out.push_back((char)(0x80 | (c & 0x3F))); }
    }
    return out;
}

}  // namespace pkm
