// Generation 4 and 5 (.pk4 / .pk5) parsing. Baseline only (species, nickname, OT, exp);
// the Gen 4-5 worker extends this (level, shiny, egg, form, ...).
#include "pkm/pkm_internal.hpp"

namespace pkm {

static std::u16string readStr(const uint8_t* d, size_t size, size_t off, size_t chars) {
    std::u16string s;
    if (off + chars * 2 > size) return s;
    for (size_t i = 0; i < chars; i++) {
        uint16_t c = rd16(d + off + i * 2);
        if (c == 0 || c == 0xFFFF) break;
        s.push_back((char16_t)c);
    }
    return s;
}

bool parseGen45(Format, const uint8_t* d, size_t n, Info& out) {
    out.species = rd16(d + 0x08);
    out.exp = rd32(d + 0x10);
    out.nickname = readStr(d, n, 0x48, 11);
    out.otName = readStr(d, n, 0x68, 8);
    return true;
}

}  // namespace pkm
