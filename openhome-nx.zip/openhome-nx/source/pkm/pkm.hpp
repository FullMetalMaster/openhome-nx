// PKM file detection and core-field reading.
// Operates on raw .pk* files in their decrypted "logical" layout (the same files desktop
// OpenHome and PKHeX import/export), so boxes stay interchangeable.
#pragma once
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace pkm {

enum class Format {
    Unknown,
    PK1,  // Gen 1  (.pk1)  files are 59 / 69 bytes (stored + OT/nickname)
    PK2,  // Gen 2  (.pk2)  files are 63 / 73 bytes
    PK3,  // Gen 3  (.pk3)  80 stored / 100 party, decrypted+unshuffled
    PK4,  // Gen 4  (.pk4)  136 / 236
    PK5,  // Gen 5  (.pk5)  136 / 220
    PK6,  // Gen 6  (.pk6)  232 / 260
    PK7,  // Gen 7  (.pk7)  232 / 260
    PB7,  // Let's Go (.pb7) 232 / 260
    PK8,  // Sword/Shield (.pk8) 328 (files 344)
    PA8,  // Legends: Arceus (.pa8) 360 (files 376)
    PB8,  // Brilliant Diamond / Shining Pearl (.pb8) 328 (files 344)
    PK9,  // Scarlet/Violet (.pk9) 328 (files 344)
    PA9,  // Legends: Z-A (.pa9) 328 (files 344)
};

struct Info {
    Format format = Format::Unknown;
    uint16_t species = 0;       // National Dex number (0 if not readable)
    uint16_t rawSpecies = 0;    // the game's own species number when it has no National Dex equivalent (hack/fakemon)
    uint16_t form = 0;
    uint8_t level = 0;          // 0 = unknown
    bool shiny = false;
    bool egg = false;
    uint16_t tid = 0, sid = 0;  // trainer ID / secret ID where the format has them
    uint32_t exp = 0;
    std::u16string nickname;    // may be empty when not readable
    std::u16string otName;
    bool valid = false;
};

const char* formatName(Format f);
const char* formatExt(Format f);
size_t formatStoredSize(Format f);  // minimum size of a usable file

// Detect from file extension (lowercase, no dot) and byte length.
Format detect(const std::string& extension, size_t size);

// Parse core fields from a raw (decrypted) buffer. Never reads out of bounds.
Info parse(Format f, const uint8_t* data, size_t size);

// Level (1..100) for an experience total, using the species' growth curve. Returns 0 if species is unknown.
uint8_t levelFromExp(uint16_t nationalDex, uint32_t exp);

// Gen 3+ shiny test (TID/SID vs PID). Gen 6+ uses the same xor rule with threshold 16.
bool isShinyPid(uint32_t pid, uint16_t tid, uint16_t sid, int threshold);

// Little-endian helpers.
uint16_t rd16(const uint8_t* p);
uint32_t rd32(const uint8_t* p);
void wr16(uint8_t* p, uint16_t v);
void wr32(uint8_t* p, uint32_t v);

std::string utf16ToUtf8(const std::u16string& s);

}  // namespace pkm
