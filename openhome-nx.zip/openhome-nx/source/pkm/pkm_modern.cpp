// Generation 6+ Pokemon (.pk6 .pk7 .pb7 .pk8 .pa8 .pb8 .pk9 .pa9) core-field parsing from the
// DECRYPTED canonical file layout. Offsets ported from PKHeX.Core/PKM/PK6.cs, PK7.cs, PB7.cs,
// Shared/G8PKM.cs (PK8, PB8), PA8.cs, PK9.cs, PA9.cs. Verified against PKHeX sample files
// (see tests/test_modern.cpp).
#include "pkm/data.h"
#include "pkm/pkm_internal.hpp"

namespace pkm {

static std::u16string readStr(const uint8_t* d, size_t size, size_t off, size_t chars) {
    std::u16string s;
    if (off > size || chars * 2 > size - off) return s;
    for (size_t i = 0; i < chars; i++) {
        uint16_t c = rd16(d + off + i * 2);
        if (c == 0) break;
        s.push_back((char16_t)c);
    }
    return s;
}

bool parseModern(Format f, const uint8_t* d, size_t n, Info& out) {
    size_t ivOff, levelOff, nickOff, otOff, nickChars;
    bool gen67 = false;
    switch (f) {
        case Format::PK6: case Format::PK7: case Format::PB7:
            gen67 = true; ivOff = 0x74; levelOff = 0xEC; nickOff = 0x40; otOff = 0xB0; nickChars = 12; break;
        case Format::PA8:
            ivOff = 0x94; levelOff = 0x168; nickOff = 0x60; otOff = 0x110; nickChars = 13; break;
        case Format::PK8: case Format::PB8: case Format::PK9: case Format::PA9:
            ivOff = 0x8C; levelOff = 0x148; nickOff = 0x58; otOff = 0xF8; nickChars = 13; break;
        default: return false;
    }
    if (n < 0x40 || ivOff + 4 > n) return false;

    uint16_t sp = rd16(d + 0x08);
    // Scarlet/Violet and Legends Z-A store an internal species ID (SpeciesConverter.GetNational9).
    if ((f == Format::PK9 || f == Format::PA9) && sp < ohnx::kSvToNationalCount) sp = ohnx::kSvToNational[sp];
    out.species = sp;
    out.form = gen67 ? (uint16_t)(d[0x1D] >> 3) : (uint16_t)d[0x24];
    out.tid = rd16(d + 0x0C);
    out.sid = rd16(d + 0x0E);
    out.exp = rd32(d + 0x10);
    uint32_t pid = rd32(d + (gen67 ? 0x18 : 0x1C));  // PID offset differs: PK6/7/PB7 0x18, Gen 8+ 0x1C
    out.shiny = isShinyPid(pid, out.tid, out.sid, 16);
    out.egg = ((rd32(d + ivOff) >> 30) & 1) != 0;
    out.nickname = readStr(d, n, nickOff, nickChars);
    out.otName = readStr(d, n, otOff, nickChars);
    // Stored level lives in the party block (0xEC for Gen 6/7, 0x148, 0x168 for PA8): present in 260+ byte
    // party files, absent from box files that end right before it, so fall back to the growth curve.
    out.level = 0;
    if (levelOff < n && d[levelOff] >= 1 && d[levelOff] <= 100) out.level = d[levelOff];
    else out.level = levelFromExp(out.species, out.exp);
    return true;
}

}  // namespace pkm
