// Encryption/shuffling of Pokemon data as stored in save files (ported from PKHeX's PokeCrypto, GPL-3.0).
//
// "Decrypted" here means the canonical layout used by .pk3/.pk4/.pk5/.pk6/.pk7/.pk8/.pk9 files exported
// by PKHeX and desktop OpenHome: blocks decrypted AND put back in canonical order. That is the form
// pkm::parse() understands and the form the box store keeps on the SD card.
#pragma once
#include <cstddef>
#include <cstdint>

namespace pkm {
namespace crypto {

// Gen 3: 80 bytes (or 100 with party stats, which are not encrypted). Bytes 0..31 are the plain header,
// bytes 32..79 are four 12-byte substructures (Growth, Attacks, EVs, Misc in canonical order).
bool decrypt3(uint8_t* d, size_t len);
bool encrypt3(uint8_t* d, size_t len);

// Gen 4/5: 136 bytes stored (+ party bytes: 236 for Gen 4, 220 for Gen 5). 4 blocks of 32 bytes.
bool decrypt45(uint8_t* d, size_t len);
bool encrypt45(uint8_t* d, size_t len);

// Gen 6/7 (and Let's Go): 232 bytes stored (+ party: 260). 4 blocks of 56 bytes.
bool decrypt67(uint8_t* d, size_t len);
bool encrypt67(uint8_t* d, size_t len);

// Gen 8/9 style: 8-byte header + 4 blocks of `blockSize` bytes (+ optional party bytes).
// Sword/Shield, BDSP, Scarlet/Violet: blockSize 80 (stored 328). Legends: Arceus: blockSize 88 (stored 360).
bool decryptBlocks(uint8_t* d, size_t len, size_t blockSize);
bool encryptBlocks(uint8_t* d, size_t len, size_t blockSize);

// The Gen 4+ checksum: 16-bit sum of the little-endian words after the 8-byte header up to `storedLen`.
uint16_t checksum16(const uint8_t* d, size_t storedLen);

}  // namespace crypto
}  // namespace pkm
