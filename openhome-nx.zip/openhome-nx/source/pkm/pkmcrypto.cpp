#include "pkm/pkmcrypto.hpp"

#include <cstring>

namespace pkm {
namespace crypto {

// Same table as PKHeX BlockPosition: row sv lists, for each decrypted position i, which encrypted
// block sits there. 24 permutations; rows 24..31 repeat rows 0..7 so ((pv >> 13) & 31) can index directly.
static const uint8_t kPos[32][4] = {
    {0, 1, 2, 3}, {0, 1, 3, 2}, {0, 2, 1, 3}, {0, 3, 1, 2}, {0, 2, 3, 1}, {0, 3, 2, 1},
    {1, 0, 2, 3}, {1, 0, 3, 2}, {2, 0, 1, 3}, {3, 0, 1, 2}, {2, 0, 3, 1}, {3, 0, 2, 1},
    {1, 2, 0, 3}, {1, 3, 0, 2}, {2, 1, 0, 3}, {3, 1, 0, 2}, {2, 3, 0, 1}, {3, 2, 0, 1},
    {1, 2, 3, 0}, {1, 3, 2, 0}, {2, 1, 3, 0}, {3, 1, 2, 0}, {2, 3, 1, 0}, {3, 2, 1, 0},
    {0, 1, 2, 3}, {0, 1, 3, 2}, {0, 2, 1, 3}, {0, 3, 1, 2}, {0, 2, 3, 1}, {0, 3, 2, 1},
    {1, 0, 2, 3}, {1, 0, 3, 2},
};

static uint32_t rd32(const uint8_t* p) {
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}
static uint16_t rd16(const uint8_t* p) { return (uint16_t)(p[0] | (p[1] << 8)); }

// XOR each 16-bit word with the high half of a running LCG (Gen 4+ scheme).
static void cryptWords(uint8_t* d, size_t len, uint32_t seed) {
    for (size_t i = 0; i + 1 < len; i += 2) {
        seed = 0x41C64E6Du * seed + 0x6073u;
        uint16_t x = (uint16_t)(seed >> 16);
        d[i] ^= (uint8_t)(x & 0xFF);
        d[i + 1] ^= (uint8_t)(x >> 8);
    }
}

// decrypted[i] = encrypted[pos[i]]  (decrypt=true)   /   encrypted[pos[i]] = decrypted[i]  (decrypt=false)
static void shuffleBlocks(uint8_t* d, size_t blockSize, const uint8_t* pos, bool decrypt) {
    uint8_t tmp[4 * 88];
    std::memcpy(tmp, d, 4 * blockSize);
    for (int i = 0; i < 4; i++) {
        if (decrypt) std::memcpy(d + i * blockSize, tmp + pos[i] * blockSize, blockSize);
        else std::memcpy(d + pos[i] * blockSize, tmp + i * blockSize, blockSize);
    }
}

// ---- Gen 3 ----
static bool crypt3(uint8_t* d, size_t len, bool decrypt) {
    if (len < 80) return false;
    uint32_t pid = rd32(d), oid = rd32(d + 4);
    uint32_t key = pid ^ oid;
    const uint8_t* pos = kPos[pid % 24];
    uint8_t* body = d + 32;
    if (decrypt) {
        for (int i = 0; i < 12; i++) {  // 48 bytes = 12 words
            body[i * 4 + 0] ^= (uint8_t)(key);
            body[i * 4 + 1] ^= (uint8_t)(key >> 8);
            body[i * 4 + 2] ^= (uint8_t)(key >> 16);
            body[i * 4 + 3] ^= (uint8_t)(key >> 24);
        }
        shuffleBlocks(body, 12, pos, true);
    } else {
        shuffleBlocks(body, 12, pos, false);
        for (int i = 0; i < 12; i++) {
            body[i * 4 + 0] ^= (uint8_t)(key);
            body[i * 4 + 1] ^= (uint8_t)(key >> 8);
            body[i * 4 + 2] ^= (uint8_t)(key >> 16);
            body[i * 4 + 3] ^= (uint8_t)(key >> 24);
        }
    }
    return true;
}
bool decrypt3(uint8_t* d, size_t len) { return crypt3(d, len, true); }
bool encrypt3(uint8_t* d, size_t len) { return crypt3(d, len, false); }

// ---- Gen 4/5 ----
static bool crypt45(uint8_t* d, size_t len, bool decrypt) {
    if (len != 136 && len != 220 && len != 236) return false;
    uint32_t pv = rd32(d);
    uint32_t chk = rd16(d + 6);
    const uint8_t* pos = kPos[(pv >> 13) & 31];
    uint8_t* body = d + 8;
    if (decrypt) {
        cryptWords(body, 128, chk);
        if (len > 136) cryptWords(d + 136, len - 136, pv);
        shuffleBlocks(body, 32, pos, true);
    } else {
        shuffleBlocks(body, 32, pos, false);
        cryptWords(body, 128, chk);
        if (len > 136) cryptWords(d + 136, len - 136, pv);
    }
    return true;
}
bool decrypt45(uint8_t* d, size_t len) { return crypt45(d, len, true); }
bool encrypt45(uint8_t* d, size_t len) { return crypt45(d, len, false); }

// ---- Gen 6+ (shared) ----
static bool cryptN(uint8_t* d, size_t len, size_t blockSize, bool decrypt) {
    size_t stored = 8 + 4 * blockSize;
    if (len < stored || blockSize > 88) return false;
    uint32_t pv = rd32(d);
    const uint8_t* pos = kPos[(pv >> 13) & 31];
    uint8_t* body = d + 8;
    if (decrypt) {
        cryptWords(body, 4 * blockSize, pv);
        if (len > stored) cryptWords(d + stored, len - stored, pv);
        shuffleBlocks(body, blockSize, pos, true);
    } else {
        shuffleBlocks(body, blockSize, pos, false);
        cryptWords(body, 4 * blockSize, pv);
        if (len > stored) cryptWords(d + stored, len - stored, pv);
    }
    return true;
}
bool decrypt67(uint8_t* d, size_t len) { return (len == 232 || len == 260) && cryptN(d, len, 56, true); }
bool encrypt67(uint8_t* d, size_t len) { return (len == 232 || len == 260) && cryptN(d, len, 56, false); }
bool decryptBlocks(uint8_t* d, size_t len, size_t bs) { return cryptN(d, len, bs, true); }
bool encryptBlocks(uint8_t* d, size_t len, size_t bs) { return cryptN(d, len, bs, false); }

uint16_t checksum16(const uint8_t* d, size_t storedLen) {
    uint32_t sum = 0;
    for (size_t i = 8; i + 1 < storedLen; i += 2) sum += rd16(d + i);
    return (uint16_t)sum;
}

}  // namespace crypto
}  // namespace pkm
