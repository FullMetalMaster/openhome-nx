// Generation 3 (GBA) Pokemon: .pk3 parsing and save-file encryption.
// Layout follows PKHeX's PK3 / PokeCrypto.Decrypt3.
#include "pkm/data.h"
#include "pkm/pkm_internal.hpp"

namespace pkm {

// Block permutations indexed by (PID % 24): result block i = encrypted block kBlockPos[sv][i].
// Logical block order is G (growth), A (attacks), E (EVs), M (misc).
static const uint8_t kBlockPos[24][4] = {
    {0, 1, 2, 3}, {0, 1, 3, 2}, {0, 2, 1, 3}, {0, 3, 1, 2}, {0, 2, 3, 1}, {0, 3, 2, 1},
    {1, 0, 2, 3}, {1, 0, 3, 2}, {2, 0, 1, 3}, {3, 0, 1, 2}, {2, 0, 3, 1}, {3, 0, 2, 1},
    {1, 2, 0, 3}, {1, 3, 0, 2}, {2, 1, 0, 3}, {3, 1, 0, 2}, {2, 3, 0, 1}, {3, 2, 0, 1},
    {1, 2, 3, 0}, {1, 3, 2, 0}, {2, 1, 3, 0}, {3, 1, 2, 0}, {2, 3, 1, 0}, {3, 2, 1, 0},
};

static void xorBlocks(uint8_t* p48, uint32_t key) {
    for (int i = 0; i < 12; i++) wr32(p48 + i * 4, rd32(p48 + i * 4) ^ key);
}

void gen3Decrypt(uint8_t* buf) {
    uint32_t pid = rd32(buf), oid = rd32(buf + 4);
    uint32_t key = pid ^ oid;
    int sv = (int)(pid % 24);
    uint8_t* data = buf + 0x20;
    xorBlocks(data, key);
    uint8_t tmp[48];
    for (int i = 0; i < 4; i++)
        for (int b = 0; b < 12; b++) tmp[i * 12 + b] = data[kBlockPos[sv][i] * 12 + b];
    for (int i = 0; i < 48; i++) data[i] = tmp[i];
}

void gen3Encrypt(uint8_t* buf) {
    uint32_t pid = rd32(buf), oid = rd32(buf + 4);
    uint32_t key = pid ^ oid;
    int sv = (int)(pid % 24);
    uint8_t* data = buf + 0x20;
    uint8_t tmp[48];
    for (int i = 0; i < 4; i++)
        for (int b = 0; b < 12; b++) tmp[kBlockPos[sv][i] * 12 + b] = data[i * 12 + b];
    for (int i = 0; i < 48; i++) data[i] = tmp[i];
    xorBlocks(data, key);
}

uint16_t gen3Checksum(const uint8_t* d) {
    uint32_t sum = 0;
    for (int i = 0; i < 24; i++) sum += rd16(d + 0x20 + i * 2);
    return (uint16_t)sum;
}

std::u16string gen3String(const uint8_t* p, size_t maxChars, bool japanese) {
    const char16_t* table = japanese ? ohnx::kGen3JpnChars : ohnx::kGen3IntChars;
    unsigned count = japanese ? ohnx::kGen3JpnCharsCount : ohnx::kGen3IntCharsCount;
    std::u16string s;
    for (size_t i = 0; i < maxChars; i++) {
        uint8_t b = p[i];
        if (b == 0xFF) break;  // terminator
        char16_t c = b < count ? table[b] : (char16_t)0xFFFF;
        if (c == 0xFFFF) continue;  // unmapped
        s.push_back(c);
    }
    return s;
}

bool parseGen3(Format, const uint8_t* d, size_t n, Info& out) {
    if (n < 80) return false;
    uint32_t pid = rd32(d);
    out.tid = rd16(d + 4);
    out.sid = rd16(d + 6);
    bool jp = d[0x12] == 1;
    out.nickname = gen3String(d + 0x08, 10, jp);
    out.otName = gen3String(d + 0x14, 7, jp);
    uint8_t flags = d[0x13];
    out.egg = (flags & 4) != 0;
    if (!(flags & 2)) return false;  // no species flag = empty slot
    uint16_t internal = rd16(d + 0x20);
    out.species = internal < ohnx::kGen3ToNationalCount ? ohnx::kGen3ToNational[internal] : 0;
    out.exp = rd32(d + 0x24);
    out.shiny = isShinyPid(pid, out.tid, out.sid, 8);
    if (n >= 100 && d[0x54] >= 1 && d[0x54] <= 100) out.level = d[0x54];  // party data carries the level
    return true;
}

}  // namespace pkm
