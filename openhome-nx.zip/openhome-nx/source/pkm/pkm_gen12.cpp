// Generation 1 and 2 (.pk1 / .pk2) parsing. TODO: implemented by the Gen 1-2 worker.
#include "pkm/pkm_internal.hpp"

namespace pkm {

bool parseGen12(Format, const uint8_t*, size_t, Info&) { return false; }

}  // namespace pkm
