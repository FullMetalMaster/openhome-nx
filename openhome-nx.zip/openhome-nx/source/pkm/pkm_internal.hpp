// Per-generation parsers, each in its own file so they can be developed independently.
// pkm::parse() (pkm.cpp) validates the size, then dispatches here. Each function receives a
// buffer already known to be at least formatStoredSize(f) bytes, and fills `Info` (format and
// valid are set by the caller's dispatch only if the function returns true).
#pragma once
#include "pkm/pkm.hpp"

namespace pkm {

bool parseGen12(Format f, const uint8_t* d, size_t n, Info& out);    // pkm_gen12.cpp  (PK1, PK2)
bool parseGen3(Format f, const uint8_t* d, size_t n, Info& out);     // pkm_gen3.cpp   (PK3)
bool parseGen45(Format f, const uint8_t* d, size_t n, Info& out);    // pkm_gen45.cpp  (PK4, PK5)
bool parseModern(Format f, const uint8_t* d, size_t n, Info& out);   // pkm_modern.cpp (PK6, PK7, PB7, PK8, PA8, PB8, PK9)

// Decoders for Gen 3 text (also used by the Gen 3 save reader). `japanese` selects the Japanese table.
std::u16string gen3String(const uint8_t* p, size_t maxChars, bool japanese);

// Encrypt/decrypt a Gen 3 Pokemon between its save-file form and the logical file form.
// `buf` must hold at least 80 bytes; for 100-byte party data only the first 80 are touched.
void gen3Decrypt(uint8_t* buf);
void gen3Encrypt(uint8_t* buf);
uint16_t gen3Checksum(const uint8_t* decrypted80);  // sum of the 24 little-endian words at 0x20..0x4F

}  // namespace pkm
