#include "platform/platform.hpp"
#include "ui/app.hpp"

int main(int, char**) {
    plat::Platform* p = plat::create();
    if (!p->init()) {
        // No system font = nothing to draw text with; still shut down cleanly.
        p->shutdown();
        return 1;
    }
    int rc = ui::run(*p);
    p->shutdown();
    return rc;
}
