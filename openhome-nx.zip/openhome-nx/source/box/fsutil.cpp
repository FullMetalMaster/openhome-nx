#include "box/fsutil.hpp"

#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>

#include <algorithm>
#include <cctype>
#include <cstdio>

namespace fsu {

std::string join(const std::string& a, const std::string& b) {
    if (a.empty()) return b;
    if (a.back() == '/') return a + b;
    return a + "/" + b;
}

std::string baseName(const std::string& p) {
    size_t i = p.find_last_of('/');
    return i == std::string::npos ? p : p.substr(i + 1);
}

std::string extLower(const std::string& name) {
    size_t i = name.find_last_of('.');
    if (i == std::string::npos || i + 1 >= name.size()) return "";
    std::string e = name.substr(i + 1);
    std::transform(e.begin(), e.end(), e.begin(), [](unsigned char c) { return (char)std::tolower(c); });
    return e;
}

bool exists(const std::string& path) {
    struct stat st;
    return stat(path.c_str(), &st) == 0;
}

bool isDir(const std::string& path) {
    struct stat st;
    return stat(path.c_str(), &st) == 0 && S_ISDIR(st.st_mode);
}

uint64_t fileSize(const std::string& path) {
    struct stat st;
    return stat(path.c_str(), &st) == 0 ? (uint64_t)st.st_size : 0;
}

bool listDir(const std::string& path, std::vector<Entry>& out) {
    out.clear();
    DIR* d = opendir(path.c_str());
    if (!d) return false;
    while (struct dirent* e = readdir(d)) {
        std::string n = e->d_name;
        if (n == "." || n == "..") continue;
        Entry en;
        en.name = n;
        struct stat st;
        std::string full = join(path, n);
        if (stat(full.c_str(), &st) == 0) {
            en.isDir = S_ISDIR(st.st_mode);
            en.size = (uint64_t)st.st_size;
        }
        out.push_back(std::move(en));
    }
    closedir(d);
    std::sort(out.begin(), out.end(), [](const Entry& a, const Entry& b) {
        if (a.isDir != b.isDir) return a.isDir;
        return a.name < b.name;
    });
    return true;
}

bool mkdirs(const std::string& path) {
    std::string cur;
    for (size_t i = 0; i <= path.size(); i++) {
        if (i == path.size() || path[i] == '/') {
            if (!cur.empty() && cur.back() != ':' && !isDir(cur)) {
                if (mkdir(cur.c_str(), 0777) != 0 && !isDir(cur)) return false;
            }
        }
        if (i < path.size()) cur.push_back(path[i]);
    }
    return isDir(path);
}

bool renameFile(const std::string& from, const std::string& to) { return std::rename(from.c_str(), to.c_str()) == 0; }
bool removeFile(const std::string& path) { return std::remove(path.c_str()) == 0; }

bool readFile(const std::string& path, std::vector<uint8_t>& out, size_t maxBytes) {
    FILE* f = std::fopen(path.c_str(), "rb");
    if (!f) return false;
    std::fseek(f, 0, SEEK_END);
    long n = std::ftell(f);
    std::fseek(f, 0, SEEK_SET);
    if (n < 0 || (size_t)n > maxBytes) { std::fclose(f); return false; }
    out.resize((size_t)n);
    size_t got = n ? std::fread(out.data(), 1, (size_t)n, f) : 0;
    std::fclose(f);
    return got == (size_t)n;
}

bool writeFile(const std::string& path, const uint8_t* data, size_t size) {
    FILE* f = std::fopen(path.c_str(), "wb");
    if (!f) return false;
    size_t put = size ? std::fwrite(data, 1, size, f) : 0;
    bool ok = std::fclose(f) == 0;
    return ok && put == size;
}

bool copyFile(const std::string& from, const std::string& to) {
    FILE* in = std::fopen(from.c_str(), "rb");
    if (!in) return false;
    FILE* out = std::fopen(to.c_str(), "wb");
    if (!out) { std::fclose(in); return false; }
    std::vector<uint8_t> buf(1 << 16);
    bool ok = true;
    size_t n;
    while ((n = std::fread(buf.data(), 1, buf.size(), in)) > 0) {
        if (std::fwrite(buf.data(), 1, n, out) != n) { ok = false; break; }
    }
    std::fclose(in);
    if (std::fclose(out) != 0) ok = false;
    return ok;
}

bool copyTree(const std::string& from, const std::string& to) {
    if (!mkdirs(to)) return false;
    std::vector<Entry> es;
    if (!listDir(from, es)) return false;
    bool ok = true;
    for (const auto& e : es) {
        std::string a = join(from, e.name), b = join(to, e.name);
        ok = (e.isDir ? copyTree(a, b) : copyFile(a, b)) && ok;
    }
    return ok;
}

}  // namespace fsu
