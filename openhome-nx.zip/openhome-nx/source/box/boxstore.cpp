#include "box/boxstore.hpp"

#include <algorithm>
#include <cstdio>
#include <ctime>
#include <set>

#include "box/fsutil.hpp"

namespace box {

int parseSlotPrefix(const std::string& n, std::string* rest) {
    if (n.size() < 5 || n[3] != '_') return -1;
    for (int i = 0; i < 3; i++)
        if (n[i] < '0' || n[i] > '9') return -1;
    int v = (n[0] - '0') * 100 + (n[1] - '0') * 10 + (n[2] - '0');
    if (v >= kSlotsPerBox) return -1;
    if (rest) *rest = n.substr(4);
    return v;
}

Store::Store(std::string root) : root_(std::move(root)) {}

std::string Store::boxDir(int bank, int box) const {
    char b[24];
    std::snprintf(b, sizeof(b), "Box %02d", box + 1);
    return fsu::join(fsu::join(fsu::join(root_, "boxes"), banks_[bank]), b);
}

void Store::scanBanks() {
    banks_.clear();
    std::vector<fsu::Entry> es;
    if (fsu::listDir(fsu::join(root_, "boxes"), es)) {
        for (const auto& e : es)
            if (e.isDir && e.name.rfind("Bank ", 0) == 0) banks_.push_back(e.name);
    }
    // natural order: "Bank 2" before "Bank 10"
    std::sort(banks_.begin(), banks_.end(), [](const std::string& a, const std::string& b) {
        return a.size() != b.size() ? a.size() < b.size() : a < b;
    });
}

bool Store::init() {
    if (!fsu::mkdirs(fsu::join(root_, "boxes"))) return false;
    scanBanks();
    if (banks_.empty()) {
        if (!fsu::mkdirs(fsu::join(root_, "boxes/Bank 1"))) return false;
        scanBanks();
    }
    for (int b = 0; b < bankCount(); b++)
        for (int x = 0; x < kBoxesPerBank; x++)
            if (!fsu::mkdirs(boxDir(b, x))) return false;
    return !banks_.empty();
}

bool Store::addBank() {
    char n[24];
    std::snprintf(n, sizeof(n), "Bank %d", bankCount() + 1);
    if (!fsu::mkdirs(fsu::join(fsu::join(root_, "boxes"), n))) return false;
    scanBanks();
    for (int x = 0; x < kBoxesPerBank; x++) fsu::mkdirs(boxDir(bankCount() - 1, x));
    return true;
}

std::string Store::slotFile(int index, const std::string& fileName) const {
    char p[8];
    std::snprintf(p, sizeof(p), "%03d_", index);
    std::string rest;
    if (parseSlotPrefix(fileName, &rest) < 0) rest = fileName;
    return p + rest;
}

std::vector<Slot> Store::load(int bank, int box) {
    std::vector<Slot> slots;
    if (bank < 0 || bank >= bankCount() || box < 0 || box >= kBoxesPerBank) return slots;
    std::string dir = boxDir(bank, box);
    std::vector<fsu::Entry> es;
    if (!fsu::listDir(dir, es)) return slots;

    struct Pending { std::string name; int idx; };
    std::vector<Pending> keep, loose;
    std::set<int> used;
    for (const auto& e : es) {
        if (e.isDir) continue;
        if (pkm::detect(fsu::extLower(e.name), (size_t)e.size) == pkm::Format::Unknown) continue;
        int idx = parseSlotPrefix(e.name);
        if (idx >= 0 && !used.count(idx)) { used.insert(idx); keep.push_back({e.name, idx}); }
        else loose.push_back({e.name, -1});
    }
    int next = 0;
    for (auto& p : loose) {
        while (next < kSlotsPerBox && used.count(next)) next++;
        if (next >= kSlotsPerBox) break;  // box full: leave extras untouched on disk
        std::string newName = slotFile(next, p.name);
        if (fsu::renameFile(fsu::join(dir, p.name), fsu::join(dir, newName))) {
            p.name = newName;
            p.idx = next;
            used.insert(next);
            keep.push_back(p);
        }
    }
    for (const auto& p : keep) {
        std::vector<uint8_t> buf;
        std::string path = fsu::join(dir, p.name);
        if (!fsu::readFile(path, buf, 1 << 20)) continue;
        Slot s;
        s.bank = bank; s.box = box; s.index = p.idx;
        s.path = path; s.fileName = p.name;
        s.info = pkm::parse(pkm::detect(fsu::extLower(p.name), buf.size()), buf.data(), buf.size());
        slots.push_back(std::move(s));
    }
    std::sort(slots.begin(), slots.end(), [](const Slot& a, const Slot& b) { return a.index < b.index; });
    return slots;
}

int Store::countIn(int bank, int box) { return (int)load(bank, box).size(); }

std::string Store::add(int bank, int box, const std::string& fileName, const uint8_t* data, size_t size, int index) {
    auto cur = load(bank, box);
    std::set<int> used;
    for (const auto& s : cur) used.insert(s.index);
    if (index < 0) {
        index = 0;
        while (index < kSlotsPerBox && used.count(index)) index++;
    }
    if (index >= kSlotsPerBox || used.count(index)) return "";
    std::string base = fsu::baseName(fileName);  // strips any directory components
    if (base.empty() || base == "." || base == "..") return "";
    std::string dir = boxDir(bank, box);
    std::string dest = fsu::join(dir, slotFile(index, base));
    for (int n = 1; fsu::exists(dest); n++) {  // never overwrite
        std::string stem = base, ext;
        size_t dot = base.find_last_of('.');
        if (dot != std::string::npos) { stem = base.substr(0, dot); ext = base.substr(dot); }
        dest = fsu::join(dir, slotFile(index, stem + "_" + std::to_string(n) + ext));
    }
    return fsu::writeFile(dest, data, size) ? dest : "";
}

bool Store::move(const Slot& s, int bank, int box, int index) {
    if (bank < 0 || bank >= bankCount() || box < 0 || box >= kBoxesPerBank || index < 0 || index >= kSlotsPerBox)
        return false;
    for (const auto& o : load(bank, box))
        if (o.index == index) return false;
    std::string dest = fsu::join(boxDir(bank, box), slotFile(index, s.fileName));
    if (fsu::exists(dest)) return false;
    return fsu::renameFile(s.path, dest);
}

bool Store::swap(const Slot& a, const Slot& b) {
    std::string tmp = fsu::join(root_, "boxes/.swap_tmp");
    std::string da = fsu::join(boxDir(b.bank, b.box), slotFile(b.index, a.fileName));
    std::string db = fsu::join(boxDir(a.bank, a.box), slotFile(a.index, b.fileName));
    if (!fsu::renameFile(a.path, tmp)) return false;
    if (!fsu::renameFile(b.path, db)) { fsu::renameFile(tmp, a.path); return false; }
    if (!fsu::renameFile(tmp, da)) { fsu::renameFile(db, b.path); fsu::renameFile(tmp, a.path); return false; }
    return true;
}

bool Store::release(const Slot& s) {
    std::string dir = fsu::join(root_, "released");
    if (!fsu::mkdirs(dir)) return false;
    std::string rest;
    if (parseSlotPrefix(s.fileName, &rest) < 0) rest = s.fileName;
    std::string dest = fsu::join(dir, rest);
    for (int n = 1; fsu::exists(dest); n++) {
        size_t dot = rest.find_last_of('.');
        std::string stem = dot == std::string::npos ? rest : rest.substr(0, dot);
        std::string ext = dot == std::string::npos ? "" : rest.substr(dot);
        dest = fsu::join(dir, stem + "_" + std::to_string(n) + ext);
    }
    return fsu::renameFile(s.path, dest);
}

bool Store::sortBox(int bank, int box) {
    auto slots = load(bank, box);
    std::stable_sort(slots.begin(), slots.end(), [](const Slot& a, const Slot& b) {
        uint16_t sa = a.info.species ? a.info.species : 9999, sb = b.info.species ? b.info.species : 9999;
        return sa < sb;
    });
    // Two-phase rename through a temp prefix so targets never collide.
    std::vector<std::string> tmp;
    for (size_t i = 0; i < slots.size(); i++) {
        std::string t = slots[i].path + ".sorting";
        if (!fsu::renameFile(slots[i].path, t)) return false;
        tmp.push_back(t);
    }
    bool ok = true;
    for (size_t i = 0; i < slots.size(); i++) {
        std::string dest = fsu::join(boxDir(bank, box), slotFile((int)i, slots[i].fileName));
        ok = fsu::renameFile(tmp[i], dest) && ok;
    }
    return ok;
}

}  // namespace box
