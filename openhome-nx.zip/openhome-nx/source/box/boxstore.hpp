// SD-card box storage with fixed slot positions.
//
//   <root>/boxes/Bank 1/Box 01/007_Charizard.pk9     <- "NNN_" prefix = slot index 0..119
//
// Files dropped in without a prefix (from desktop OpenHome/PKHeX) are given the first free slot
// and renamed with a prefix on first load. Moving a Pokemon = renaming its file. Nothing is
// ever deleted: "release" moves the file to <root>/released/.
#pragma once
#include <string>
#include <vector>

#include "pkm/pkm.hpp"

namespace box {

constexpr int kCols = 12;
constexpr int kRows = 10;
constexpr int kSlotsPerBox = kCols * kRows;  // 120
constexpr int kBoxesPerBank = 30;

struct Slot {
    int bank = 0, box = 0, index = 0;
    std::string path;
    std::string fileName;
    pkm::Info info;
};

class Store {
public:
    explicit Store(std::string root);
    bool init();  // creates Bank 1 with all boxes if there are no banks yet

    int bankCount() const { return (int)banks_.size(); }
    const std::string& bankName(int i) const { return banks_[i]; }
    bool addBank();  // creates "Bank N+1"
    static int boxCount() { return kBoxesPerBank; }

    // Returns the occupied slots of a box (each with a unique index). Renames unprefixed files.
    std::vector<Slot> load(int bank, int box);

    // Add raw .pkN bytes to a box slot (-1 = first free). Returns new path or "".
    std::string add(int bank, int box, const std::string& fileName, const uint8_t* data, size_t size, int index = -1);

    // Move to an EMPTY destination slot.
    bool move(const Slot& s, int bank, int box, int index);
    // Swap two occupied slots (any boxes/banks).
    bool swap(const Slot& a, const Slot& b);
    // Move the file into <root>/released/ (recoverable).
    bool release(const Slot& s);
    // Reorder one box by National Dex number (stable), packing to the start.
    bool sortBox(int bank, int box);

    const std::string& root() const { return root_; }
    std::string boxDir(int bank, int box) const;
    int countIn(int bank, int box);

private:
    void scanBanks();
    std::string slotFile(int index, const std::string& fileName) const;
    std::string root_;
    std::vector<std::string> banks_;
};

// "007_Charizard.pk9" -> 7; returns -1 when there is no valid prefix.
int parseSlotPrefix(const std::string& fileName, std::string* rest = nullptr);

}  // namespace box
