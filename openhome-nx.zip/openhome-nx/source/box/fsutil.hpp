// Small POSIX file helpers (opendir/stat/rename). Used instead of std::filesystem because
// libnx's "sdmc:/" and "ohsave:/" devices behave like plain stdio/POSIX paths.
#pragma once
#include <cstdint>
#include <string>
#include <vector>

namespace fsu {

struct Entry {
    std::string name;
    bool isDir = false;
    uint64_t size = 0;
};

// Lists a directory (no "." / ".."), directories first then files, each sorted by name.
bool listDir(const std::string& path, std::vector<Entry>& out);
bool exists(const std::string& path);
bool isDir(const std::string& path);
bool mkdirs(const std::string& path);                // like mkdir -p
bool renameFile(const std::string& from, const std::string& to);
bool removeFile(const std::string& path);
bool readFile(const std::string& path, std::vector<uint8_t>& out, size_t maxBytes = 64u << 20);
bool writeFile(const std::string& path, const uint8_t* data, size_t size);
bool copyFile(const std::string& from, const std::string& to);
bool copyTree(const std::string& from, const std::string& to);  // recursive, returns false on any error
uint64_t fileSize(const std::string& path);

std::string baseName(const std::string& path);
std::string extLower(const std::string& name);  // without dot, lowercase
std::string join(const std::string& a, const std::string& b);

}  // namespace fsu
