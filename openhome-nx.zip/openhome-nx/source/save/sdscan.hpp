// Finds save files for older Pokemon games (GB/GBA/DS/3DS emulator saves) on the SD card.
// Read-only. The scanner works in small steps so the UI never freezes.
#pragma once
#include <cstdint>
#include <string>
#include <vector>

namespace save {

// Returns a human label if (extension, size) looks like a Pokemon-era save, else "".
// Detection is by file size only, so it is a hint, not proof.
std::string classifySave(const std::string& fileName, uint64_t size);

struct Found {
    std::string path;
    uint64_t size = 0;
    std::string label;
};

class Scanner {
public:
    void start(const std::string& root);
    void step(int dirBudget);  // processes up to `dirBudget` directories
    bool running() const { return !stack_.empty(); }
    const std::vector<Found>& results() const { return results_; }
    int dirsVisited() const { return visited_; }
    int otherSaves() const { return other_; }  // .sav-like files that didn't match a known size

private:
    struct Item { std::string path; int depth; };
    std::vector<Item> stack_;
    std::vector<Found> results_;
    int visited_ = 0, other_ = 0;
};

}  // namespace save
