// Switch "SCBlock" saves protected by SwishCrypto: Sword/Shield, Legends: Arceus, Scarlet/Violet and
// Legends: Z-A. Ported from PKHeX (GPL-3.0): Saves/Encryption/SwishCrypto/*.cs (SwishCrypto, SCBlock,
// SCXorShift32), Saves/SAV8SWSH.cs, SAV8LA.cs, SAV9SV.cs, SAV9ZA.cs and the SaveBlockAccessor* key tables.
//
// File layout: [ block, block, ... ][ 32-byte SHA-256 ].  The whole payload is XORed with a fixed pad
// (period 0x7F) and hashed with fixed intro/outro salts. Each block is { key u32, type byte, optional
// length fields, data } where everything after the key is XORed with a per-block xorshift stream.
//
// Reading only: the box block is decrypted into memory and Pokemon are decrypted on demand.
#include <cstring>
#include <map>

#include "pkm/pkm_internal.hpp"
#include "pkm/pkmcrypto.hpp"
#include "save/hash.hpp"
#include "save/readers.hpp"

namespace save {
namespace {

const uint8_t kIntro[64] = {
    0x9E, 0xC9, 0x9C, 0xD7, 0x0E, 0xD3, 0x3C, 0x44, 0xFB, 0x93, 0x03, 0xDC, 0xEB, 0x39, 0xB4, 0x2A,
    0x19, 0x47, 0xE9, 0x63, 0x4B, 0xA2, 0x33, 0x44, 0x16, 0xBF, 0x82, 0xA2, 0xBA, 0x63, 0x55, 0xB6,
    0x3D, 0x9D, 0xF2, 0x4B, 0x5F, 0x7B, 0x6A, 0xB2, 0x62, 0x1D, 0xC2, 0x1B, 0x68, 0xE5, 0xC8, 0xB5,
    0x3A, 0x05, 0x90, 0x00, 0xE8, 0xA8, 0x10, 0x3D, 0xE2, 0xEC, 0xF0, 0x0C, 0xB2, 0xED, 0x4F, 0x6D};
const uint8_t kOutro[64] = {
    0xD6, 0xC0, 0x1C, 0x59, 0x8B, 0xC8, 0xB8, 0xCB, 0x46, 0xE1, 0x53, 0xFC, 0x82, 0x8C, 0x75, 0x75,
    0x13, 0xE0, 0x45, 0xDF, 0x32, 0x69, 0x3C, 0x75, 0xF0, 0x59, 0xF8, 0xD9, 0xA2, 0x5F, 0xB2, 0x17,
    0xE0, 0x80, 0x52, 0xDB, 0xEA, 0x89, 0x73, 0x99, 0x75, 0x79, 0xAF, 0xCB, 0x2E, 0x80, 0x07, 0xE6,
    0xF1, 0x26, 0xE0, 0x03, 0x0A, 0xE6, 0x6F, 0xF6, 0x41, 0xBF, 0x7E, 0x59, 0xC2, 0xAE, 0x55, 0xFD};
// PKHeX's pad is 0x80 bytes with a zero last byte and is advanced by 0x7F, i.e. a period of 0x7F.
const uint8_t kPad[0x7F] = {
    0xA0, 0x92, 0xD1, 0x06, 0x07, 0xDB, 0x32, 0xA1, 0xAE, 0x01, 0xF5, 0xC5, 0x1E, 0x84, 0x4F, 0xE3,
    0x53, 0xCA, 0x37, 0xF4, 0xA7, 0xB0, 0x4D, 0xA0, 0x18, 0xB7, 0xC2, 0x97, 0xDA, 0x5F, 0x53, 0x2B,
    0x75, 0xFA, 0x48, 0x16, 0xF8, 0xD4, 0x8A, 0x6F, 0x61, 0x05, 0xF4, 0xE2, 0xFD, 0x04, 0xB5, 0xA3,
    0x0F, 0xFC, 0x44, 0x92, 0xCB, 0x32, 0xE6, 0x1B, 0xB9, 0xB1, 0x2E, 0x01, 0xB0, 0x56, 0x53, 0x36,
    0xD2, 0xD1, 0x50, 0x3D, 0xDE, 0x5B, 0x2E, 0x0E, 0x52, 0xFD, 0xDF, 0x2F, 0x7B, 0xCA, 0x63, 0x50,
    0xA4, 0x67, 0x5D, 0x23, 0x17, 0xC0, 0x52, 0xE1, 0xA6, 0x30, 0x7C, 0x2B, 0xB6, 0x70, 0x36, 0x5B,
    0x2A, 0x27, 0x69, 0x33, 0xF5, 0x63, 0x7B, 0x36, 0x3F, 0x26, 0x9B, 0xA3, 0xED, 0x7A, 0x53, 0x00,
    0xA4, 0x48, 0xB3, 0x50, 0x9E, 0x14, 0xA0, 0x52, 0xDE, 0x7E, 0x10, 0x2B, 0x1B, 0x77, 0x6E};

constexpr size_t kHash = 32;

// SCXorShift32
struct XorShift {
    uint32_t st;
    int c = 0;
    static uint32_t adv(uint32_t s) { s ^= s << 2; s ^= s >> 15; s ^= s << 13; return s; }
    explicit XorShift(uint32_t seed) : st(seed) {
        int n = 0;
        for (uint32_t v = seed; v; v &= v - 1) n++;  // popcount
        for (int i = 0; i < n; i++) st = adv(st);
    }
    uint8_t next() {
        uint8_t r = (uint8_t)(st >> (c << 3));
        if (c == 3) { st = adv(st); c = 0; }
        else c++;
        return r;
    }
    uint32_t next32() {
        uint32_t a = next(), b = next(), c2 = next(), d = next();
        return a | (b << 8) | (c2 << 16) | (d << 24);
    }
};

enum : uint8_t { kBool1 = 1, kBool2 = 2, kBool3 = 3, kObject = 4, kArray = 5 };

int typeSize(uint8_t t) {
    switch (t) {
        case 3: case 8: case 12: return 1;
        case 9: case 13: return 2;
        case 10: case 14: case 16: return 4;
        case 11: case 15: case 17: return 8;
        default: return 0;
    }
}

struct Block {
    uint32_t key = 0;
    uint8_t type = 0, sub = 0;
    size_t dataOff = 0, dataLen = 0;
};

// Is the stored hash right? (computed over the still-XORed payload, as PKHeX does)
bool hashValid(const Bytes& b) {
    if (b.size() < kHash + 8) return false;
    size_t n = b.size() - kHash;
    Bytes buf;
    buf.reserve(64 + n + 64);
    buf.insert(buf.end(), kIntro, kIntro + 64);
    buf.insert(buf.end(), b.begin(), b.begin() + (long)n);
    buf.insert(buf.end(), kOutro, kOutro + 64);
    uint8_t h[32];
    hash::sha256(buf.data(), buf.size(), h);
    return std::memcmp(h, b.data() + n, kHash) == 0;
}

// Walks the block list of the (pad-removed) payload. Every offset is bounds-checked.
bool parseBlocks(const Bytes& p, std::vector<Block>& out, std::string& why) {
    size_t off = 0, n = p.size();
    while (off < n) {
        if (n - off < 5) { why = "truncated block header"; return false; }
        Block b;
        b.key = pkm::rd32(p.data() + off);
        off += 4;
        XorShift xk(b.key);
        b.type = (uint8_t)(p[off++] ^ xk.next());
        if (b.type == kBool1 || b.type == kBool2 || b.type == kBool3) {
            b.dataOff = off;
            b.dataLen = 0;
        } else if (b.type == kObject) {
            if (n - off < 4) { why = "truncated object header"; return false; }
            uint32_t len = pkm::rd32(p.data() + off) ^ xk.next32();
            off += 4;
            if (len > n - off) { why = "object runs past the end"; return false; }
            b.dataOff = off;
            b.dataLen = len;
            off += len;
        } else if (b.type == kArray) {
            if (n - off < 5) { why = "truncated array header"; return false; }
            uint32_t cnt = pkm::rd32(p.data() + off) ^ xk.next32();
            off += 4;
            b.sub = (uint8_t)(p[off++] ^ xk.next());
            int sz = typeSize(b.sub);
            if (!sz) { why = "unknown array type"; return false; }
            uint64_t bytes = (uint64_t)cnt * (uint64_t)sz;
            if (bytes > n - off) { why = "array runs past the end"; return false; }
            b.dataOff = off;
            b.dataLen = (size_t)bytes;
            off += (size_t)bytes;
        } else {
            int sz = typeSize(b.type);
            if (!sz) { why = "unknown block type"; return false; }
            if ((size_t)sz > n - off) { why = "value runs past the end"; return false; }
            b.dataOff = off;
            b.dataLen = (size_t)sz;
            off += (size_t)sz;
        }
        out.push_back(b);
    }
    return true;
}

// Decrypts a block's data (the xorshift stream continues after the header fields).
Bytes decodeBlock(const Bytes& p, const Block& b) {
    XorShift xk(b.key);
    xk.next();  // type byte
    if (b.type == kObject) xk.next32();
    else if (b.type == kArray) { xk.next32(); xk.next(); }
    Bytes d(p.begin() + (long)b.dataOff, p.begin() + (long)(b.dataOff + b.dataLen));
    for (auto& v : d) v ^= xk.next();
    return d;
}

enum class Kind { SwSh, LA, SV, ZA };

struct Layout {
    Kind kind;
    const char* name;
    pkm::Format fmt;
    uint32_t kBox, kParty, kStatus, kNames;
    size_t stride;       // bytes per box slot
    size_t stored;       // Pokemon bytes returned to the caller
    size_t blockSize;    // crypto block size
    size_t partyStride;  // 0 = party not read
    size_t otOff;
    size_t gameOff;
};

const uint32_t kBoxNames = 0x19722C89;
const Layout kSwSh = {Kind::SwSh, "Sword / Shield", pkm::Format::PK8, 0x0D66012C, 0x2985FE5D, 0xF25C070E, kBoxNames, 344, 328, 80, 344, 0xB0, 0xA4};
const Layout kLA = {Kind::LA, "Legends: Arceus", pkm::Format::PA8, 0x47E1CEAB, 0x2985FE5D, 0xF25C070E, kBoxNames, 360, 360, 88, 376, 0x20, 0x14};
const Layout kSV = {Kind::SV, "Scarlet / Violet", pkm::Format::PK9, 0x0D66012C, 0x3AA1A9AD, 0xE3E89BD1, kBoxNames, 344, 328, 80, 344, 0x10, 0x04};
const Layout kZA = {Kind::ZA, "Legends: Z-A", pkm::Format::PA9, 0x0D66012C, 0x3AA1A9AD, 0xE3E89BD1, kBoxNames, 408, 328, 80, 0, 0x10, 0x04};

constexpr int kBoxes = 32, kPerBox = 30;

class SCSave : public SaveFile {
public:
    SCSave(const Layout& l, std::string title, std::string trainer, Bytes box, Bytes names, Bytes party, std::string notes)
        : L(l), title_(std::move(title)), trainer_(std::move(trainer)), box_(std::move(box)), names_(std::move(names)),
          party_(std::move(party)), notes_(std::move(notes)) {}

    pkm::Format format() const override { return L.fmt; }
    std::string title() const override { return title_; }
    std::string trainer() const override { return trainer_; }
    int boxCount() const override { return kBoxes; }
    int boxSlots() const override { return kPerBox; }
    std::string notes() const override { return notes_; }

    std::string boxName(int box) const override {
        std::string def = SaveFile::boxName(box);
        size_t at = 0x22 * (size_t)(box < 0 ? 0 : box);
        if (box < 0 || box >= kBoxes || at + 0x22 > names_.size()) return def;
        if (pkm::rd16(names_.data() + at) == 0) return def;
        std::u16string s;
        for (int i = 0; i < 17; i++) {
            uint16_t c = pkm::rd16(names_.data() + at + (size_t)i * 2);
            if (!c) break;
            s.push_back((char16_t)c);
        }
        std::string u = pkm::utf16ToUtf8(s);
        return u.empty() ? def : u;
    }

    int partyCount() const override {
        if (!L.partyStride || party_.size() <= 6 * L.partyStride) return 0;
        int c = party_[6 * L.partyStride];
        return c < 0 ? 0 : c > 6 ? 6 : c;
    }

    bool readBox(int box, int slot, std::vector<uint8_t>& out) const override {
        if (box < 0 || box >= kBoxes || slot < 0 || slot >= kPerBox) return false;
        size_t off = ((size_t)box * kPerBox + (size_t)slot) * L.stride;
        if (off + L.stored > box_.size()) return false;
        return decodeMon(box_.data() + off, out);
    }

    bool readParty(int index, std::vector<uint8_t>& out) const override {
        if (index < 0 || index >= partyCount()) return false;
        size_t off = (size_t)index * L.partyStride;
        if (off + L.stored > party_.size()) return false;
        return decodeMon(party_.data() + off, out);
    }

private:
    bool decodeMon(const uint8_t* src, std::vector<uint8_t>& out) const {
        uint8_t m[360];
        std::memcpy(m, src, L.stored);
        bool zero = true;
        for (size_t i = 0; i < L.stored && zero; i++) zero = m[i] == 0;
        if (zero) return false;
        if (!pkm::crypto::decryptBlocks(m, L.stored, L.blockSize)) return false;
        if (pkm::rd16(m + 8) == 0) return false;  // no species = empty slot
        out.assign(m, m + L.stored);
        return true;
    }

    Layout L;
    std::string title_, trainer_;
    Bytes box_, names_, party_;
    std::string notes_;
};

}  // namespace

SavePtr openSCBlock(const Bytes& b, const std::string&, const Game* hint, std::string& err) {
    err.clear();
    if (b.size() < 0x1000 || b.size() > (64u << 20)) return nullptr;
    if (!hashValid(b)) return nullptr;  // not an SCBlock save (or damaged: nothing here to read anyway)

    Bytes p(b.begin(), b.end() - (long)kHash);
    for (size_t i = 0; i < p.size(); i++) p[i] ^= kPad[i % 0x7F];

    std::vector<Block> blocks;
    std::string why;
    if (!parseBlocks(p, blocks, why)) { err = "Switch save container is damaged (" + why + ")"; return nullptr; }
    std::map<uint32_t, size_t> byKey;
    for (size_t i = 0; i < blocks.size(); i++) byKey.emplace(blocks[i].key, i);
    auto has = [&](uint32_t k) { return byKey.count(k) != 0; };

    const Layout* L = nullptr;
    if (has(0x47E1CEAB) && has(kSwSh.kStatus)) L = &kLA;
    else if (has(0x0D66012C) && has(kSwSh.kStatus) && has(kSwSh.kParty)) L = &kSwSh;
    else if (has(0x0D66012C) && has(kSV.kStatus)) L = has(0x2D87BE5C) && !has(0x0DEAAEBD) ? &kZA : &kSV;
    if (!L) { err = "This Switch save is not one of the supported Pokemon games"; return nullptr; }

    auto get = [&](uint32_t k, Bytes& out) {
        auto it = byKey.find(k);
        if (it == byKey.end()) return false;
        out = decodeBlock(p, blocks[it->second]);
        return true;
    };
    Bytes box, names, status, party;
    if (!get(L->kBox, box) || !get(L->kStatus, status) || !get(L->kNames, names)) {
        err = "Save is missing its box or trainer data";
        return nullptr;
    }
    // Scarlet/Violet and Z-A share their keys; tell them apart by the size of one box slot (344 vs 408 bytes).
    if (L->kind == Kind::SV || L->kind == Kind::ZA) {
        size_t per = box.size() / ((size_t)kBoxes * kPerBox);
        if (per >= 400) L = &kZA;
        else if (per >= 340) L = &kSV;
        if (L->kind == Kind::ZA) get(L->kParty, party);
    }
    if (box.size() < (size_t)kBoxes * kPerBox * L->stride - (L->stride - L->stored)) {
        err = "Box data is smaller than expected (" + std::to_string(box.size()) + " bytes in " + L->name + " layout)";
        return nullptr;
    }
    get(L->kParty, party);

    std::string title = L->name;
    uint8_t game = L->gameOff < status.size() ? status[L->gameOff] : 0;
    switch (L->kind) {
        case Kind::SwSh: title = game == 44 ? "Sword" : game == 45 ? "Shield" : title; break;
        case Kind::SV: title = game == 50 ? "Scarlet" : game == 51 ? "Violet" : title; break;
        default: break;
    }
    if (hint && hint->name && title == L->name) title = hint->name;

    std::u16string ot;
    if (L->otOff + 0x1A <= status.size())
        for (int i = 0; i < 13; i++) {
            uint16_t c = pkm::rd16(status.data() + L->otOff + (size_t)i * 2);
            if (!c) break;
            ot.push_back((char16_t)c);
        }
    std::string notes = "Switch save, " + std::to_string(blocks.size()) + " data blocks, checksum OK";
    return SavePtr(new SCSave(*L, title, pkm::utf16ToUtf8(ot), std::move(box), std::move(names), std::move(party), notes));
}

}  // namespace save
