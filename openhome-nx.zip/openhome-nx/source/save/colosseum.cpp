// Pokemon Colosseum (GameCube) save reader. Ported from PKHeX's SAV3Colosseum / ColoCrypto / SAV3GCMemoryCard /
// CK3 (GPL-3.0). Accepts a .gci file (0x40-byte header + 0x60000), a raw 0x60000 save image, or a whole
// GameCube memory card image (.raw / .gcp / .mcd) that contains a Colosseum save.
//
// The save holds three 0x1E000-byte slots from 0x6000. The newest slot (highest counter at +4) is read. It is
// encrypted with a chained SHA-1 xor stream keyed by the hash stored in its last 20 bytes. Pokemon are stored in
// the 312-byte big-endian CK3 layout and are converted to standard 80-byte .pk3 data on the way out, so they go
// into OpenHome banks like any other Gen 3 Pokemon. Reading only: Colosseum saves cannot be written back.
#include <cstring>

#include "pkm/data.h"
#include "pkm/pkm_internal.hpp"
#include "save/hash.hpp"
#include "save/readers.hpp"

namespace save {
namespace {

constexpr size_t kSaveSize = 0x60000;
constexpr size_t kSlotStart = 0x6000;
constexpr size_t kSlotSize = 0x1E000;
constexpr int kSlots = 3;
constexpr size_t kCk3 = 312;
constexpr size_t kPartyAt = 0xA8;
constexpr size_t kBoxAt = 0xB90;
constexpr size_t kBoxStride = 0x24A4;
constexpr int kBoxes = 3;
constexpr int kBoxMons = 30;

uint16_t be16(const uint8_t* p) { return (uint16_t)(p[0] << 8 | p[1]); }
uint32_t be32(const uint8_t* p) { return (uint32_t)p[0] << 24 | (uint32_t)p[1] << 16 | (uint32_t)p[2] << 8 | p[3]; }
void wbe32(uint8_t* p, uint32_t v) { p[0] = (uint8_t)(v >> 24); p[1] = (uint8_t)(v >> 16); p[2] = (uint8_t)(v >> 8); p[3] = (uint8_t)v; }

bool isColoCode(const uint8_t* p) { return p[0] == 'G' && p[1] == 'C' && p[2] == '6' && (p[3] == 'J' || p[3] == 'E' || p[3] == 'P'); }

// The slot is decrypted in place. `s` points at the 0x1E000-byte slot.
void decryptSlot(uint8_t* s) {
    uint8_t digest[20], hash[20];
    for (int i = 0; i < 20; i++) digest[i] = (uint8_t)~s[kSlotSize - 20 + i];
    uint8_t* p = s + 0x18;
    size_t left = kSlotSize - 20 - 0x18;
    while (left >= 20) {
        hash::sha1(p, 20, hash);  // hash of the still-encrypted bytes feeds the next round
        for (int j = 0; j < 20; j++) p[j] ^= digest[j];
        std::memcpy(digest, hash, 20);
        p += 20;
        left -= 20;
    }
}

int32_t headerChecksum(const uint8_t* s, const uint8_t* hash) {
    int32_t r = 0;
    for (int i = 0; i < 0x18; i += 4) r -= (int32_t)be32(s + i);
    r -= (int32_t)(be32(s + 0x18) ^ ~be32(hash));
    r -= (int32_t)(be32(s + 0x1C) ^ ~be32(hash + 4));
    return r;
}

// Validates a DEcrypted slot: SHA-1 over everything before the last 40 bytes, and the header checksum.
bool slotValid(uint8_t* dec, bool& headerOk) {
    // Both checksums are computed with the header-checksum word (0x0C) zeroed; it is put back afterwards.
    uint32_t old = be32(dec + 0x0C);
    wbe32(dec + 0x0C, 0);
    uint8_t h[20];
    hash::sha1(dec, kSlotSize - 40, h);
    headerOk = (uint32_t)headerChecksum(dec, h) == old;
    wbe32(dec + 0x0C, old);
    return std::memcmp(h, dec + kSlotSize - 20, 20) == 0;
}

// GameCube text (UTF-16 big endian) -> Gen 3 byte text, via the same tables the .pk3 reader uses.
bool g3Map(bool jp, char16_t c, uint8_t& out) {
    static char16_t tab[2][256];
    static bool built = false;
    if (!built) {
        for (int j = 0; j < 2; j++)
            for (int b = 0; b < 256; b++) {
                uint8_t one = (uint8_t)b;
                std::u16string s = pkm::gen3String(&one, 1, j == 1);
                tab[j][b] = s.empty() ? 0 : s[0];
            }
        built = true;
    }
    for (int b = 0; b < 255; b++)
        if (tab[jp ? 1 : 0][b] == c && c != 0) { out = (uint8_t)b; return true; }
    return false;
}

void gcText(const uint8_t* src, size_t chars, bool jp, uint8_t* dest, size_t destLen) {
    std::memset(dest, 0xFF, destLen);
    size_t i = 0;
    for (; i < chars && i < destLen; i++) {
        char16_t c = (char16_t)be16(src + i * 2);
        if (c == 0) break;
        uint8_t b;
        dest[i] = g3Map(jp, c, b) ? b : 0xB7;
    }
}

uint16_t internalToNational(uint16_t id) { return id < ohnx::kGen3ToNationalCount ? ohnx::kGen3ToNational[id] : 0; }

// CK3 (312 bytes, big endian) -> logical PK3 (100 bytes: 80 stored + party stats).
bool ck3ToPk3(const uint8_t* c, std::vector<uint8_t>& out) {
    uint16_t sp = be16(c);
    if (sp == 0 || internalToNational(sp) == 0) return false;
    out.assign(100, 0);
    uint8_t* d = out.data();
    uint8_t gcLang = c[0x0B];
    static const uint8_t langMap[8] = {0, 1, 2, 5, 3, 4, 7, 0};  // GC: JPN ENG GER FRE ITA SPA -> GBA language ids
    uint8_t lang = gcLang < 8 ? langMap[gcLang] : 0;
    bool jp = c[0x09] == 1 || gcLang == 1;
    pkm::wr32(d, be32(c + 4));
    pkm::wr16(d + 4, be16(c + 0x16));  // TID
    pkm::wr16(d + 6, be16(c + 0x14));  // SID
    gcText(c + 0x44, 10, jp, d + 0x08, 10);
    d[0x12] = lang;
    bool egg = c[0xCB] == 1;
    d[0x13] = (uint8_t)(2 | (egg ? 4 : 0));
    gcText(c + 0x18, 7, jp, d + 0x14, 7);
    d[0x1B] = 0;
    pkm::wr16(d + 0x20, sp);
    uint16_t item = be16(c + 0x88);
    pkm::wr16(d + 0x22, item <= 346 ? item : 0);
    pkm::wr32(d + 0x24, be32(c + 0x5C));
    uint8_t ppb = 0;
    for (int m = 0; m < 4; m++) {
        pkm::wr16(d + 0x2C + m * 2, be16(c + 0x78 + m * 4));
        d[0x34 + m] = c[0x7A + m * 4];
        ppb |= (uint8_t)((c[0x7B + m * 4] & 3) << (m * 2));
    }
    d[0x28] = ppb;
    d[0x29] = (uint8_t)std::min<uint16_t>(0xFF, be16(c + 0xB0));
    // EVs are stored HP, Atk, Def, SpA, SpD, Spe; Gen 3 wants HP, Atk, Def, Spe, SpA, SpD
    auto ev = [&](int at) { return (uint8_t)std::min<uint16_t>(255, be16(c + at)); };
    d[0x38] = ev(0x98); d[0x39] = ev(0x9A); d[0x3A] = ev(0x9C);
    d[0x3B] = ev(0xA2); d[0x3C] = ev(0x9E); d[0x3D] = ev(0xA0);
    for (int i = 0; i < 5; i++) d[0x3E + i] = c[0xB2 + i];
    d[0x43] = c[0xBC];
    d[0x44] = c[0xCA] & 0xF;
    d[0x45] = (uint8_t)be16(c + 0x0C);
    uint8_t gcGame = c[0x08];
    static const uint8_t gameMap[12] = {0, 4, 5, 0, 0, 0, 0, 0, 1, 2, 3, 15};
    uint8_t game = gcGame < 12 ? gameMap[gcGame] : 0;
    uint16_t origins = (uint16_t)((c[0x0E] & 0x7F) | (game & 15) << 7 | (c[0x0F] & 15) << 11 | (c[0x10] & 1) << 15);
    pkm::wr16(d + 0x46, origins);
    auto iv = [&](int at) { return (uint32_t)std::min<uint16_t>(31, be16(c + at)); };
    uint32_t ivs = iv(0xA4) | iv(0xA6) << 5 | iv(0xA8) << 10 | iv(0xAE) << 15 | iv(0xAA) << 20 | iv(0xAC) << 25;
    if (egg) ivs |= 1u << 30;
    if (c[0xCC] == 1) ivs |= 1u << 31;
    pkm::wr32(d + 0x48, ivs);
    // party stats
    d[0x54] = c[0x60];
    pkm::wr16(d + 0x56, be16(c + 0x8A));
    pkm::wr16(d + 0x58, be16(c + 0x8C));
    pkm::wr16(d + 0x5A, be16(c + 0x8E));
    pkm::wr16(d + 0x5C, be16(c + 0x90));
    pkm::wr16(d + 0x5E, be16(c + 0x96));
    pkm::wr16(d + 0x60, be16(c + 0x92));
    pkm::wr16(d + 0x62, be16(c + 0x94));
    pkm::wr16(d + 0x1C, pkm::gen3Checksum(d));
    return true;
}

class ColosseumSave : public SaveFile {
public:
    ColosseumSave(std::vector<uint8_t> slot, std::string how) : s_(std::move(slot)), how_(std::move(how)) {
        std::memcpy(&region_, s_.data() + 0x09, 1);
        jp_ = s_[0x0B] == 1;
        for (int i = 0; i < 6; i++)
            if (be16(s_.data() + kPartyAt + i * kCk3)) party_++;
    }
    pkm::Format format() const override { return pkm::Format::PK3; }
    std::string title() const override { return "Pokemon Colosseum (GameCube)"; }
    std::string trainer() const override {
        uint8_t t[22];
        std::memcpy(t, s_.data() + 0x78, 20);
        std::u16string u;
        for (int i = 0; i < 10; i++) {
            char16_t c = (char16_t)be16(t + i * 2);
            if (!c) break;
            u.push_back(c);
        }
        return pkm::utf16ToUtf8(u);
    }
    int boxCount() const override { return kBoxes; }
    int boxSlots() const override { return kBoxMons; }
    std::string boxName(int box) const override {
        if (box < 0 || box >= kBoxes) return "";
        const uint8_t* p = s_.data() + kBoxAt + kBoxStride * box;
        std::u16string u;
        for (int i = 0; i < 8; i++) {
            char16_t c = (char16_t)be16(p + i * 2);
            if (!c) break;
            u.push_back(c);
        }
        return u.empty() ? "Box " + std::to_string(box + 1) : pkm::utf16ToUtf8(u);
    }
    int partyCount() const override { return party_; }
    std::string notes() const override {
        return how_ + ". Shadow Pokemon are shown like any other. Read-only: Colosseum saves are never written.";
    }
    bool readBox(int box, int slot, std::vector<uint8_t>& out) const override {
        if (box < 0 || box >= kBoxes || slot < 0 || slot >= kBoxMons) return false;
        size_t at = kBoxAt + kBoxStride * box + 0x14 + kCk3 * slot;
        if (!ck3ToPk3(s_.data() + at, out)) return false;
        out.resize(80);
        return true;
    }
    bool readParty(int i, std::vector<uint8_t>& out) const override {
        if (i < 0 || i >= 6) return false;
        return ck3ToPk3(s_.data() + kPartyAt + kCk3 * i, out);
    }

private:
    std::vector<uint8_t> s_;
    std::string how_;
    uint8_t region_ = 0;
    bool jp_ = false;
    int party_ = 0;
};

// Finds the 0x60000-byte save image in .gci / raw / memory card bytes. Returns false if this is not Colosseum.
bool locate(const Bytes& b, size_t& at, std::string& how) {
    auto looksRaw = [&](size_t o) {
        if (o + kSaveSize > b.size()) return false;
        for (int i = 0; i < kSlots; i++)
            if (pkm::rd32(b.data() + o + kSlotStart + kSlotSize * i) != 0x00000101u) return false;
        return true;
    };
    if (b.size() == kSaveSize + 0x40 && isColoCode(b.data()) && looksRaw(0x40)) { at = 0x40; how = "Colosseum .gci file"; return true; }
    if (b.size() == kSaveSize && looksRaw(0)) { at = 0; how = "Colosseum raw save"; return true; }
    // memory card image
    size_t n = b.size();
    if (n >= 0x80000 && (n & (n - 1)) == 0 && n >= 5 * 0x2000) {
        const uint8_t* d = b.data();
        if (be16(d + 0x22) != n / 0x2000 / 16) return false;
        // use the directory (block 1) or its backup (block 2), whichever has the higher update counter
        size_t dir = be16(d + 2 * 0x2000 + 0x1FFA) > be16(d + 0x2000 + 0x1FFA) ? 2 * 0x2000 : 0x2000;
        for (int i = 0; i < 127; i++) {
            const uint8_t* e = d + dir + i * 0x40;
            if (!isColoCode(e)) continue;
            size_t first = be16(e + 0x36), count = be16(e + 0x38);
            if (first < 5 || (first + count) * 0x2000 > n || count * 0x2000 < kSaveSize) continue;
            if (!looksRaw(first * 0x2000)) continue;
            at = first * 0x2000;
            how = "Colosseum save inside a memory card";
            return true;
        }
    }
    return false;
}

}  // namespace

SavePtr openColosseum(const Bytes& b, const std::string&, const Game*, std::string& err) {
    err.clear();
    size_t at = 0;
    std::string how;
    if (!locate(b, at, how)) return nullptr;
    int best = -1;
    int32_t bestCtr = -1;
    for (int i = 0; i < kSlots; i++) {
        int32_t ctr = (int32_t)be32(b.data() + at + kSlotStart + kSlotSize * i + 4);
        if (ctr > bestCtr) { bestCtr = ctr; best = i; }
    }
    if (best < 0) { err = "Colosseum save has no valid slot"; return nullptr; }
    std::vector<uint8_t> slot(b.begin() + at + kSlotStart + kSlotSize * best,
                              b.begin() + at + kSlotStart + kSlotSize * (best + 1));
    decryptSlot(slot.data());
    bool headerOk = false;
    if (!slotValid(slot.data(), headerOk)) {
        err = "Colosseum save failed its checksum (the file may be damaged or from a hacked save)";
        return nullptr;
    }
    if (!headerOk) how += " (header checksum differs; body is fine)";
    return SavePtr(new ColosseumSave(std::move(slot), how));
}

}  // namespace save
