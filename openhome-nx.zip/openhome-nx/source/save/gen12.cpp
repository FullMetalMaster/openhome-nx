// Gen 1-2 (Game Boy) save reader. NOT IMPLEMENTED YET: declines silently so other families get a chance.
#include "save/readers.hpp"

namespace save {

SavePtr openGen12(const std::vector<uint8_t>&, const std::string&, const Game*, std::string&) { return nullptr; }

}  // namespace save
