#include "save/savemount.hpp"

#include <cctype>
#include <cstdio>
#include <ctime>

#include "box/fsutil.hpp"

#ifdef __SWITCH__
#include <switch.h>
#endif

namespace save {

static User g_user;
static bool g_haveUser = false;

void setUser(const User& u) { g_user = u; g_haveUser = true; }
bool haveUser() { return g_haveUser; }
const User& currentUser() { return g_user; }

std::string resultText(uint32_t rc) {
    char b[32];
    std::snprintf(b, sizeof(b), "%04u-%04u (0x%X)", 2000 + (rc & 0x1FF), (rc >> 9) & 0x1FFF, rc);
    return b;
}

#ifdef __SWITCH__
static bool g_acct = false;
static bool g_mounted = false;
static const char* kDev = "ohsave";

static AccountUid toUid(const User& u) {
    AccountUid a;
    a.uid[0] = u.uid[0];
    a.uid[1] = u.uid[1];
    return a;
}

std::vector<User> listUsers(std::string& error) {
    std::vector<User> out;
    if (!g_acct) {
        Result rc = accountInitialize(AccountServiceType_Application);
        if (R_FAILED(rc)) rc = accountInitialize(AccountServiceType_System);
        if (R_FAILED(rc)) { error = "Account service failed: " + resultText(rc); return out; }
        g_acct = true;
    }
    AccountUid uids[ACC_USER_LIST_SIZE];
    s32 n = 0;
    Result rc = accountListAllUsers(uids, ACC_USER_LIST_SIZE, &n);
    if (R_FAILED(rc)) { error = "Listing users failed: " + resultText(rc); return out; }
    for (s32 i = 0; i < n; i++) {
        User u;
        u.uid[0] = uids[i].uid[0];
        u.uid[1] = uids[i].uid[1];
        u.name = "User " + std::to_string(i + 1);
        AccountProfile prof;
        if (R_SUCCEEDED(accountGetProfile(&prof, uids[i]))) {
            AccountProfileBase base;
            if (R_SUCCEEDED(accountProfileGet(&prof, nullptr, &base)) && base.nickname[0]) u.name = base.nickname;
            accountProfileClose(&prof);
        }
        out.push_back(u);
    }
    if (out.empty()) error = "No user profiles found";
    return out;
}

MountResult mount(const Game& game) {
    MountResult r;
    if (!g_haveUser) { r.error = "No user selected"; return r; }
    unmount();
    Result rc = fsdevMountSaveData(kDev, game.titleId, toUid(g_user));
    if (R_FAILED(rc)) {
        r.error = "Could not open the save for " + std::string(game.name) + ": " + resultText(rc) +
                  ". Is the game installed, and has this user played it?";
        return r;
    }
    g_mounted = true;
    r.ok = true;
    r.device = kDev;
    return r;
}

void unmount() {
    if (g_mounted) { fsdevUnmountDevice(kDev); g_mounted = false; }
}

bool commit() { return g_mounted && R_SUCCEEDED(fsdevCommitDevice(kDev)); }

#else  // ---------- host stubs (desktop testing) ----------
std::vector<User> listUsers(std::string&) {
    User a, b;
    a.name = "Wayne"; a.uid[0] = 1;
    b.name = "Guest"; b.uid[0] = 2;
    return {a, b};
}
MountResult mount(const Game& g) {
    MountResult r;
    r.error = "Could not open the save for " + std::string(g.name) + ": 2002-0001 (host stub)";
    return r;
}
void unmount() {}
bool commit() { return false; }
#endif

std::string backup(const Game& game, const std::string& sdRoot, std::string& error) {
    char stamp[32];
    std::time_t t = std::time(nullptr);
    std::strftime(stamp, sizeof(stamp), "%Y%m%d-%H%M%S", std::localtime(&t));
    std::string name;
    for (const char* p = game.name; *p; ++p) name.push_back(std::isalnum((unsigned char)*p) ? *p : '_');
    std::string dest = fsu::join(fsu::join(fsu::join(sdRoot, "backups"), name), stamp);
    if (!fsu::mkdirs(dest)) { error = "Could not create " + dest; return ""; }
    if (!fsu::copyTree("ohsave:/", dest)) { error = "Copying the save failed part-way; backup is incomplete"; return ""; }
    return dest;
}

}  // namespace save
