// Small dependency-free hashes needed by save formats.
#pragma once
#include <cstddef>
#include <cstdint>

namespace save {
namespace hash {

void sha256(const uint8_t* data, size_t len, uint8_t out[32]);
void sha1(const uint8_t* data, size_t len, uint8_t out[20]);
void md5(const uint8_t* data, size_t len, uint8_t out[16]);
uint16_t crc16ccitt(const uint8_t* data, size_t len, uint16_t init = 0xFFFF);  // poly 0x1021, MSB first
uint32_t crc32(const uint8_t* data, size_t len);                              // IEEE, as in zlib

}  // namespace hash
}  // namespace save
