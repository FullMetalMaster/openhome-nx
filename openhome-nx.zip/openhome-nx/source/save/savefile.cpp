#include "save/savefile.hpp"

#include "save/readers.hpp"

namespace save {

SavePtr open(const std::vector<uint8_t>& bytes, const std::string& fileName, const Game* hint, std::string& err) {
    err.clear();
    if (bytes.size() < 0x1000) { err = "File is too small to be a save"; return nullptr; }
    using Opener = SavePtr (*)(const std::vector<uint8_t>&, const std::string&, const Game*, std::string&);
    static const Opener openers[] = {openColosseum, openGen3, openGen12, openGen45, openGen67, openBDSP, openSCBlock};
    for (Opener o : openers) {
        std::string e;
        SavePtr s = o(bytes, fileName, hint, e);
        if (s) return s;
        if (!e.empty()) { err = e; return nullptr; }  // the family claimed it but could not read it
    }
    err = "This is not a save the app can read yet. Supported so far: Pokemon Colosseum (.gci / memory card), Gen 3 (Ruby/Sapphire/Emerald/FireRed/LeafGreen, Emerald Seaglass-style hacks) and the Switch games (Sword/Shield, Legends: Arceus, Brilliant Diamond/Shining Pearl, Scarlet/Violet, Legends: Z-A).";
    return nullptr;
}

}  // namespace save
