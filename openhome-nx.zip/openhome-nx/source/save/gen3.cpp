// Generation 3 save reader: Ruby / Sapphire / Emerald / FireRed / LeafGreen (GBA battery saves).
// Layout follows PKHeX's SAV3*.cs (GPL-3.0): a save is two copies ("slots") of 14 sections of
// 4096 bytes. Each section ends with a footer: id (0xFF4), checksum (0xFF6), signature
// 0x08012025 (0xFF8), save counter (0xFFC). The copy with the newer counter is the live one.
// The same 128 KB image is used by FireRed/LeafGreen on Switch, and is also looked for inside
// larger files (flash dumps, containers).
#include <cstring>

#include "pkm/data.h"
#include "pkm/pkm_internal.hpp"
#include "save/readers.hpp"

namespace save {

static Gen3Species g_species = Gen3Species::Auto;
void setGen3Species(Gen3Species m) { g_species = m; }
Gen3Species gen3Species() { return g_species; }

namespace {

// National Dex number -> vanilla Gen 3 internal species number (0 if Gen 3 cannot hold it).
uint16_t nationalToInternal(uint16_t nat) {
    static uint16_t table[387];
    static bool built = false;
    if (!built) {
        for (unsigned i = 1; i < ohnx::kGen3ToNationalCount; i++) {
            uint16_t n = ohnx::kGen3ToNational[i];
            if (n >= 1 && n <= 386 && !table[n]) table[n] = (uint16_t)i;
        }
        built = true;
    }
    return nat >= 1 && nat <= 386 ? table[nat] : 0;
}

// Species number used by Complete-Fire-Red-Upgrade hacks -> National Dex number (0 = not known).
// Anchors (CFRU include/constants/species.h): Celebi 251, Treecko 277 ... Chimecho 411, Egg 412, Unown forms
// 413-439, Turtwig 440 ... Arceus 546, Victini 547 ... Genesect 702, Chespin 758 ... Volcanion 829,
// Rowlet 939 ... Xurkitree 1013. Gen 4, 5, 6 and 7 species are consecutive inside those ranges.
// Alternate forms and anything later are NOT mapped here (they get a placeholder sprite).
uint16_t cfruToNational(uint16_t id) {
    if (id >= 1 && id <= 251) return id;
    if (id >= 277 && id <= 411) return id < ohnx::kGen3ToNationalCount ? ohnx::kGen3ToNational[id] : 0;
    if (id >= 440 && id <= 546) return (uint16_t)(387 + (id - 440));
    if (id >= 547 && id <= 702) return (uint16_t)(494 + (id - 547));
    if (id >= 758 && id <= 829) return (uint16_t)(650 + (id - 758));
    if (id >= 939 && id <= 1013) return (uint16_t)(722 + (id - 939));
    return 0;
}

constexpr size_t kSector = 0x1000;
constexpr int kSections = 14;
constexpr size_t kSlotSize = kSections * kSector;  // 0xE000
constexpr uint32_t kSignature = 0x08012025;
constexpr size_t kMonSize = 80;
constexpr size_t kPartyMonSize = 100;
constexpr int kBoxes = 14;
constexpr int kBoxMons = 30;
constexpr size_t kStorageMonsAt = 4;                            // first 4 bytes: current box
constexpr size_t kStorageNamesAt = 4 + 80 * kBoxes * kBoxMons;  // 9 bytes per box name

const uint16_t kLen[kSections] = {3884, 3968, 3968, 3968, 3848, 3968, 3968, 3968, 3968, 3968, 3968, 3968, 3968, 2000};

uint16_t sectionSum(const uint8_t* p, size_t len) {
    uint32_t s = 0;
    for (size_t i = 0; i + 4 <= len; i += 4) s += pkm::rd32(p + i);
    return (uint16_t)(s + (s >> 16));
}

struct Slot {
    bool ok = false;           // 14 sections with unique ids and the signature
    size_t phys[kSections] = {};  // absolute file offset of each section id
    uint32_t counter = 0;
    int validSums = 0;
};

Slot probe(const Bytes& b, size_t base) {
    Slot s;
    if (base > b.size() || b.size() - base < kSlotSize) return s;
    bool seen[kSections] = {};
    for (int i = 0; i < kSections; i++) {
        const uint8_t* sec = b.data() + base + (size_t)i * kSector;
        if (pkm::rd32(sec + 0xFF8) != kSignature) return s;
        unsigned id = pkm::rd16(sec + 0xFF4);
        if (id >= (unsigned)kSections || seen[id]) return s;
        seen[id] = true;
        s.phys[id] = base + (size_t)i * kSector;
        if (pkm::rd16(sec + 0xFF6) == sectionSum(sec, kLen[id])) s.validSums++;
        if (id == 0) s.counter = pkm::rd32(sec + 0xFFC);
    }
    s.ok = true;
    return s;
}

bool better(const Slot& x, const Slot& y) {  // is x a better "live" copy than y?
    bool fx = x.validSums == kSections, fy = y.validSums == kSections;
    if (fx != fy) return fx;
    if (x.counter != y.counter) return x.counter > y.counter;
    return x.validSums > y.validSums;
}

bool allZero(const uint8_t* p, size_t n) {
    for (size_t i = 0; i < n; i++)
        if (p[i]) return false;
    return true;
}

class Gen3Save : public SaveFile {
public:
    Gen3Save(Bytes img, size_t origin, const Slot& active, const Game* hint)
        : img_(std::move(img)), origin_(origin), active_(active) {
        const uint8_t* s0 = img_.data() + active_.phys[0];
        uint32_t code = pkm::rd32(s0 + 0xAC);
        kind_ = code == 0 ? 0 : code == 1 ? 1 : 2;
        const char* hn = hint ? hint->name : "";
        if (kind_ == 1)
            title_ = std::strstr(hn, "LeafGreen") ? "LeafGreen (Gen 3)"
                     : std::strstr(hn, "FireRed") ? "FireRed (Gen 3)" : "FireRed / LeafGreen (Gen 3)";
        else
            title_ = kind_ == 0 ? "Ruby / Sapphire (Gen 3)" : "Emerald (Gen 3)";
        trainer_ = pkm::utf16ToUtf8(pkm::gen3String(s0, 7, false));
        autoDetected_ = false;
        if (g_species == Gen3Species::Expansion) mode_ = Gen3Species::Expansion;
        else if (g_species == Gen3Species::Cfru) mode_ = Gen3Species::Cfru;
        else if (g_species == Gen3Species::Auto) {
            // Vanilla Gen 3 never stores species 252..276 or above 411. Seeing 252..276 means National Dex numbering
            // (pokeemerald-expansion). Seeing numbers above 411 means a hack: FireRed hacks (Unbound and friends,
            // built on CFRU) append later generations after the Gen 3 block, Emerald hacks use National Dex numbers.
            bool low = false, high = false;
            std::vector<uint8_t> m;
            auto look = [&](bool ok) {
                if (!ok) return;
                uint16_t sp = pkm::rd16(m.data() + 0x20);
                if (sp >= 252 && sp <= 276) low = true;
                if (sp > 411) high = true;
            };
            for (int b = 0; b < kBoxes; b++)
                for (int sl = 0; sl < kBoxMons; sl++) look(readBox(b, sl, m));
            for (int i = 0; i < partyCount(); i++) look(readParty(i, m));
            if (low) mode_ = Gen3Species::Expansion;
            else if (high) mode_ = kind_ == 1 ? Gen3Species::Cfru : Gen3Species::Expansion;
            autoDetected_ = mode_ != Gen3Species::Vanilla;
        }
        if (mode_ == Gen3Species::Expansion) title_ += " - expanded species (Seaglass-style)";
        else if (mode_ == Gen3Species::Cfru) title_ += " - FireRed hack numbering (Unbound-style)";
    }

    pkm::Info describe(const std::vector<uint8_t>& mon) const override {
        pkm::Info i = pkm::parse(pkm::Format::PK3, mon.data(), mon.size());
        if (mode_ == Gen3Species::Vanilla || mon.size() < kMonSize) return i;
        uint16_t raw = pkm::rd16(mon.data() + 0x20);
        uint16_t nat = mode_ == Gen3Species::Cfru ? cfruToNational(raw) : (raw <= 1025 ? raw : 0);  // Expansion stores the National Dex number
        i.valid = raw >= 1 && raw <= 1300;
        i.species = nat;
        i.rawSpecies = nat ? 0 : (i.valid ? raw : 0);  // no official art: the UI shows a placeholder / your own sprite
        i.level = 0;
        if (nat && i.exp) i.level = pkm::levelFromExp(nat, i.exp);
        if (mon.size() >= 100 && mon[0x54] >= 1 && mon[0x54] <= 100) i.level = mon[0x54];
        return i;
    }

    bool exportMon(const std::vector<uint8_t>& mon, std::vector<uint8_t>& out, std::string& why) const override {
        out = mon;
        if (mode_ == Gen3Species::Vanilla || mon.size() < kMonSize) return true;
        uint16_t raw = pkm::rd16(mon.data() + 0x20);
        uint16_t nat = mode_ == Gen3Species::Cfru ? cfruToNational(raw) : raw;
        uint16_t internal = nationalToInternal(nat);
        if (!internal) {
            why = nat ? "Species #" + std::to_string(nat) + " does not exist in Gen 3, so it can't be saved as a standard .pk3 file"
                      : "Species #" + std::to_string(raw) + " is specific to this hack, so it can't be saved as a standard .pk3 file";
            return false;
        }
        pkm::wr16(out.data() + 0x20, internal);
        pkm::wr16(out.data() + 0x1C, pkm::gen3Checksum(out.data()));
        return true;
    }

    pkm::Format format() const override { return pkm::Format::PK3; }
    std::string title() const override { return title_; }
    std::string trainer() const override { return trainer_; }
    int boxCount() const override { return kBoxes; }
    int boxSlots() const override { return kBoxMons; }

    std::string boxName(int box) const override {
        std::string def = SaveFile::boxName(box);
        if (box < 0 || box >= kBoxes) return def;
        uint8_t n[9];
        if (!stream(kStorageNamesAt + 9 * (size_t)box, n, 9, false)) return def;
        if (n[0] == 0xFF || n[0] == 0x00) return def;
        std::string s = pkm::utf16ToUtf8(pkm::gen3String(n, 8, false));
        return s.empty() ? def : s;
    }

    int partyCount() const override {
        int c = img_[active_.phys[1] + partyAt()];
        return c < 0 ? 0 : c > 6 ? 6 : c;
    }

    std::string notes() const override {
        int valid = 0;
        for (int id = 0; id < kSections; id++) {
            const uint8_t* sec = img_.data() + active_.phys[id];
            if (pkm::rd16(sec + 0xFF6) == sectionSum(sec, kLen[id])) valid++;
        }
        std::string n = "Newest save copy: " + std::to_string(valid) + " of 14 sections valid";
        if (mode_ == Gen3Species::Expansion) n += autoDetected_ ? "; expanded species numbering detected" : "; expanded species numbering";
        if (mode_ == Gen3Species::Cfru) n += autoDetected_ ? "; FireRed-hack species numbering detected" : "; FireRed-hack species numbering";
        if (origin_ != 0) n += "; found inside a larger file at offset " + std::to_string(origin_);
        return n;
    }

    bool readBox(int box, int slot, std::vector<uint8_t>& out) const override {
        if (box < 0 || box >= kBoxes || slot < 0 || slot >= kBoxMons) return false;
        uint8_t m[kMonSize];
        if (!stream(monAt(box, slot), m, kMonSize, false)) return false;
        return finish(m, kMonSize, out);
    }

    bool readParty(int index, std::vector<uint8_t>& out) const override {
        if (index < 0 || index >= partyCount()) return false;
        size_t at = active_.phys[1] + partyMonsAt() + (size_t)index * kPartyMonSize;
        if (at + kPartyMonSize > img_.size()) return false;
        uint8_t m[kPartyMonSize];
        std::memcpy(m, img_.data() + at, kPartyMonSize);
        return finish(m, kPartyMonSize, out);
    }

    bool writeBox(int box, int slot, const uint8_t* data, size_t len, std::string& err) override {
        if (box < 0 || box >= kBoxes || slot < 0 || slot >= kBoxMons) { err = "No such box slot"; return false; }
        if (!data || len < kMonSize) { err = "That is not a Gen 3 Pokemon"; return false; }
        uint8_t m[kMonSize];
        std::memcpy(m, data, kMonSize);
        if (pkm::rd16(m + 0x20) == 0) { err = "That Pokemon is empty"; return false; }
        pkm::wr16(m + 0x1C, pkm::gen3Checksum(m));
        pkm::gen3Encrypt(m);
        if (!stream(monAt(box, slot), m, kMonSize, true)) { err = "Could not write to the save"; return false; }
        return true;
    }

    bool clearBox(int box, int slot, std::string& err) override {
        if (box < 0 || box >= kBoxes || slot < 0 || slot >= kBoxMons) { err = "No such box slot"; return false; }
        uint8_t z[kMonSize] = {};
        if (!stream(monAt(box, slot), z, kMonSize, true)) { err = "Could not write to the save"; return false; }
        return true;
    }

    bool serialize(std::vector<uint8_t>& out, std::string&) const override {
        out = img_;
        return true;
    }

private:
    size_t partyAt() const { return kind_ == 1 ? 0x34 : 0x234; }
    size_t partyMonsAt() const { return kind_ == 1 ? 0x38 : 0x238; }
    static size_t monAt(int box, int slot) { return kStorageMonsAt + kMonSize * ((size_t)box * kBoxMons + (size_t)slot); }

    bool finish(uint8_t* m, size_t n, std::vector<uint8_t>& out) const {
        if (allZero(m, kMonSize)) return false;
        pkm::gen3Decrypt(m);
        if (pkm::rd16(m + 0x20) == 0) return false;  // no species = empty slot
        out.assign(m, m + n);
        return true;
    }

    // The PC storage is one byte stream spread over sections 5..13. Reads/writes `len` bytes at
    // stream offset `off`; a write also fixes the checksum of every section it touches.
    bool stream(size_t off, uint8_t* buf, size_t len, bool write) const {
        Gen3Save* self = const_cast<Gen3Save*>(this);
        size_t start = 0;
        size_t done = 0;
        bool touched[kSections] = {};
        for (int id = 5; id < kSections && done < len; id++) {
            size_t secLen = kLen[id];
            size_t pos = off + done;
            if (pos >= start + secLen) { start += secLen; continue; }
            size_t inSec = pos - start;
            size_t n = secLen - inSec;
            if (n > len - done) n = len - done;
            size_t at = active_.phys[id] + inSec;
            if (at + n > img_.size()) return false;
            if (write) { std::memcpy(self->img_.data() + at, buf + done, n); touched[id] = true; }
            else std::memcpy(buf + done, img_.data() + at, n);
            done += n;
            start += secLen;
        }
        if (done != len) return false;
        if (write)
            for (int id = 5; id < kSections; id++)
                if (touched[id]) {
                    uint8_t* sec = self->img_.data() + active_.phys[id];
                    pkm::wr16(sec + 0xFF6, sectionSum(sec, kLen[id]));
                }
        return true;
    }

    Bytes img_;
    size_t origin_;
    Slot active_;
    int kind_ = 2;  // 0 RS, 1 FRLG, 2 Emerald
    Gen3Species mode_ = Gen3Species::Vanilla;
    bool autoDetected_ = false;
    std::string title_, trainer_;
};

}  // namespace

SavePtr openGen3(const Bytes& b, const std::string&, const Game* hint, std::string& err) {
    err.clear();
    Slot first;
    size_t base = 0;
    bool found = false;
    for (size_t p = 0; p + kSlotSize <= b.size(); p += kSector) {
        first = probe(b, p);
        if (first.ok) { base = p; found = true; break; }
    }
    if (!found) return nullptr;  // not a Gen 3 save
    size_t origin = base;
    if (base == kSlotSize && b.size() >= 2 * kSlotSize) origin = 0;  // standalone image, first copy damaged
    Slot other = probe(b, base + kSlotSize);
    Slot active = first;
    if (other.ok && better(other, first)) active = other;
    return SavePtr(new Gen3Save(b, origin, active, hint));
}

}  // namespace save
