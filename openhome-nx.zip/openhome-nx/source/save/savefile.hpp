// A Pokemon save file opened for browsing and (where supported) editing.
//
// Pokemon bytes crossing this interface are in the DECRYPTED, LOGICAL layout of the matching .pk* file
// (the same files desktop OpenHome / PKHeX import and export). Each reader does the game-specific
// decryption, block shuffling, checksums and offsets internally.
#pragma once
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "pkm/pkm.hpp"

namespace save {

struct Game;  // gamedb.hpp

class SaveFile {
public:
    virtual ~SaveFile() = default;

    virtual pkm::Format format() const = 0;        // native Pokemon format of this save
    virtual std::string title() const = 0;         // "FireRed (Gen 3)", "Scarlet / Violet", ...
    virtual std::string trainer() const { return ""; }
    virtual int boxCount() const = 0;
    virtual int boxSlots() const = 0;              // slots per box (30; 25 in Let's Go)
    virtual std::string boxName(int box) const { return "Box " + std::to_string(box + 1); }
    virtual int partyCount() const { return 0; }
    // Human-readable remarks shown to the user ("14 of 14 sections valid", "found inside a larger file at offset 12288").
    virtual std::string notes() const { return ""; }

    // Reads one Pokemon. Returns false for an empty / invalid slot or out-of-range indices.
    virtual bool readBox(int box, int slot, std::vector<uint8_t>& out) const = 0;
    virtual bool readParty(int /*index*/, std::vector<uint8_t>& /*out*/) const { return false; }

    // Editing. Defaults refuse; formats that support it override all three.
    virtual bool writeBox(int /*box*/, int /*slot*/, const uint8_t* /*data*/, size_t /*len*/, std::string& err) {
        err = "Editing this kind of save is not supported yet";
        return false;
    }
    virtual bool clearBox(int /*box*/, int /*slot*/, std::string& err) {
        err = "Editing this kind of save is not supported yet";
        return false;
    }
    // Reads the displayable details of a Pokemon returned by readBox/readParty. Defaults to pkm::parse; saves
    // with their own numbering (e.g. Emerald Seaglass) override it.
    virtual pkm::Info describe(const std::vector<uint8_t>& mon) const { return pkm::parse(format(), mon.data(), mon.size()); }
    // Turns a Pokemon from this save into the bytes of a standard .pkN file. Returns false (with `why`) if it
    // cannot be represented as one.
    virtual bool exportMon(const std::vector<uint8_t>& mon, std::vector<uint8_t>& out, std::string& why) const {
        (void)why;
        out = mon;
        return true;
    }

    // The complete save file image with all edits applied and checksums fixed. Nothing on disk is touched.
    virtual bool serialize(std::vector<uint8_t>& out, std::string& err) const {
        (void)out;
        err = "Editing this kind of save is not supported yet";
        return false;
    }
};

using SavePtr = std::unique_ptr<SaveFile>;

// How species numbers are read from Gen 3 saves.
//   Vanilla   - the original Gen 3 internal numbering (Ruby/Sapphire/Emerald/FireRed/LeafGreen).
//   Expansion - National Dex numbers stored directly (pokeemerald-expansion hacks such as Emerald Seaglass).
//   Cfru      - FireRed hacks built on the Complete Fire Red Upgrade (Pokemon Unbound and similar): Gen 1-3 keep the
//               vanilla numbers, later generations are appended after them.
//   Auto      - decide from the save's contents and which game it is.
enum class Gen3Species { Auto, Vanilla, Expansion, Cfru };
void setGen3Species(Gen3Species m);
Gen3Species gen3Species();

// Identify and open a save. `hint` (may be null) is the game the file came from, when known. On failure
// returns nullptr and sets `err` ("" never means success: it is always filled with a reason).
SavePtr open(const std::vector<uint8_t>& bytes, const std::string& fileName, const Game* hint, std::string& err);

}  // namespace save
