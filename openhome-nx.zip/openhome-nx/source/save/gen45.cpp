// STUB: not implemented yet. Declines silently so other families get a chance.
#include "save/readers.hpp"

namespace save {

SavePtr openGen45(const Bytes&, const std::string&, const Game*, std::string&) { return nullptr; }

}  // namespace save
