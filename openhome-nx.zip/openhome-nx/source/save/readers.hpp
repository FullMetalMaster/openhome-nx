// One opener per save-format family. Each returns nullptr with `err` EMPTY when the bytes are not its
// format (so the next family can try), or nullptr with `err` filled when the bytes ARE its format but
// cannot be read (checksum failure, truncated, ...). savefile.cpp stops at the first non-empty `err`.
#pragma once
#include <string>
#include <vector>

#include "save/gamedb.hpp"
#include "save/savefile.hpp"

namespace save {

using Bytes = std::vector<uint8_t>;

SavePtr openGen3(const Bytes&, const std::string& fileName, const Game* hint, std::string& err);    // gen3.cpp   RS, E, FRLG (128 KB; also inside larger containers)
SavePtr openColosseum(const Bytes&, const std::string& fileName, const Game* hint, std::string& err); // colosseum.cpp Pokemon Colosseum (.gci / raw / memory card)
SavePtr openGen12(const Bytes&, const std::string& fileName, const Game* hint, std::string& err);   // gen12.cpp  Red/Blue/Yellow, Gold/Silver/Crystal
SavePtr openGen45(const Bytes&, const std::string& fileName, const Game* hint, std::string& err);   // gen45.cpp  DP, Pt, HGSS, BW, B2W2
SavePtr openGen67(const Bytes&, const std::string& fileName, const Game* hint, std::string& err);   // gen67.cpp  XY, ORAS, SM, USUM, Let's Go
SavePtr openBDSP(const Bytes&, const std::string& fileName, const Game* hint, std::string& err);    // bdsp.cpp   Brilliant Diamond / Shining Pearl
SavePtr openSCBlock(const Bytes&, const std::string& fileName, const Game* hint, std::string& err); // scblock.cpp Sword/Shield, Legends: Arceus, Scarlet/Violet, Legends: Z-A

}  // namespace save
