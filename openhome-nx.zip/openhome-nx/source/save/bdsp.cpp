// Pokemon Brilliant Diamond / Shining Pearl "SaveData.bin" (PKHeX SAV8BS.cs, BoxLayout8b.cs, Party8b.cs,
// MyStatus8b.cs, SaveUtil.IsG8BDSP). A flat file with fixed offsets; an MD5 of the whole file (with its own
// hash bytes zeroed) is stored at 0xE9818. Reading only.
#include <cstring>

#include "pkm/pkm_internal.hpp"
#include "pkm/pkmcrypto.hpp"
#include "save/hash.hpp"
#include "save/readers.hpp"

namespace save {
namespace {

constexpr size_t kBoxAt = 0x14EF4, kStride = 344, kStored = 328;
constexpr size_t kNamesAt = 0x148AA, kPartyAt = 0x14098, kStatusAt = 0x79BB4, kHashAt = 0xE9818;
constexpr int kBoxes = 40, kPerBox = 30;

struct Rev { size_t size; uint32_t version; };
const Rev kRevs[] = {{0xE9828, 0x25}, {0xEDC20, 0x2C}, {0xEED8C, 0x32}, {0xEF0A4, 0x34}};  // 1.0, 1.1, 1.2, 1.3

class BdspSave : public SaveFile {
public:
    BdspSave(Bytes d, bool hashOk) : d_(std::move(d)), hashOk_(hashOk) {
        game_ = d_[kStatusAt + 0x2B] == 1 ? "Shining Pearl" : "Brilliant Diamond";
        std::u16string ot;
        for (int i = 0; i < 13; i++) {
            uint16_t c = pkm::rd16(d_.data() + kStatusAt + (size_t)i * 2);
            if (!c) break;
            ot.push_back((char16_t)c);
        }
        trainer_ = pkm::utf16ToUtf8(ot);
    }
    pkm::Format format() const override { return pkm::Format::PB8; }
    std::string title() const override { return game_; }
    std::string trainer() const override { return trainer_; }
    int boxCount() const override { return kBoxes; }
    int boxSlots() const override { return kPerBox; }
    std::string notes() const override {
        return hashOk_ ? "Brilliant Diamond / Shining Pearl save, checksum OK" : "Save read, but its checksum does not match";
    }
    std::string boxName(int box) const override {
        std::string def = SaveFile::boxName(box);
        if (box < 0 || box >= kBoxes) return def;
        size_t at = kNamesAt + 0x22 * (size_t)box;
        if (pkm::rd16(d_.data() + at) == 0) return def;
        std::u16string s;
        for (int i = 0; i < 17; i++) {
            uint16_t c = pkm::rd16(d_.data() + at + (size_t)i * 2);
            if (!c) break;
            s.push_back((char16_t)c);
        }
        std::string u = pkm::utf16ToUtf8(s);
        return u.empty() ? def : u;
    }
    int partyCount() const override {
        int c = d_[kPartyAt + 6 * kStride];
        return c > 6 ? 6 : c;
    }
    bool readBox(int box, int slot, std::vector<uint8_t>& out) const override {
        if (box < 0 || box >= kBoxes || slot < 0 || slot >= kPerBox) return false;
        return decode(kBoxAt + ((size_t)box * kPerBox + (size_t)slot) * kStride, out);
    }
    bool readParty(int i, std::vector<uint8_t>& out) const override {
        if (i < 0 || i >= partyCount()) return false;
        return decode(kPartyAt + (size_t)i * kStride, out);
    }

private:
    bool decode(size_t off, std::vector<uint8_t>& out) const {
        if (off + kStored > d_.size()) return false;
        uint8_t m[kStored];
        std::memcpy(m, d_.data() + off, kStored);
        bool zero = true;
        for (size_t i = 0; i < kStored && zero; i++) zero = m[i] == 0;
        if (zero) return false;
        if (!pkm::crypto::decryptBlocks(m, kStored, 80)) return false;
        if (pkm::rd16(m + 8) == 0) return false;
        out.assign(m, m + kStored);
        return true;
    }
    Bytes d_;
    bool hashOk_;
    std::string game_, trainer_;
};

}  // namespace

SavePtr openBDSP(const Bytes& b, const std::string&, const Game*, std::string& err) {
    err.clear();
    bool match = false;
    for (const Rev& r : kRevs)
        if (b.size() == r.size && pkm::rd32(b.data()) == r.version) match = true;
    if (!match) return nullptr;
    // MD5 over the file with its hash bytes zeroed.
    Bytes tmp = b;
    std::memset(tmp.data() + kHashAt, 0, 16);
    uint8_t h[16];
    hash::md5(tmp.data(), tmp.size(), h);
    bool ok = std::memcmp(h, b.data() + kHashAt, 16) == 0;
    return SavePtr(new BdspSave(b, ok));
}

}  // namespace save
