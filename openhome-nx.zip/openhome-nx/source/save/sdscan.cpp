#include "save/sdscan.hpp"

#include <algorithm>

#include "box/fsutil.hpp"

namespace save {

static bool isSaveExt(const std::string& e) { return e == "sav" || e == "dsv" || e == "srm" || e == "sa1"; }

std::string classifySave(const std::string& fileName, uint64_t size) {
    if (!isSaveExt(fsu::extLower(fileName))) return "";
    switch (size) {
        case 32768: case 32816: return "Game Boy / GBC save (Gen 1-2)";
        case 131072: case 131088: return "GBA save (Gen 3)";
        case 524288: case 524410: return "DS save (Gen 4-5)";
        case 415232: return "3DS save (size matches X/Y)";
        case 483328: return "3DS save (size matches OR/AS)";
        case 441856: return "3DS save (size matches Sun/Moon)";
        case 445440: return "3DS save (size matches US/UM)";
        default: return "";
    }
}

void Scanner::start(const std::string& root) {
    stack_.clear();
    results_.clear();
    visited_ = other_ = 0;
    stack_.push_back({root, 0});
}

static bool skipDir(const std::string& name) {
    if (name.empty() || name[0] == '.') return true;
    static const char* kSkip[] = {"Nintendo", "atmosphere", "bootloader", "sxos", "emummc", "openhome-nx", "$RECYCLE.BIN",
                                  "System Volume Information"};
    for (const char* s : kSkip)
        if (name == s) return true;
    return false;
}

void Scanner::step(int budget) {
    while (budget-- > 0 && !stack_.empty()) {
        Item it = stack_.back();
        stack_.pop_back();
        visited_++;
        std::vector<fsu::Entry> es;
        if (!fsu::listDir(it.path, es)) continue;
        for (const auto& e : es) {
            std::string full = fsu::join(it.path, e.name);
            if (e.isDir) {
                if (it.depth < 8 && !skipDir(e.name)) stack_.push_back({full, it.depth + 1});
            } else {
                std::string ext = fsu::extLower(e.name);
                if (ext != "sav" && ext != "dsv" && ext != "srm" && ext != "sa1") continue;
                std::string label = classifySave(e.name, e.size);
                if (label.empty()) other_++;
                else results_.push_back({full, e.size, label});
            }
        }
    }
    std::sort(results_.begin(), results_.end(), [](const Found& a, const Found& b) { return a.path < b.path; });
}

}  // namespace save
