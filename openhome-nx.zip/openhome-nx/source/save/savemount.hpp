// Mounting a game's save data from the Switch (like JKSV does) + safe backups.
// Needs custom firmware homebrew with full filesystem permissions.
#pragma once
#include <cstdint>
#include <string>
#include <vector>

#include "gamedb.hpp"

namespace save {

struct User {
    std::string name;
    uint64_t uid[2] = {0, 0};
};

// Lists the console's user profiles directly through the account service. This works even when
// the system user-selector applet can't be opened (e.g. when launched from the album applet).
std::vector<User> listUsers(std::string& error);
void setUser(const User& u);
bool haveUser();
const User& currentUser();

struct MountResult {
    bool ok = false;
    std::string device;  // e.g. "ohsave" -> files at "ohsave:/main"
    std::string error;   // human-readable, includes the 2xxx-xxxx result code
};

MountResult mount(const Game& game);  // mounts the current user's save
void unmount();

// Copies everything in the mounted save to <sdRoot>/backups/<game>/<timestamp>/.
// Returns the backup dir, or "" (and fills `error`) on failure.
std::string backup(const Game& game, const std::string& sdRoot, std::string& error);

bool commit();  // fsdevCommitDevice, needed after modifying a mounted save

// "2002-0001"-style text for a libnx Result.
std::string resultText(uint32_t rc);

}  // namespace save
