// Switch Pokemon games supported by OpenHome-NX and how their saves are laid out.
// Host-safe (no libnx includes) so it can be unit tested.
#pragma once
#include <cstdint>
#include <vector>

#include "pkm/pkm.hpp"

namespace save {

enum class Crypto {
    None,        // plain binary (Let's Go)
    SCBlock,     // SCBlock container, swish-encrypted (Sword/Shield, Legends: Arceus, Scarlet/Violet)
    BDSPPlain,   // BDSP SaveData.bin (plain-ish; check PKHeX SAV8BS)
};

struct Game {
    const char* name;
    uint64_t titleId;
    pkm::Format format;      // native PKM format for this game
    const char* mainFile;    // primary save file inside the mounted save dir
    Crypto crypto;
    bool verified;           // title ID cross-checked against community lists by the author
    const char* match = nullptr;  // when titleId == 0: find the installed game whose name contains this text
};

// Title IDs are the base-game application IDs. Double check against your own console
// (e.g. via JKSV / the title list) before relying on them - regional editions share IDs, but
// please confirm. FireRed / LeafGreen and Legends: Z-A have no confirmed title ID here, so they are found
// on the console by NAME (see `match`); their saves are the standard GBA .sav (FRLG) or SCBlock `main` (Z-A).
const std::vector<Game>& games();

}  // namespace save
