# OpenHome NX

A Nintendo Switch homebrew (`.nro`) Pokémon box manager modelled on the desktop
[OpenHome](https://github.com/andrewbenington/OpenHome): a graphical bank/box grid with sprites, a
preview panel, filtering, release, and a way to find save files. Boxes are plain `.pk3 … .pk9` files on
your SD card, so they stay compatible with desktop OpenHome and PKHeX.

> **Status: v0.3.** Box UI, SD-card save search, profile picker, game-save mounting + backup, and readers for
> Gen 3 (Ruby/Sapphire/Emerald/FireRed/LeafGreen, **Pokemon Colosseum**, Emerald Seaglass / Pokemon Unbound style
> hacks), Sword/Shield, Legends: Arceus, BDSP, Scarlet/Violet and Legends: Z-A. Gen 1-2, Gen 4-5, Gen 6-7 and
> Let's Go saves are **not readable yet**. The app never writes to a game save.

## Colosseum

Put a `.gci` file, a raw 0x60000-byte save, or a whole GameCube memory-card image (`.raw .gcp .mcd`, for example from
Dolphin or a card dumper) anywhere on the SD card; **Find Saves -> Scan** lists it. The newest of the three save
slots is read and the Pokemon are converted to normal `.pk3` data. Shadow Pokemon are included. Read-only.

## ROM hacks and custom sprites

* **Auto / Vanilla / Expansion / Cfru** (Settings -> Gen 3 numbering) decide how species numbers are read.
  Emerald Seaglass uses National Dex numbers directly (Expansion). Unbound-style FireRed hacks (Cfru) append later
  generations after the Gen 3 block. Sweet-style re-skins use vanilla numbering.
* Species the hack added itself (fakemon) show a "?" tile with their number. Put art at
  `sdmc:/switch/openhome-nx/sprites/custom/raw_<number>.png` and it replaces the tile; `<dex>.png` in the same folder
  replaces an official sprite. The app cannot ship fakemon art.

## Build (Docker, works from Ubuntu/WSL)

```bash
cd openhome-nx
docker run --rm -v "$PWD":/project -w /project devkitpro/devkita64 make
```

Or with devkitPro installed locally: `export DEVKITPRO=/opt/devkitpro` then `make`.
The result is `openhome-nx.nro` (about 8 MB, it includes the sprites). Copy it to `sd:/switch/`.

Clean rebuild: add `make clean &&` in front.

## Using it

| Where | What |
|-------|------|
| **Home** | Bank/box grid. D-pad moves, **A** picks up/puts down (swaps if occupied), **L/R** change box, **Y** filter, **X** release (moves the file to `released/`, never deletes), **-** sort the box. Touch works too. |
| **Find Saves** | Left: the Switch games and **Change profile** (a built-in picker, so it works even from the album applet). Right: **Scan for saves** searches the whole SD card for `.sav .dsv .srm .sa1` (Game Boy, GBA, DS, 3DS), or **Browse folders** to look yourself. **A** on a Pokémon file imports it into the current box. |
| **Settings** | Info and paths. |

**Opening a save:** pressing **A** on a game (or on a save found on the SD card) opens it into the big
panel on the left of Home, showing its boxes with sprites. **D-pad Left** from the bank (or a tap) moves
into the save panel, **L/R** change the save's box, **A** picks up a *copy* of a Pokémon, then **A** on an
empty bank slot puts it there as a `.pkN` file. Saves are never written to. Readers so far: **Gen 3**
(Ruby/Sapphire/Emerald/FireRed/LeafGreen, including saves wrapped in a larger file) and **Gen 8/9**
(Sword/Shield, Legends: Arceus, Brilliant Diamond/Shining Pearl, Scarlet/Violet, Legends: Z-A).
Emerald Seaglass and other pokeemerald-expansion hacks are detected automatically (or force it in Settings).
FireRed, LeafGreen and Z-A are found by looking inside your profile's save data (not by name). Backups made by
this app can be reopened from Find Saves. The other generations still show "not readable yet".

**ZL/ZR** switch tabs. Pressing **A** on a game in *Console saves* mounts that game's save for your
profile and writes a full backup to `sdmc:/switch/openhome-nx/backups/` first.

Save mounting needs Atmosphere-style full file access. If mounting fails, the app shows the real
error code. Launching by holding **R** on a game (title takeover) instead of the album usually fixes it.

## Layout

| Path | Purpose |
|------|---------|
| `source/ui/` | The whole interface (tabs, grid, dialogs, keyboard) |
| `source/gfx/` | Small software renderer (shapes, text, PNG) so no SDL/borealis is needed |
| `source/platform/` | Switch input/screen/font; `tools/host_preview.cpp` provides a PC version |
| `source/box/` | Banks, boxes, fixed slot positions (`007_Charizard.pk9` = slot 7), file helpers |
| `source/pkm/` | PKM format detection and core fields; generated name tables |
| `source/save/` | Game DB, profile list, save mount + backup, SD-card scanner |
| `romfs/sprites/` | 1025 box sprites, packed by `tools/pack_sprites.py` |
| `tools/` | `gen_data.py` (name tables), `pack_sprites.py`, `host_preview.cpp` (PC screenshots) |

## Tests and PC preview (no Switch toolchain)

```bash
g++ -std=c++17 -Isource -o /tmp/t tests/test_pkm.cpp source/pkm/*.cpp source/box/*.cpp source/save/*.cpp && /tmp/t
g++ -std=c++17 -O1 -Isource -Itests -o /tmp/preview tools/host_preview.cpp source/ui/app.cpp \
  source/gfx/canvas.cpp source/box/*.cpp source/pkm/*.cpp source/save/*.cpp
/tmp/preview "$PWD" /usr/share/fonts/truetype/dejavu/DejaVuSans.ttf /tmp/shots   # writes PNG screenshots
```

More tests: `tests/test_gen3.cpp`, `test_modern.cpp`, `test_scblock.cpp`, `test_bdsp.cpp` (build lines are in
each file's header).

## Roadmap

0. Done: Gen 3 reader (tested on real `.pk3` data and synthetic saves in the real layout) and Gen 8/9
   readers (`scblock.cpp`, `bdsp.cpp`; checked against PKHeX's source and synthetic saves, not yet against a real
   console save). The Pokémon crypto was verified on 842 real encrypted Pokémon from a real 3DS save.
   FireRed/LeafGreen and Z-A are found on the console by name (title IDs are not built in).
1. Readers for Gen 1-2, Gen 4-5, Gen 6-7, Let's Go (PB7), then BDSP (`SaveData.bin`).
2. SCBlock + swish decryption for Sword/Shield, Legends: Arceus, Scarlet/Violet (port from
   [PKHeX](https://github.com/kwsch/PKHeX), GPL-3.0).
3. Box ↔ save transfer: backup first, checksum/hash fixups, `fsdevCommitDevice`.
4. Cross-generation conversion; tracked Pokémon, plugins, richer filters.
5. Older-game saves (GB/DS/3DS) found by *Find Saves*: read and import their Pokémon.
6. Legends: Z-A save layout (SCBlock, PKHeX `SAV9ZA`).

## Notes

- Struct offsets follow PKHeX's layouts and were tested on synthetic data only; verify on real exports.
- Sprites come from the OpenHome repository (`tools/pack_sprites.py`). Pokémon artwork belongs to
  its owners; keep this build for personal use.
- Modifying saves can corrupt them or get an online account banned. Keep the backups.
- Not affiliated with OpenHome, Nintendo, or The Pokémon Company. Project licence: GPL-3.0 (`LICENSE`).
