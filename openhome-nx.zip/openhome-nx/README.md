# OpenHome NX

A Nintendo Switch homebrew (`.nro`) Pokémon box manager modelled on the desktop
[OpenHome](https://github.com/andrewbenington/OpenHome): a graphical bank/box grid with sprites, a
preview panel, filtering, release, and a way to find save files. Boxes are plain `.pk3 … .pk9` files on
your SD card, so they stay compatible with desktop OpenHome and PKHeX.

> **Status: v0.2.** The interface, box management, SD-card save search, profile picker and
> game-save mounting + backup work. Reading/writing the Pokémon *inside* each game's save is **not
> implemented yet** (see Roadmap). The app never writes to a game save.

## Build (Docker, works from Ubuntu/WSL)

```bash
cd openhome-nx
docker run --rm -v "$PWD":/project -w /project devkitpro/devkita64 make
```

Or with devkitPro installed locally: `export DEVKITPRO=/opt/devkitpro` then `make`.
The result is `openhome-nx.nro` (about 8 MB, it includes the sprites). Copy it to `sd:/switch/`.

Clean rebuild: add `make clean &&` in front.

## Using it

| Where | What |
|-------|------|
| **Home** | Bank/box grid. D-pad moves, **A** picks up/puts down (swaps if occupied), **L/R** change box, **Y** filter, **X** release (moves the file to `released/`, never deletes), **-** sort the box. Touch works too. |
| **Find Saves** | Left: the Switch games and **Change profile** (a built-in picker, so it works even from the album applet). Right: **Scan for saves** searches the whole SD card for `.sav .dsv .srm .sa1` (Game Boy, GBA, DS, 3DS), or **Browse folders** to look yourself. **A** on a Pokémon file imports it into the current box. |
| **Settings** | Info and paths. |

**ZL/ZR** switch tabs. Pressing **A** on a game in *Console saves* mounts that game's save for your
profile and writes a full backup to `sdmc:/switch/openhome-nx/backups/` first.

Save mounting needs Atmosphere-style full file access. If mounting fails, the app shows the real
error code. Launching by holding **R** on a game (title takeover) instead of the album usually fixes it.

## Layout

| Path | Purpose |
|------|---------|
| `source/ui/` | The whole interface (tabs, grid, dialogs, keyboard) |
| `source/gfx/` | Small software renderer (shapes, text, PNG) so no SDL/borealis is needed |
| `source/platform/` | Switch input/screen/font; `tools/host_preview.cpp` provides a PC version |
| `source/box/` | Banks, boxes, fixed slot positions (`007_Charizard.pk9` = slot 7), file helpers |
| `source/pkm/` | PKM format detection and core fields; generated name tables |
| `source/save/` | Game DB, profile list, save mount + backup, SD-card scanner |
| `romfs/sprites/` | 1025 box sprites, packed by `tools/pack_sprites.py` |
| `tools/` | `gen_data.py` (name tables), `pack_sprites.py`, `host_preview.cpp` (PC screenshots) |

## Tests and PC preview (no Switch toolchain)

```bash
g++ -std=c++17 -Isource -o /tmp/t tests/test_pkm.cpp source/pkm/*.cpp source/box/*.cpp source/save/*.cpp && /tmp/t
g++ -std=c++17 -O1 -Isource -Itests -o /tmp/preview tools/host_preview.cpp source/ui/app.cpp \
  source/gfx/canvas.cpp source/box/*.cpp source/pkm/*.cpp source/save/*.cpp
/tmp/preview "$PWD" /usr/share/fonts/truetype/dejavu/DejaVuSans.ttf /tmp/shots   # writes PNG screenshots
```

## Roadmap

1. Let's Go (PB7) save reader, then BDSP (`SaveData.bin`).
2. SCBlock + swish decryption for Sword/Shield, Legends: Arceus, Scarlet/Violet (port from
   [PKHeX](https://github.com/kwsch/PKHeX), GPL-3.0).
3. Box ↔ save transfer: backup first, checksum/hash fixups, `fsdevCommitDevice`.
4. Cross-generation conversion; tracked Pokémon, plugins, richer filters.
5. Older-game saves (GB/GBA/DS/3DS) found by *Find Saves*: read and import their Pokémon.
6. Legends: Z-A once its title ID and save layout are confirmed.

## Notes

- Struct offsets follow PKHeX's layouts and were tested on synthetic data only; verify on real exports.
- Sprites come from the OpenHome repository (`tools/pack_sprites.py`). Pokémon artwork belongs to
  its owners; keep this build for personal use.
- Modifying saves can corrupt them or get an online account banned. Keep the backups.
- Not affiliated with OpenHome, Nintendo, or The Pokémon Company. Project licence: GPL-3.0 (`LICENSE`).
